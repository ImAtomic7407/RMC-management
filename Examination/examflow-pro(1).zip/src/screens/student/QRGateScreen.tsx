import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Button, Card, Badge } from '../../components/ui/M3Components';
import { QrCode, ArrowLeft, RefreshCw, Smartphone, ShieldCheck, Sparkles, LogOut } from 'lucide-react';

export default function QRGateScreen({ exam, onBack, onTriggerVerify }: { exam: any, onBack: () => void, onTriggerVerify: () => void }) {
  const { user, studentGateState, setStudentGateState, setGateSessions } = useAppContext();
  const [expiryTime, setExpiryTime] = useState(299); // 5 mins

  useEffect(() => {
    const timer = setInterval(() => {
      setExpiryTime(prev => {
        if (prev <= 1) {
          return 299; // auto reset
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleRefresh = () => {
    setExpiryTime(299);
  };

  const handleSimulateAutoVerify = () => {
    setStudentGateState(prev => ({
      ...prev,
      status: 'WAITING_ROOM',
      verified: true,
      paperDownloaded: 'DOWNLOADING',
      percent: 15
    }));

    setGateSessions(prev => prev.map(s => {
      if (s.student.id === 's1') { // Rohan
        return {
          ...s,
          gateStatus: 'VERIFIED',
          deviceStatus: 'BOUND',
          paperDownloadStatus: 'DOWNLOADING'
        };
      }
      return s;
    }));

    // Trigger timer to complete paper download
    setTimeout(() => {
      setStudentGateState(prev => {
        if (prev.verified) {
          return {
            ...prev,
            paperDownloaded: 'READY',
            percent: 100
          };
        }
        return prev;
      });

      setGateSessions(prev => prev.map(s => {
        if (s.student.id === 's1') {
          return { ...s, paperDownloadStatus: 'READY' };
        }
        return s;
      }));
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col justify-between p-4">
      {/* Top Bar */}
      <div className="space-y-2">
        <header className="flex items-center gap-3 py-2 border-b border-surface-variant/30">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-sm font-extrabold text-on-surface truncate max-w-[200px]">{exam.title}</h1>
            <p className="text-[10px] text-tertiary font-bold uppercase">Gate Entrance Verification</p>
          </div>
        </header>

        {/* Identity Context */}
        <div className="flex items-center justify-between bg-surface-container-low px-4 py-3 rounded-2xl border border-outline/10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary-container rounded-xl text-on-primary-container">
               <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div>
               <p className="text-xs font-bold leading-tight">{user?.name}</p>
               <p className="font-mono text-[9px] text-on-surface-variant uppercase">{user?.id === 's1' ? 'JEE26-041' : 'JEE-UNKNOWN'}</p>
            </div>
          </div>
          <Badge variant="info">WAITING SCAN</Badge>
        </div>
      </div>

      {/* Center QR Zone */}
      <div className="flex flex-col items-center justify-center space-y-4 my-4">
        {/* Animated mock QR code */}
        <div className="relative p-6 bg-white rounded-[36px] shadow-lg border border-surface-variant/40 flex flex-col items-center">
          <div className="w-56 h-56 bg-surface-container-high rounded-2xl p-4 flex items-center justify-center relative overflow-hidden">
            {/* Real aesthetic design pattern representing simulated QR */}
            <div className="grid grid-cols-4 gap-3 w-full h-full opacity-80 select-none">
              {Array.from({ length: 16 }).map((_, i) => (
                <div 
                  key={i} 
                  className={`rounded ${
                    (i % 3 === 0 || i === 0 || i === i || i === 15) ? 'bg-on-surface' : 'bg-transparent'
                  }`} 
                />
              ))}
            </div>
            
            {/* Scanning line indicator */}
            <div className="absolute inset-x-0 top-0 h-1 bg-primary shadow-sm shadow-primary/40 animate-bounce" style={{ animationDuration: '4s' }} />
          </div>

          <div className="absolute -top-3 bg-secondary text-on-secondary px-3 py-1 rounded-full text-[9px] font-mono font-bold tracking-wider uppercase">
             GATE TOKEN SIGNATURE
          </div>

          <p className="text-[9px] font-mono text-on-surface-variant pt-4 flex items-center gap-1.5 uppercase font-bold text-center">
            <Smartphone className="w-3.5 h-3.5 text-primary" /> Device ID: {user?.id === 's1' ? 'DEV-9801X' : 'DEV-STUDENT'}
          </p>
        </div>

        {/* Expiry Widget */}
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-bold text-on-surface-variant uppercase">Token expires in</p>
          <div className="flex items-center gap-3">
             <span className="text-lg font-mono font-bold text-error">{formatCountdown(expiryTime)}</span>
             <button onClick={handleRefresh} className="p-1.5 bg-surface-container hover:bg-surface-container-high rounded-lg">
                <RefreshCw className="w-3.5 h-3.5 text-primary" />
             </button>
          </div>
        </div>
      </div>

      {/* Instructions & Help */}
      <div className="space-y-3">
        <Card className="p-4 bg-primary-container/10 border border-primary-container text-xs text-on-surface space-y-1">
           <h3 className="font-bold text-primary text-xs flex items-center gap-1">
             <ShieldCheck className="w-4 h-4" /> EXAM DOOR INSTRUCTION
           </h3>
           <p className="text-on-surface opacity-80 text-[11px] leading-relaxed">
             Show this QR code on your phone screen to your assigned exam hall supervisor. Your locked examination package will decrypt on your device immediately after supervisor gate scan.
           </p>
        </Card>

        {/* Simulation Sandbox Tool for review */}
        <div className="p-3 bg-tertiary-container/10 border-2 border-dashed border-tertiary-container rounded-2xl space-y-1.5">
           <div className="flex items-center gap-1.5 text-[10px] font-bold text-tertiary">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SIMULATE SUPERVISOR DESK ACTION</span>
           </div>
           <button 
             onClick={handleSimulateAutoVerify}
             className="w-full bg-secondary-container hover:bg-secondary-container/80 text-on-secondary-container py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1"
           >
              <span>⚡ COMPLETED SUPERVISOR DISK SCAN</span>
           </button>
        </div>
      </div>
    </div>
  );
}
