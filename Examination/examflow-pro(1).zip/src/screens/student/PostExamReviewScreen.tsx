import React, { useState } from 'react';
import { Card, Badge, Button } from '../../components/ui/M3Components';
import { 
  ArrowLeft, Download, Award, ShieldAlert, CheckCircle, AlertOctagon, 
  HelpCircle, ChevronRight, ChevronDown, Sparkles, BookOpen, Star, Undo2
} from 'lucide-react';

export default function PostExamReviewScreen({ exam, onBack, onOpenPracticeRetake }: { 
  exam: any, 
  onBack: () => void,
  onOpenPracticeRetake: () => void
}) {
  const [activeTab, setActiveTab] = useState<'PHYSICS' | 'CHEMISTRY' | 'MATHS'>('PHYSICS');
  const [expandedSolutions, setExpandedSolutions] = useState<Record<number, boolean>>({});

  const scoreSummary = {
    score: 245,
    maxScore: 300,
    pct: '81.6%',
    correct: 65,
    wrong: 10,
    unattempted: 15,
    rank: '#1'
  };

  const PHYSICS_REVIEWS = [
    {
      id: 101,
      text: "A parallel plate capacitor is charged and then disconnected from the source. Explain the effect on capacitance if a dielectric sheet is inserted.",
      type: "MCQ",
      selected: "A",
      correct: "A",
      status: "CORRECT",
      gained: "+4 Marks",
      options: ["Capacitance increases & voltage decreases", "Capacitance decreases & voltage increases", "Capacitance remains constant", "Capacitance drops to zero"],
      explanation: "Inserting a dielectric sheet increases capacitance because of polarization of the material (C = K*C0). Since it is disconnected from the battery, the charge Q remains constant, leading to V = Q/C decreasing accordingly.",
    },
    {
      id: 102,
      text: "Calculate the equivalent resistance of a reciprocal circuit containing 5 gold resistors in parallel where each resistor is of value 25 Ohms.",
      type: "INTEGER",
      selected: "5",
      correct: "5",
      status: "CORRECT",
      gained: "+4 Marks",
      options: [],
      explanation: "Equivalent resistance R_eq of n identical resistors in parallel is R/n. Here 25 Ohms / 5 = 5 Ohms.",
    },
    {
      id: 103,
      text: "What is the speed of an electromagnetic wave in vacuum? (in standard metric power representation)",
      type: "MCQ",
      selected: "B",
      correct: "A",
      status: "WRONG",
      gained: "-1 Mark",
      options: ["3 x 10^8 m/s", "1.5 x 10^8 m/s", "4.2 x 10^9 m/s", "None of the above"],
      explanation: "The velocity of light and electromagnetic waves in vacuum is exactly 3 x 10^8 m/s (c = 1 / sqrt(mu0 * epsilon0)).",
    }
  ];

  const CHEMISTRY_REVIEWS = [
    {
      id: 201,
      text: "What is the hybridisation of xenon in XeF4 compound structure?",
      type: "MCQ",
      selected: "A",
      correct: "A",
      status: "CORRECT",
      gained: "+4 Marks",
      options: ["sp3d2", "sp3", "dsp2", "sp3d"],
      explanation: "Xenon has 8 valence electrons. In XeF4, it forms 4 sigma bonds with fluorine and retains 2 lone pairs. Static number is 6, which denotes sp3d2 hybridisation.",
    },
    {
      id: 202,
      text: "Determine the state oxidation number of central chromium atom in acidic sodium dichromate compound reagent (Na2Cr2O7).",
      type: "INTEGER",
      selected: "",
      correct: "6",
      status: "UNATTEMPTED",
      gained: "0 Marks",
      options: [],
      explanation: "Sodium state is +1, Oxygen state is -2. Thus 2(+1) + 2(Cr) + 7(-2) = 0 => 2Cr = 12 => Cr = +6 oxidation state.",
    }
  ];

  const MATHS_REVIEWS = [
    {
      id: 301,
      text: "Find the general solution of the integration limit of integral bounded by unit circle boundary curves.",
      type: "MCQ",
      selected: "B",
      correct: "B",
      status: "CORRECT",
      gained: "+4 Marks",
      options: ["Pi square", "2 Pi", "Pi", "Zero"],
      explanation: "General integral along circular contour of length is calculated via boundary conditions resulting in 2 Pi limit resolution.",
    }
  ];

  const reviewQuestionsMap = {
    PHYSICS: PHYSICS_REVIEWS,
    CHEMISTRY: CHEMISTRY_REVIEWS,
    MATHS: MATHS_REVIEWS
  };

  const activeReviews = reviewQuestionsMap[activeTab];

  const toggleSolution = (qId: number) => {
    setExpandedSolutions(prev => ({
      ...prev,
      [qId]: !prev[qId]
    }));
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col pb-24">
      {/* Header */}
      <header className="px-4 py-4 border-b border-surface-variant flex items-center justify-between sticky top-0 bg-surface z-30">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-on-surface">Official Review Portal</h1>
            <p className="text-[10px] text-on-surface-variant">SECURE MOCK · RELEASED RESULTS KEYS</p>
          </div>
        </div>
        <Button variant="text" className="!px-2 border border-outline/10 text-xs font-bold gap-1 flex items-center">
           <Download className="w-3.5 h-3.5" /> PDF
        </Button>
      </header>

      <main className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Results Banner Grid */}
        <Card className="p-5 bg-surface-container-low border border-surface-variant/30 space-y-4">
           <div className="flex justify-between items-center bg-primary-container/20 p-3.5 rounded-2xl">
              <div className="flex items-center gap-2">
                 <Award className="w-8 h-8 text-primary" />
                 <div>
                    <p className="text-[9px] font-bold text-on-surface-variant uppercase">Your Final Rank</p>
                    <p className="text-lg font-black text-on-surface">LEADERBOARD #{scoreSummary.rank}</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-[9px] font-bold text-on-surface-variant uppercase">Score Percentage</p>
                 <p className="text-lg font-black text-primary">{scoreSummary.pct}</p>
              </div>
           </div>

           <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
              <div className="bg-surface-container-high p-2 rounded-xl">
                 <p className="text-[8px] opacity-75 uppercase">Total</p>
                 <p className="font-bold">{scoreSummary.score}/{scoreSummary.maxScore}</p>
              </div>
              <div className="bg-green-100 text-green-800 p-2 rounded-xl">
                 <p className="text-[8px] opacity-75 uppercase">Correct</p>
                 <p className="font-bold">{scoreSummary.correct}</p>
              </div>
              <div className="bg-red-100 text-red-800 p-2 rounded-xl">
                 <p className="text-[8px] opacity-75 uppercase">Wrong</p>
                 <p className="font-bold">{scoreSummary.wrong}</p>
              </div>
              <div className="bg-surface-container p-2 rounded-xl">
                 <p className="text-[8px] opacity-75 uppercase">Left</p>
                 <p className="font-bold">{scoreSummary.unattempted}</p>
              </div>
           </div>
        </Card>

        {/* Section Tabs */}
        <div className="flex bg-surface-container p-1 rounded-2xl gap-1">
           {['PHYSICS', 'CHEMISTRY', 'MATHS'].map((tab) => (
             <button
               key={tab}
               onClick={() => setActiveTab(tab as any)}
               className={`flex-1 py-2 text-center rounded-xl text-[10px] font-bold tracking-wide transition-all ${
                 activeTab === tab ? 'bg-primary text-on-primary' : 'text-on-surface-variant'
               }`}
             >
               {tab}
             </button>
           ))}
        </div>

        {/* Questions Cards Reviews */}
        <div className="space-y-4">
           {activeReviews.map((rev, index) => {
             const isCorrect = rev.status === 'CORRECT';
             const isWrong = rev.status === 'WRONG';
             const isUnattempted = rev.status === 'UNATTEMPTED';
             const isOpen = expandedSolutions[rev.id] || false;

             return (
               <Card key={rev.id} className="p-4 space-y-3.5 border border-surface-variant/30 relative">
                  <div className="flex justify-between items-start">
                     <span className="text-[10px] bg-surface-container-high font-mono px-2 py-0.5 rounded font-bold">
                        Q.{index+1} · {rev.type}
                     </span>
                     <div className="flex gap-1.5 items-center">
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-extrabold ${
                          isCorrect ? 'bg-green-100 text-green-800' : isWrong ? 'bg-red-100 text-red-800' : 'bg-surface-container text-on-surface-variant'
                        }`}>{rev.status}</span>
                        <span className="text-[10px] font-bold font-mono text-on-surface-variant">{rev.gained}</span>
                     </div>
                  </div>

                  <p className="text-xs font-semibold leading-relaxed text-on-surface">{rev.text}</p>

                  {/* Options status */}
                  {rev.type === 'MCQ' ? (
                    <div className="space-y-2">
                       {rev.options.map((opt, oIdx) => {
                          const labelMap = ['A', 'B', 'C', 'D'];
                          const label = labelMap[oIdx];
                          const selectedByMe = rev.selected === label;
                          const correctByAnswer = rev.correct === label;

                          let bgClass = "bg-surface-container-low border-outline/10";
                          let dotColor = "bg-surface-container-high";

                          if (correctByAnswer) {
                            bgClass = "bg-green-100 text-green-900 border-green-400";
                            dotColor = "bg-green-600 text-white";
                          } else if (selectedByMe) {
                            bgClass = "bg-red-50 text-red-900 border-red-400";
                            dotColor = "bg-red-600 text-white";
                          }

                          return (
                            <div key={label} className={`p-3 rounded-2xl border text-xs leading-normal flex items-center gap-2.5 font-bold ${bgClass}`}>
                               <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${dotColor}`}>
                                  {label}
                               </span>
                               <span>{opt}</span>
                            </div>
                          );
                       })}
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                       <div className="bg-surface-container-low p-2.5 rounded-xl border border-outline/10">
                          <p className="text-[8px] text-on-surface-variant uppercase font-bold">Your marked Input</p>
                          <p className="font-mono text-xs">{isUnattempted ? '— Not Entered' : rev.selected}</p>
                       </div>
                       <div className="bg-green-50 p-2.5 rounded-xl border border-green-200">
                          <p className="text-[8px] text-green-700 uppercase font-bold">Official Correct answer</p>
                          <p className="font-mono text-xs text-green-900 font-bold">{rev.correct}</p>
                       </div>
                    </div>
                  )}

                  {/* Solution expandable */}
                  <div className="border-t border-surface-variant/40 pt-1.5">
                     <button 
                       onClick={() => toggleSolution(rev.id)}
                       className="w-full flex items-center justify-between text-[11px] font-bold text-primary py-1"
                     >
                       <span>VIEW ANSWER EXPLANATION</span>
                       <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                     </button>

                     {isOpen && (
                       <div className="space-y-3.5 pt-2 animate-in slide-in-from-top-1 duration-200">
                          <div className="aspect-[4/1.5] bg-surface-container-high p-4 rounded-xl flex items-center justify-center border border-dashed border-outline/15 select-none text-[9px] font-mono text-on-surface-variant flex-col gap-1">
                             <HelpCircle className="w-5 h-5 text-on-surface-variant/40 animate-spin" style={{ animationDuration: '4s' }} />
                             <span>MATH/PHYS SOLUTION GRAPH block</span>
                             <span className="opacity-40 text-[8px]">EXPLAIN_DRAW_ID_{rev.id}.PNG</span>
                          </div>
                          <p className="text-[11px] text-on-surface-variant leading-relaxed font-medium">
                             {rev.explanation}
                          </p>
                       </div>
                     )}
                  </div>
               </Card>
             );
           })}
        </div>

        {/* Retake paper practice CTA */}
        <Card className="p-4 bg-tertiary-container/10 border border-tertiary-container mt-4 space-y-3">
           <div className="flex items-center gap-1.5 text-xs font-bold text-tertiary">
              <Star className="w-4 h-4 text-tertiary fill-current" />
              <span>Full Paper Retest / Practice</span>
           </div>
           <p className="text-[10px] text-on-surface-variant leading-relaxed">
              Want to improve your marks or try solving candidates variations? You can now retake this entire scheduled exam variant paper under friendly Practice mode. No rankings or lock logs.
           </p>
           <Button onClick={onOpenPracticeRetake} className="w-full text-xs font-bold bg-secondary-container text-on-secondary-container rounded-xl flex items-center justify-center gap-1">
              <Undo2 className="w-3.5 h-3.5" /> START FULL RETAKE PRACTICE
           </Button>
        </Card>
      </main>
    </div>
  );
}
