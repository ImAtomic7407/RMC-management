import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Button, Card, Badge } from '../../components/ui/M3Components';
import { 
  ShieldCheck, AlertTriangle, HelpCircle, ArrowRight, ShieldAlert, 
  Trash2, Landmark, CheckCircle, Timer, Menu, Bookmark, HelpCircleIcon, 
  RefreshCw, Sparkles, ChevronLeft, ChevronRight, CheckCircle2, CloudLightning
} from 'lucide-react';

export default function SecureAttemptScreen({ onSucceedSubmit, onBackToLobby }: { 
  onSucceedSubmit: () => void, 
  onBackToLobby: () => void 
}) {
  const { studentGateState, setStudentGateState, gateSessions, setGateSessions } = useAppContext();

  // Active step inside Secure screen: 'ENTRY_RULES' | 'LIVE_EXAM'
  const [internalStep, setInternalStep] = useState<'ENTRY_RULES' | 'LIVE_EXAM'>('ENTRY_RULES');

  // Rules checklist state
  const [agreedToRules, setAgreedToRules] = useState(false);

  // Active question and exam state
  const [activeSection, setActiveSection] = useState<'PHYSICS' | 'CHEMISTRY' | 'MATHS'>('PHYSICS');
  const [activeQuestionIdx, setActiveQuestionIdx] = useState(0);
  const [secTimer, setSecTimer] = useState(10795); // 2h 59m 55s
  const [showNavigator, setShowNavigator] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [saveState, setSaveState] = useState<'Saved' | 'Saving' | 'Retry'>('Saved');

  // Load standard question paper Mock data
  const PHYSICS_QUESTIONS = [
    { id: 101, text: "A parallel plate capacitor is charged and then disconnected from the source. Explain the effect on capacitance if a dielectric sheet is inserted.", type: "MCQ", order: 1, options: ["Capacitance increases & voltage decreases", "Capacitance decreases & voltage increases", "Capacitance remains constant", "Capacitance drops to zero"] },
    { id: 102, text: "Calculate the equivalent resistance of a reciprocal circuit containing 5 gold resistors in parallel where each resistor is of value 25 Ohms.", type: "INTEGER", order: 2, options: [] },
    { id: 103, text: "What is the speed of an electromagnetic wave in vacuum? (in standard metric power representation)", type: "MCQ", order: 3, options: ["3 x 10^8 m/s", "1.5 x 10^8 m/s", "4.2 x 10^9 m/s", "None of the above"] },
  ];

  const CHEMISTRY_QUESTIONS = [
    { id: 201, text: "What is the hybridisation of xenon in XeF4 compound structure?", type: "MCQ", order: 1, options: ["sp3d2", "sp3", "dsp2", "sp3d"] },
    { id: 202, text: "Determine the state oxidation number of central chromium atom in acidic sodium dichromate compound reagent (Na2Cr2O7).", type: "INTEGER", order: 2, options: [] },
  ];

  const MATHS_QUESTIONS = [
    { id: 301, text: "Find the general solution of the integration limit of integral bounded by unit circle boundary curves.", type: "MCQ", order: 1, options: ["Pi square", "2 Pi", "Pi", "Zero"] },
    { id: 302, text: "Evaluate the limit value: Lim (x tends to 1) [ (x^10 - 1) / (x - 1) ].", type: "INTEGER", order: 2, options: [] },
  ];

  const questionsMap = {
    PHYSICS: PHYSICS_QUESTIONS,
    CHEMISTRY: CHEMISTRY_QUESTIONS,
    MATHS: MATHS_QUESTIONS
  };

  const currentQuestions = questionsMap[activeSection];
  const activeQuestion = currentQuestions[activeQuestionIdx] || currentQuestions[0];

  // Tick timer
  useEffect(() => {
    if (internalStep === 'LIVE_EXAM' && !studentGateState.showViolationWarning) {
      const interval = setInterval(() => {
        setSecTimer(prev => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [internalStep, studentGateState.showViolationWarning]);

  const formatSecTimer = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleOptionSelect = (qId: number, optionIndex: string) => {
    setSaveState('Saving');
    setTimeout(() => {
      setStudentGateState((prev: any) => ({
        ...prev,
        answers: {
          ...prev.answers,
          [qId]: { ...prev.answers[qId], selectedOption: optionIndex }
        }
      }));
      setSaveState('Saved');
    }, 400);
  };

  const handleIntegerChange = (qId: number, val: string) => {
    setSaveState('Saving');
    setTimeout(() => {
      setStudentGateState((prev: any) => ({
        ...prev,
        answers: {
          ...prev.answers,
          [qId]: { ...prev.answers[qId], integerAnswer: val }
        }
      }));
      setSaveState('Saved');
    }, 400);
  };

  const handleToggleMark = (qId: number) => {
    setStudentGateState((prev: any) => {
      const nextMarked = new Set(prev.marked);
      if (nextMarked.has(qId)) {
        nextMarked.delete(qId);
      } else {
        nextMarked.add(qId);
      }
      return { ...prev, marked: nextMarked };
    });
  };

  // Safe navigation checks
  const handlePrev = () => {
    if (activeQuestionIdx > 0) {
      setActiveQuestionIdx(prev => prev - 1);
    }
  };

  const handleNext = () => {
    if (activeQuestionIdx < currentQuestions.length - 1) {
      setActiveQuestionIdx(prev => prev + 1);
    } else {
      // Toggle to next section
      if (activeSection === 'PHYSICS') {
        setActiveSection('CHEMISTRY');
        setActiveQuestionIdx(0);
      } else if (activeSection === 'CHEMISTRY') {
        setActiveSection('MATHS');
        setActiveQuestionIdx(0);
      }
    }
  };

  const triggerMockViolation = (reason: string) => {
    const nextCount = studentGateState.violationCount + 1;
    setStudentGateState((prev: any) => ({
      ...prev,
      violationCount: nextCount,
      showViolationWarning: true,
      violationReason: reason
    }));

    // Sync to teacher gate sessions model
    setGateSessions((prev: any[]) => prev.map(s => {
      if (s.student.id === 's1') {
        return { ...s, violationCount: s.violationCount + 1 };
      }
      return s;
    }));
  };

  // Submit flow
  const handleFinalConfirmSubmit = () => {
    setStudentGateState((prev: any) => ({
      ...prev,
      status: 'SUBMITTED'
    }));

    setGateSessions((prev: any[]) => prev.map(s => {
       if (s.student.id === 's1') {
         return { ...s, attemptStatus: 'SUBMITTED' };
       }
       return s;
    }));

    setShowSubmitModal(false);
    onSucceedSubmit();
  };

  // Simple statistics count
  const allQuestionIds = [...PHYSICS_QUESTIONS, ...CHEMISTRY_QUESTIONS, ...MATHS_QUESTIONS].map(q => q.id);
  const attemptedCount = allQuestionIds.filter(qId => {
    const ans = studentGateState.answers[qId];
    return ans && (ans.selectedOption !== undefined || (ans.integerAnswer !== undefined && ans.integerAnswer !== ''));
  }).length;
  const markedReviewCount = studentGateState.marked.size;
  const unattemptedCount = allQuestionIds.length - attemptedCount;

  // RULE ENTRY SCREEN
  if (internalStep === 'ENTRY_RULES') {
    return (
      <div className="min-h-screen bg-surface flex flex-col justify-between p-5 pb-8">
        <header className="py-2 border-b border-surface-variant/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-primary" />
            <div>
              <h1 className="text-xs font-bold text-on-surface-variant uppercase">SECURITY PROTOCOL VERIFICATION</h1>
              <h2 className="text-sm font-extrabold text-on-surface">Secure Lock Sandbox Environment</h2>
            </div>
          </div>
        </header>

        <main className="flex-1 py-4 space-y-4 overflow-y-auto">
          <Card className="p-3 bg-red-50 text-red-900 border border-red-200">
             <div className="flex items-center gap-2 mb-1.5 font-bold">
                <AlertTriangle className="w-5 h-5 text-error" />
                <h3 className="text-xs">HIGH SECURITY LEVEL ACTIVATED</h3>
             </div>
             <p className="text-[10px] leading-relaxed">
                By entering secure mode, your mobile browser locks focus. Moving out of the tab, screen switches, screenshots, split screens, or turning off devices will immediately trigger automated supervisor cheating alarms!
             </p>
          </Card>

          {/* Core restrictive points */}
          <div className="space-y-2">
             <h4 className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider px-1">Candidate Prohibited Actions</h4>
             <div className="space-y-2">
                <RestrictionRow label="Full-Screen Focus Enforcement" desc="The exam tab must remain at top of window stack. Background movement flags a violation." />
                <RestrictionRow label="Instant Screenshot Blocking" desc="Hardware screenshot clicks are parsed & screens will be locked under white security protection covers." />
                <RestrictionRow label="System Navigation Disabled" desc="Native Back button triggers prevent accidental page navigation. Submit form manually." />
                <RestrictionRow label="Smart Assistant & Overlay Checks" desc="Any floating overlay icons, call overlays or volume toggles will submit or flag the participant." />
             </div>
          </div>

          {/* Privacy Overlay Explanation */}
          <Card className="p-3.5 bg-surface-container-low border border-outline/10 space-y-1">
             <h4 className="text-xs font-bold text-on-surface">Volume & Privacy Calibration</h4>
             <p className="text-[10px] text-on-surface-variant leading-relaxed">
                Your device front camera will monitor eye tracking. To protect student privacy, data is cached strictly locally in encrypted chunks — no bio telemetry is uploaded to our central cloud nodes.
             </p>
          </Card>

          {/* Agreed state checkbox */}
          <label className="flex items-start gap-3 bg-surface-container p-3 rounded-2xl border border-primary/10 select-none cursor-pointer">
            <input 
              type="checkbox" 
              checked={agreedToRules} 
              onChange={() => setAgreedToRules(!agreedToRules)}
              className="mt-1 w-4 h-4 rounded text-primary focus:ring-primary accent-primary" 
            />
            <div className="text-[11px] leading-relaxed">
               <span className="font-bold text-on-surface block">I understand & accept the examination room rules</span>
               <span className="text-on-surface-variant opacity-75">I agree to stay in secure system mode. I am fully responsible for any attempt termination caused by browser swapping.</span>
            </div>
          </label>
        </main>

        <div className="space-y-2">
           <Button 
             disabled={!agreedToRules}
             onClick={() => setInternalStep('LIVE_EXAM')}
             className="w-full py-4 bg-error text-on-error font-extrabold flex items-center justify-center gap-2 rounded-2xl"
           >
              <span>LOCK BROWSER & START EXAM</span>
              <ArrowRight className="w-4 h-4" />
           </Button>
           <button onClick={onBackToLobby} className="w-full text-center py-2 text-[11px] text-on-surface-variant hover:text-primary">
              Return to Waiting Room Locker
           </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // LIVE SECURED EXAMINATION INTERFACE
  // ==========================================
  return (
    <div className="min-h-screen bg-surface flex flex-col justify-between">
      {/* EXAM SECURITY VIOLATION OVERLAY */}
      {studentGateState.showViolationWarning && (
        <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center p-6 space-y-5 animate-in fade-in duration-150">
          <div className="p-4 bg-red-100 rounded-full text-error">
             <ShieldAlert className="w-16 h-16 animate-bounce" />
          </div>
          <div className="text-center space-y-2 max-w-sm">
             <h2 className="text-lg font-black text-on-surface uppercase tracking-tight">Exam Security Violation</h2>
             <p className="text-xs font-bold text-red-700">ALERT SIGNATURE DETECTED: {studentGateState.violationReason}</p>
             <p className="text-[11px] text-on-surface-variant leading-relaxed">
                Your sandbox window focus was disrupted! Gatekeepers has synchronized this incident. Please note that repeated warnings may result in immediate auto-submission.
             </p>
          </div>

          <div className="bg-red-50 border border-red-200 px-4 py-3 rounded-2xl space-y-1 text-center w-full max-w-xs">
             <p className="text-[11px] font-bold text-red-900 uppercase">Warning Severity Status</p>
             <p className="text-xl font-bold font-mono text-error">Warning {studentGateState.violationCount} of 3</p>
          </div>

          <Button 
            variant={studentGateState.violationCount >= 3 ? 'danger' : 'primary'}
            disabled={studentGateState.violationCount >= 4}
            onClick={() => {
              if (studentGateState.violationCount >= 3) {
                // Auto submit!
                handleFinalConfirmSubmit();
              } else {
                setStudentGateState((prev: any) => ({ ...prev, showViolationWarning: false }));
              }
            }}
            className="w-full py-3.5 text-xs font-bold uppercase shrink-0 max-w-xs"
          >
             {studentGateState.violationCount >= 3 ? 'FORCE SUBMIT EXAM ATTEMPT' : 'I acknowledge, return to my paper'}
          </Button>

          <p className="text-[9px] text-on-surface-variant font-mono text-center">SECURE PROTOCOL BIND ACTIVE</p>
        </div>
      )}

      {/* SUBMIT CONFIRMATION OVERLAY */}
      {showSubmitModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
           <Card className="p-6 bg-surface max-w-md w-full space-y-4 border border-surface-variant">
              <div className="flex items-center gap-2 border-b border-surface-variant/35 pb-2">
                 <ShieldCheck className="w-5 h-5 text-primary" />
                 <h3 className="font-extrabold text-sm uppercase text-on-surface">PRE-SUBMIT QUESTION STATEMENT</h3>
              </div>

              <div className="grid grid-cols-3 gap-2 py-1 text-center text-xs">
                 <div className="bg-green-100 rounded-xl p-2.5 text-green-900">
                    <p className="text-[9px] font-bold uppercase">Attempted</p>
                    <p className="text-base font-bold font-mono">{attemptedCount}</p>
                 </div>
                 <div className="bg-yellow-100 rounded-xl p-2.5 text-yellow-900">
                    <p className="text-[9px] font-bold uppercase">Mark Review</p>
                    <p className="text-base font-bold font-mono">{markedReviewCount}</p>
                 </div>
                 <div className="bg-red-100 rounded-xl p-2.5 text-red-900">
                    <p className="text-[9px] font-bold uppercase">Unattempted</p>
                    <p className="text-base font-bold font-mono">{unattemptedCount}</p>
                 </div>
              </div>

              {/* Summary table */}
              <div className="space-y-1.5 bg-surface-container-low p-3 rounded-xl border border-outline/5 text-[11px]">
                 <p className="font-bold opacity-75">Variant Section breakdown:</p>
                 <div className="flex justify-between">
                   <span>Physics Segment</span>
                   <span className="font-mono font-bold">3 Qs complete</span>
                 </div>
                 <div className="flex justify-between">
                   <span>Chemistry Segment</span>
                   <span className="font-mono font-bold">2 Qs complete</span>
                 </div>
                 <div className="flex justify-between">
                   <span>Maths Segment</span>
                   <span className="font-mono font-bold">2 Qs complete</span>
                 </div>
              </div>

              <div className="bg-red-50 text-red-800 p-3 rounded-xl text-[10px] leading-relaxed font-bold">
                 ⚡ CRITICAL: Once you confirm submit, answers will lock instantly. Correct options, marking rubrics, solution maps cannot be accessed until administrator releases results.
              </div>

              <div className="flex gap-2">
                 <Button onClick={() => setShowSubmitModal(false)} variant="outline" className="flex-1 font-bold py-3 text-xs">
                    GO BACK
                 </Button>
                 <Button onClick={handleFinalConfirmSubmit} className="flex-1 bg-red-700 text-white hover:bg-red-800 font-bold py-3 text-xs">
                    CONFIRM SUBMIT
                 </Button>
              </div>
           </Card>
        </div>
      )}

      {/* Top status header */}
      <header className="bg-surface sticky top-0 px-4 py-3 flex items-center justify-between border-b border-surface-variant/40 z-30">
        <div className="flex items-center gap-1.5">
          <Badge variant="error" className="animate-pulse bg-red-600 font-mono text-[8px] tracking-widest px-2.5 py-0.5 font-bold">
            SECURE EXAM CONSOLE
          </Badge>
          <span className="bg-primary/10 text-primary font-mono text-[9px] px-2 py-0.5 rounded font-bold">Variant: Alpha-A</span>
        </div>

        {/* Counter clock */}
        <div className="flex items-center gap-1.5 bg-surface-container px-3 py-1.5 rounded-full border border-outline/5">
          <Timer className="w-4 h-4 text-error" />
          <span className="font-mono text-xs font-black text-on-surface">{formatSecTimer(secTimer)}</span>
        </div>
      </header>

      {/* Sections Tab Row */}
      <div className="bg-surface-container flex border-b border-surface-variant sticky top-[53px] z-20">
        {['PHYSICS', 'CHEMISTRY', 'MATHS'].map((sec) => (
          <button
            key={sec}
            onClick={() => {
              setActiveSection(sec as any);
              setActiveQuestionIdx(0);
            }}
            className={`flex-1 text-center py-3 text-[10px] font-bold border-b-2 tracking-wider ${
              activeSection === sec ? 'border-primary text-primary bg-primary/5' : 'border-transparent text-on-surface-variant opacity-75'
            }`}
          >
            {sec}
          </button>
        ))}
      </div>

      {/* Question Main Workspace */}
      <main className="p-4 space-y-4 flex-1 overflow-y-auto">
        {/* Sync Status / Offline Widget */}
        <div className="flex justify-between items-center text-[9px] bg-green-50 text-green-800 border border-green-200 px-3 py-1.5 rounded-xl font-mono uppercase font-bold">
          <span className="flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5" /> CACHED ENVELOPE VERIFIED (OFFLINE OK)</span>
          <span className="flex items-center gap-1 text-primary"><RefreshCw className="w-3 h-3 animate-spin" /> SYNCED LIVE</span>
        </div>

        {/* Question Header Card */}
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-sm text-on-surface">Question #{activeQuestion.order} ({activeQuestion.type})</h3>
          <button 
            onClick={() => handleToggleMark(activeQuestion.id)}
            className={`p-2 rounded-xl flex items-center gap-1 border text-[10px] font-bold ${
              studentGateState.marked.has(activeQuestion.id) 
                ? 'bg-yellow-100 border-yellow-300 text-yellow-900' 
                : 'bg-surface-container-low border-outline/10 text-on-surface-variant'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${studentGateState.marked.has(activeQuestion.id) ? 'fill-current' : ''}`} />
            <span>{studentGateState.marked.has(activeQuestion.id) ? 'Marked Review' : 'Mark Review'}</span>
          </button>
        </div>

        {/* Question image mockup block */}
        <div className="aspect-[4/2] bg-surface-container-high rounded-2xl flex flex-col items-center justify-center border border-outline/15 border-dashed relative select-none">
           <svg className="w-8 h-8 opacity-25 text-on-surface-variant animate-pulse mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
           </svg>
           <span className="text-[9px] font-mono opacity-50 font-bold uppercase uppercase tracking-widest">{activeSection} variant diagram block</span>
           <span className="absolute bottom-1 right-2 font-mono text-[8px] opacity-40">IMAGE_VARIANT_{activeQuestion.id}.PNG</span>
        </div>

        {/* Question content text */}
        <p className="text-xs font-semibold leading-relaxed text-on-surface selection:bg-transparent">
          {activeQuestion.text}
        </p>

        {/* Selected options block */}
        <div className="space-y-2 pt-2">
          {activeQuestion.type === 'MCQ' ? (
            activeQuestion.options.map((option: string, index: number) => {
              const labelMap = ['A', 'B', 'C', 'D'];
              const label = labelMap[index];
              const isSelected = studentGateState.answers[activeQuestion.id]?.selectedOption === label;
              return (
                <button
                  key={label}
                  onClick={() => handleOptionSelect(activeQuestion.id, label)}
                  className={`w-full p-3.5 rounded-2xl border text-left text-xs font-bold transition-all flex items-center gap-3 ${
                    isSelected 
                      ? 'bg-primary-container text-on-primary-container border-primary font-black scale-[1.01]' 
                      : 'bg-surface-container-low border-outline/10 text-on-surface hover:bg-surface-container-high'
                  }`}
                >
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                     isSelected ? 'bg-primary text-on-primary' : 'bg-surface-container-high text-on-surface-variant border border-outline/20'
                  }`}>{label}</span>
                  <span>{option}</span>
                </button>
              );
            })
          ) : (
            <div className="space-y-2 bg-surface-container-low p-4 rounded-3xl border border-outline/10">
               <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">CANDIDATE INTEGER TYPE ANSWER</p>
               <input 
                 type="number" 
                 placeholder="Please write your calculated numeric answer here..." 
                 value={studentGateState.answers[activeQuestion.id]?.integerAnswer || ''}
                 onChange={(e) => handleIntegerChange(activeQuestion.id, e.target.value)}
                 className="w-full bg-surface text-on-surface py-3 px-4 rounded-xl text-xs font-bold font-mono border border-outline/30 focus:border-primary outline-none"
               />
               <p className="text-[9px] text-on-surface-variant opacity-75">Only standard floating points/integers are formatted. Decimals up to 2 positions accepted.</p>
            </div>
          )}
        </div>
      </main>

      {/* Simulator alerts panel directly built into live paper workspace for validation */}
      <Card className="m-4 p-3 bg-tertiary-container/10 border border-dashed border-tertiary-container space-y-1.5 shrink-0">
         <div className="flex items-center gap-1.5 text-[10px] font-bold text-tertiary">
            <Sparkles className="w-3.5 h-3.5" />
            <span>SECURE SANDBOX VALIDATION SIMULATION</span>
         </div>
         <div className="grid grid-cols-2 gap-2 text-[8px] font-mono">
           <button onClick={() => triggerMockViolation("App Swapped background detected!")} className="bg-red-50 text-red-900 px-2 py-1.5 rounded-lg font-bold border border-red-200 text-left">
             ⚡ Switch app background
           </button>
           <button onClick={() => triggerMockViolation("Secondary floating call overlays detected!")} className="bg-red-50 text-red-900 px-2 py-1.5 rounded-lg font-bold border border-red-200 text-left">
             ⚡ Capture screenshot
           </button>
         </div>
      </Card>

      {/* Bottom control row */}
      <footer className="bg-surface border-t border-surface-variant px-4 py-3 sticky bottom-0 z-10 space-y-2">
        <div className="flex justify-between items-center text-xs">
          {/* Save Status */}
          <span className="text-[10px] font-mono font-bold text-on-surface-variant flex items-center gap-1">
             <span className={`w-2 h-2 rounded-full ${saveState === 'Saved' ? 'bg-green-600' : 'bg-yellow-500 animate-pulse'}`} />
             <span>{saveState === 'Saved' ? 'Auto-Cached Saved' : 'Auto-Caching...'}</span>
          </span>

          {/* Grid navigator controller */}
          <button 
            onClick={() => setShowNavigator(!showNavigator)}
            className="text-primary font-bold text-xs flex items-center gap-1 bg-primary/5 px-3 py-1.5 rounded-lg border border-primary/20"
          >
             <span>Question Map Grid</span>
          </button>
        </div>

        {/* Nav list cards showing question states */}
        {showNavigator && (
          <div className="bg-surface-container rounded-3xl p-4 border border-surface-variant animate-in slide-in-from-bottom duration-200 max-h-[140px] overflow-y-auto">
             <p className="text-[10px] font-bold text-on-surface-variant uppercase mb-2">Question breakdown list</p>
             <div className="grid grid-cols-6 gap-2 text-center text-[10px] font-mono font-bold">
               {allQuestionIds.map((qId, idx) => {
                  const isMarked = studentGateState.marked.has(qId);
                  const isAns = studentGateState.answers[qId]?.selectedOption || studentGateState.answers[qId]?.integerAnswer;
                  return (
                    <button 
                      key={qId}
                      onClick={() => {
                        // find section
                        if (idx < 3) {
                          setActiveSection('PHYSICS');
                          setActiveQuestionIdx(idx);
                        } else if (idx < 5) {
                          setActiveSection('CHEMISTRY');
                          setActiveQuestionIdx(idx - 3);
                        } else {
                          setActiveSection('MATHS');
                          setActiveQuestionIdx(idx - 5);
                        }
                        setShowNavigator(false);
                      }}
                      className={`p-2 rounded-lg border ${
                        isMarked 
                          ? 'bg-yellow-200 text-yellow-900 border-yellow-400' 
                          : isAns 
                            ? 'bg-green-200 text-green-900 border-green-400' 
                            : 'bg-surface-container-high text-on-surface border-outline/10'
                      }`}
                    >
                       {idx + 1}
                    </button>
                  );
               })}
             </div>
          </div>
        )}

        <div className="flex gap-2">
           <Button variant="outline" onClick={handlePrev} className="flex-1 py-3 text-xs font-bold">
              PREVIOUS
           </Button>
           <Button variant="tonal" onClick={handleNext} className="flex-1 py-3 text-xs font-bold">
              SAVE & NEXT
           </Button>
           <Button onClick={() => setShowSubmitModal(true)} className="flex-1 py-3 bg-red-700 hover:bg-red-800 text-white text-xs font-extrabold rounded-2xl text-center">
              SUBMIT PAPER
           </Button>
        </div>
      </footer>
    </div>
  );
}

const RestrictionRow = ({ label, desc }: { label: string, desc: string }) => (
  <div className="flex items-start gap-2.5 bg-surface-container-low border border-outline/5 px-3 py-2.5 rounded-2xl text-xs">
    <div className="w-2 h-2 rounded-full bg-error mt-1.5 shrink-0" />
    <div>
      <span className="font-extrabold text-on-surface block leading-none">{label}</span>
      <span className="text-[10px] text-on-surface-variant leading-tight opacity-75">{desc}</span>
    </div>
  </div>
);
