import React from 'react';
import { Card, Badge, Button } from '../../components/ui/M3Components';
import { ShieldCheck, Undo2, Award, ArrowLeft, AlignCenter, Star, HelpCircleIcon, AlertTriangle } from 'lucide-react';

export default function PracticeIntroScreen({ exam, onBack, onStartPractice, onReviewPrevious }: {
  exam: any,
  onBack: () => void,
  onStartPractice: () => void,
  onReviewPrevious: () => void
}) {
  return (
    <div className="min-h-screen bg-surface flex flex-col justify-between p-5 pb-8">
      {/* Top Bar */}
      <header className="flex items-center gap-3 py-2 border-b border-surface-variant/30 text-on-surface">
        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xs font-bold text-on-surface-variant uppercase">PRACTICE RETAKE PORTAL</h1>
          <h2 className="text-sm font-extrabold text-on-surface truncate max-w-[200px]">{exam.title}</h2>
        </div>
      </header>

      {/* Main illustration & info */}
      <main className="flex-1 py-6 space-y-6 overflow-y-auto">
        <div className="flex flex-col items-center text-center space-y-3 p-4">
           <div className="p-4 bg-tertiary-container/30 text-tertiary rounded-full animate-pulse">
              <Undo2 className="w-12 h-12" />
           </div>
           <div>
              <Badge variant="warning" className="uppercase font-mono tracking-widest px-3 font-bold text-[9px]">
                 PRACTICE / UNRANKED MODE
              </Badge>
              <h3 className="font-extrabold text-base text-on-surface mt-2">Ready to retest the full paper?</h3>
              <p className="text-xs text-on-surface shadow-sm max-w-sm mt-1 leading-relaxed opacity-80">
                 You are about to launch a friendly unranked practice session on the exact same exam package variant.
              </p>
           </div>
        </div>

        {/* Warning cards / Info list */}
        <div className="space-y-3">
           <Card className="p-4 bg-surface-container border border-surface-variant/40 space-y-2 text-xs">
              <h4 className="font-bold text-on-surface flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-primary" /> RETAKE GUIDELINES</h4>
              <p className="text-on-surface-variant text-[11px] leading-relaxed">
                 1. The retest session runs locally inside your browser cache.
              </p>
              <p className="text-on-surface-variant text-[11px] leading-relaxed">
                 2. Correct answers, solutions will be unlocked IMMEDIATELY inside the reattempt viewport upon selecting choices, or at manual submit.
              </p>
              <p className="text-on-surface-variant text-[11px] leading-relaxed">
                 3. Your score will be stored strictly as a practice attempt — it will <strong>never affect</strong> the official exam leaderboard ranking.
              </p>
           </Card>

           <div className="bg-yellow-50 text-yellow-900 border border-yellow-200 rounded-2xl p-4 flex gap-3 text-xs leading-relaxed">
              <AlertTriangle className="w-6 h-6 shrink-0 text-yellow-700 mt-0.5" />
              <div>
                 <span className="font-bold block">No Single-Question Reattempts</span>
                 <span className="text-[10px] opacity-90">To simulate high realistic mock values, you must practice the entire exam paper layout sequentially. Single selected question isolated retry is prohibited.</span>
              </div>
           </div>
        </div>
      </main>

      {/* Primary Actions */}
      <div className="space-y-3 max-w-sm mx-auto w-full">
         <Button 
           onClick={onStartPractice}
           className="w-full py-4 text-base bg-primary text-on-primary font-bold rounded-2xl flex items-center justify-center gap-2 shadow-md"
         >
            <Star className="w-4.5 h-4.5 fill-current text-on-primary" /> START RETAKE PRACTICE
         </Button>
         <Button 
           onClick={onReviewPrevious}
           variant="tonal"
           className="w-full py-3.5 text-xs font-bold rounded-2xl"
         >
            REVIEW PREVIOUS SUBMITTED KEY
         </Button>
      </div>
    </div>
  );
}
