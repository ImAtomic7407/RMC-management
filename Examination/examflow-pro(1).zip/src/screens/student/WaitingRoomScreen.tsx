import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Button, Card, Badge } from '../../components/ui/M3Components';
import { 
  CheckCircle, Loader2, RefreshCw, AlertCircle, FileLock2, Award, 
  Compass, ShieldAlert, Sparkles
} from 'lucide-react';

export default function WaitingRoomScreen({ exam, onEnterSecureMode }: { exam: any, onEnterSecureMode: () => void }) {
  const { user, studentGateState, setStudentGateState } = useAppContext();
  const [downloadProgress, setDownloadProgress] = useState(30);

  useEffect(() => {
    if (studentGateState.paperDownloaded === 'DOWNLOADING') {
      const interval = setInterval(() => {
        setDownloadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStudentGateState(current => ({
              ...current,
              paperDownloaded: 'READY'
            }));
            return 100;
          }
          return prev + 10;
        });
      }, 500);
      return () => clearInterval(interval);
    }
  }, [studentGateState.paperDownloaded]);

  const handleRetryDownload = () => {
    setDownloadProgress(10);
    setStudentGateState(prev => ({
      ...prev,
      paperDownloaded: 'DOWNLOADING'
    }));
  };

  const isReady = studentGateState.paperDownloaded === 'READY';

  return (
    <div className="min-h-screen bg-surface flex flex-col justify-between p-4 pb-8">
      {/* Header */}
      <header className="py-2 border-b border-surface-variant/30 flex items-center justify-between">
        <div>
          <h1 className="text-xs font-bold text-on-surface-variant uppercase">SECURE WAITING LOBBY</h1>
          <h2 className="text-sm font-extrabold text-on-surface truncate max-w-[200px]">{exam.title}</h2>
        </div>
        <Badge variant={isReady ? 'success' : 'warning'}>
           {studentGateState.paperDownloaded}
        </Badge>
      </header>

      <main className="flex-1 py-4 space-y-5 overflow-y-auto">
        {/* Student Profile Identity Card */}
        <Card className="p-4 flex gap-4 items-center bg-surface-container-low border border-outline/5 shadow-sm">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150" 
            alt="Profile pic" 
            className="w-14 h-14 rounded-full border-2 border-primary/20 object-cover"
          />
          <div>
            <h3 className="font-extrabold text-base text-on-surface">{user?.name}</h3>
            <p className="font-mono text-[10px] uppercase text-on-surface-variant">UID: {user?.id === 's1' ? 'JEE26-041' : 'JEE-UNKNOWN'}</p>
            <div className="flex gap-2 mt-1">
               <span className="bg-green-100 text-green-800 text-[8px] px-2 py-0.5 rounded-full font-bold uppercase">Gate Verified</span>
               <span className="bg-primary-container text-on-primary-container text-[8px] px-2 py-0.5 rounded-full font-bold uppercase">Device Bound: {user?.id === 's1' ? 'DEV-9801X' : 'DEV-STUDENT'}</span>
            </div>
          </div>
        </Card>

        {/* Assigned Seats Section */}
        <div className="grid grid-cols-2 gap-2">
           <div className="bg-surface-container-high p-3 rounded-2xl text-center">
              <p className="text-[9px] uppercase font-bold text-on-surface-variant opacity-70">ASSIGN SEAT NUMBER</p>
              <p className="text-xl font-bold font-mono text-primary">HALL-04 / SEAT-19</p>
           </div>
           <div className="bg-surface-container-high p-3 rounded-2xl text-center">
              <p className="text-[9px] uppercase font-bold text-on-surface-variant opacity-70">VARIANT VARIATION</p>
              <p className="text-xl font-bold font-mono text-tertiary">VARIANT_ALPHA (SEC&gt;A)</p>
           </div>
        </div>

        {/* Paper Package Status Widget */}
        <Card className="p-4 bg-surface-container border border-surface-variant/40 space-y-3">
          <div className="flex justify-between items-center text-xs font-bold">
             <span className="text-on-surface flex items-center gap-1.5"><FileLock2 className="w-4 h-4 text-primary" /> SECURE DECRYPTION PROGRESS</span>
             <span className="text-primary font-mono">{isReady ? '100%' : `${downloadProgress}%`}</span>
          </div>

          {!isReady ? (
            <div className="space-y-2">
              <div className="w-full h-2 bg-surface-container-high rounded-full overflow-hidden">
                <div 
                  className="bg-primary h-full transition-all duration-300" 
                  style={{ width: `${downloadProgress}%` }} 
                />
              </div>
              <p className="text-[10px] text-on-surface-variant text-center animate-pulse flex items-center justify-center gap-1.5">
                <Loader2 className="w-3.5 h-3.5 animate-spin" /> Fetching exam questions package encryption tokens...
              </p>
            </div>
          ) : (
            <div className="bg-green-50 text-green-800 p-2 text-center rounded-xl text-[10px] font-bold border border-green-200 flex items-center justify-center gap-1.5">
               <CheckCircle className="w-4 h-4 text-green-700" /> SECURE OFFLINE CACHE ENVELOPE GENERATED SUCCESSFULLY!
            </div>
          )}

          {studentGateState.paperDownloaded === 'FAILED' && (
            <div className="space-y-2">
              <div className="bg-red-50 text-red-800 p-3 rounded-xl text-xs space-y-1 border border-red-200">
                <p className="font-bold flex items-center gap-1.5"><AlertCircle className="w-4 h-4 text-error" /> Package decpryption error (Err: 403-Signature)</p>
                <p className="text-[10px]">Your device network disconnected. Press retry button to attempt cache download again.</p>
              </div>
              <Button onClick={handleRetryDownload} variant="outline" className="w-full py-2.5 text-xs font-bold flex items-center justify-center gap-1.5">
                 <RefreshCw className="w-3.5 h-3.5" /> RE-DOWNLOAD SECURE BRIEFCASE
              </Button>
            </div>
          )}
        </Card>

        {/* Section Target Count Breakdown */}
        <div className="space-y-2">
          <p className="text-[10px] font-bold text-on-surface-variant px-2 uppercase tracking-wide">SECURE COGNITIVE PACKAGES</p>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
             <SectionCard label="Physics" count="30 Questions" />
             <SectionCard label="Chemistry" count="30 Questions" />
             <SectionCard label="Maths" count="30 Questions" />
          </div>
        </div>

        {/* Readiness Checklist */}
        <div className="space-y-2 pt-2 border-t border-surface-variant/30">
          <p className="text-[10px] font-bold text-on-surface-variant px-2 uppercase tracking-wide">Gate Readiness Checksheet</p>
          <div className="space-y-2">
            <CheckRow active={true} label="Identity physically validated by supervisor gate scan" />
            <CheckRow active={true} label="Active hardware physical address pre-bound with candidate account" />
            <CheckRow active={true} label="Candidate variants generated and package envelope buffered" />
            <CheckRow active={isReady} label="Local security sandbox cache database synchronized" />
            <CheckRow active={isReady} label="Answers inputs will remain locked until exam administrator opens gateway" />
          </div>
        </div>
      </main>

      {/* Enter Action Button */}
      <div className="space-y-4">
        {/* Helper sandbox widgets to trigger download completion manually for testing */}
        {!isReady && (
          <div className="p-3 bg-tertiary-container/10 border border-dashed border-tertiary-container rounded-2xl flex items-center justify-between">
             <span className="text-[9px] font-bold text-tertiary">SIMULATOR ACTION:</span>
             <button 
               onClick={() => setStudentGateState(prev => ({ ...prev, paperDownloaded: 'READY' }))}
               className="bg-primary text-on-primary text-[9px] px-3 py-1 rounded-lg font-bold"
             >
                FORCIBLY READY PACKAGE
             </button>
          </div>
        )}

        <Button 
          disabled={!isReady} 
          onClick={onEnterSecureMode}
          className="w-full py-4 text-base font-bold flex items-center justify-center gap-2 rounded-2xl bg-secondary-container text-on-secondary-container hover:bg-primary hover:text-on-primary max-w-md mx-auto"
        >
          <Compass className="w-5 h-5 animate-pulse" /> ENTER SECURE MODE GATE
        </Button>
      </div>
    </div>
  );
}

const SectionCard = ({ label, count }: { label: string, count: string }) => (
  <div className="bg-surface-container-high p-2 rounded-xl">
     <p className="font-bold text-on-surface text-[11px] mb-0.5">{label}</p>
     <p className="text-[9px] opacity-75">{count}</p>
  </div>
);

const CheckRow = ({ active, label }: { active: boolean, label: string }) => (
  <div className="flex items-start gap-3 px-2 text-xs">
    {active ? (
      <CheckCircle className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
    ) : (
      <Loader2 className="w-4 h-4 text-on-surface-variant/40 shrink-0 mt-0.5 animate-spin" />
    )}
    <span className={active ? 'text-on-surface font-medium' : 'text-on-surface-variant opacity-50'}>{label}</span>
  </div>
);
