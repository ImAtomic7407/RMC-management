import React, { useState, useEffect } from 'react';
import { Card, Button, Badge, Tabs } from '../../components/ui/M3Components';
import { Clock, Send, ChevronLeft, ChevronRight, Grid, Bookmark, AlertCircle } from 'lucide-react';

export default function StudentAttemptScreen({ exam, onFinish }: any) {
  const [activeTab, setActiveTab] = useState<'PHYSICS' | 'CHEMISTRY' | 'MATHS'>('PHYSICS');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10800); // 3 hours
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [markedForReview, setMarkedForReview] = useState<Set<string>>(new Set());
  const [showGrid, setShowGrid] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setTimeLeft(prev => Math.max(0, prev - 1)), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const sections = [
    { id: 'PHYSICS', label: 'Physics' },
    { id: 'CHEMISTRY', label: 'Chemistry' },
    { id: 'MATHS', label: 'Maths' },
  ];

  // Dummy questions for the UI preview
  const questions: any[] = Array.from({ length: 30 }).map((_, i) => ({
    id: `q-${activeTab}-${i}`,
    number: i + 1,
    type: i % 5 === 0 ? 'INTEGER' : 'MCQ',
    text: `Complex problem involving ${activeTab} principles. What is the final value?`,
    marks: 4,
    negMarks: 1
  }));

  const q = questions[currentIdx];
  const isSelected = (opt: string) => answers[q.id] === opt;

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Header */}
      <header className="p-4 bg-primary text-on-primary flex items-center justify-between sticky top-0 z-20 shadow-lg">
        <div className="flex flex-col">
          <h2 className="text-sm font-bold opacity-80 truncate max-w-[150px]">{exam.title}</h2>
          <div className="flex items-center gap-1">
             <Clock className="w-3.5 h-3.5" />
             <span className="text-lg font-mono font-bold">{formatTime(timeLeft)}</span>
          </div>
        </div>
        <Button 
          variant="secondary" 
          onClick={onFinish} 
          className="shadow-sm !px-4 !py-1 text-sm bg-tertiary-container text-on-tertiary-container"
        >
          SUBMIT
        </Button>
      </header>

      {/* Section Filter */}
      <div className="bg-surface sticky top-[68px] z-10 px-4 py-2 flex justify-between items-center shadow-sm border-b border-surface-variant/50">
        <Tabs items={sections} activeTab={activeTab} onChange={(id) => {
          setActiveTab(id as any);
          setCurrentIdx(0);
        }} />
        <button onClick={() => setShowGrid(true)} className="p-2 bg-surface-container-high rounded-xl">
           <Grid className="w-6 h-6" />
        </button>
      </div>

      <main className="flex-1 overflow-y-auto p-4 space-y-4 pb-32">
        <div className="flex justify-between items-center bg-surface-container-low p-2 rounded-xl">
           <span className="text-xs font-bold px-3">Question {currentIdx + 1}</span>
           <div className="flex gap-2">
              <span className="text-[10px] font-bold bg-green-100 text-green-800 px-2 py-0.5 rounded-full">+4</span>
              <span className="text-[10px] font-bold bg-red-100 text-red-800 px-2 py-0.5 rounded-full">-1</span>
           </div>
        </div>

        {/* Question Content */}
        <div className="space-y-4">
           {/* Question Image Placeholder */}
           <div className="w-full h-48 bg-white border border-surface-variant rounded-2xl flex items-center justify-center p-4">
              <div className="text-center opacity-30">
                 <AlertCircle className="w-12 h-12 mx-auto mb-2" />
                 <p className="font-bold text-sm underlineDecoration">Question Image View Area</p>
                 <p className="text-[10px]">Real image from server will load here</p>
              </div>
           </div>
           
           <p className="text-on-surface font-medium leading-relaxed">{q.text}</p>
        </div>

        {/* Answer Selection */}
        <div className="pt-4 border-t border-surface-variant/30">
           {q.type === 'MCQ' ? (
             <div className="grid gap-3">
               {['A', 'B', 'C', 'D'].map(opt => (
                 <button 
                   key={opt}
                   onClick={() => setAnswers({...answers, [q.id]: opt})}
                   className={`p-4 rounded-[20px] flex items-center gap-4 border-2 transition-all ${isSelected(opt) ? 'bg-primary border-primary text-on-primary shadow-md translate-x-1' : 'bg-surface-container-low border-transparent text-on-surface'}`}
                 >
                   <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${isSelected(opt) ? 'bg-white/20' : 'bg-surface-container-high'}`}>{opt}</span>
                   <span className="text-sm font-medium">Option {opt} Detail Text</span>
                 </button>
               ))}
               <Button 
                variant="text" 
                onClick={() => setAnswers({...answers, [q.id]: undefined})} 
                className="w-fit text-xs self-end opacity-60"
              >
                Clear Selection
              </Button>
             </div>
           ) : (
             <div className="space-y-4">
               <p className="text-xs font-bold text-on-surface-variant">TYPE YOUR ANSWER</p>
               <input 
                 type="number"
                 placeholder="0"
                 className="w-full text-center text-4xl font-bold py-6 bg-surface-container-high rounded-[28px] outline-none text-primary border-4 border-transparent focus:border-primary/20"
                 value={answers[q.id] || ''}
                 onChange={(e) => setAnswers({...answers, [q.id]: e.target.value})}
               />
               <p className="text-center text-[10px] opacity-50 uppercase font-bold">Only integers allowed</p>
             </div>
           )}
        </div>
      </main>

      {/* Fixed Bottom Controls */}
      <footer className="fixed bottom-0 w-full bg-surface-container px-4 py-4 border-t border-surface-variant flex items-center gap-3 z-30">
        <Button 
          variant="outline" 
          className="!px-3 !py-3 bg-white"
          onClick={() => {
            const newMarked = new Set(markedForReview);
            if (newMarked.has(q.id)) newMarked.delete(q.id);
            else newMarked.add(q.id);
            setMarkedForReview(newMarked);
          }}
        >
          <Bookmark className={`w-6 h-6 ${markedForReview.has(q.id) ? 'fill-primary text-primary' : ''}`} />
        </Button>
        <Button 
          variant="tonal" 
          disabled={currentIdx === 0}
          onClick={() => setCurrentIdx(prev => prev - 1)}
          className="flex-1"
        >
          PREV
        </Button>
        <Button 
          variant="primary" 
          disabled={currentIdx === questions.length - 1}
          onClick={() => setCurrentIdx(prev => prev + 1)}
          className="flex-1"
        >
          NEXT
        </Button>
      </footer>

      {/* Navigation Grid Modal */}
      {showGrid && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end animate-in fade-in duration-200">
           <div className="w-full bg-surface rounded-t-[32px] p-6 space-y-4 animate-in slide-in-from-bottom duration-300">
              <div className="flex items-center justify-between">
                 <h3 className="font-bold text-lg">{activeTab} Question Grid</h3>
                 <button onClick={() => setShowGrid(false)} className="p-2"><Grid className="w-5 h-5" /></button>
              </div>
              <div className="grid grid-cols-6 gap-2 m3-scroll-hide overflow-y-auto max-h-[60vh]">
                 {questions.map((item, i) => {
                    const isAns = !!answers[item.id];
                    const isReview = markedForReview.has(item.id);
                    return (
                      <button 
                        key={item.id}
                        onClick={() => {
                          setCurrentIdx(i);
                          setShowGrid(false);
                        }}
                        className={`w-full aspect-square rounded-xl text-xs font-bold transition-all ${
                          currentIdx === i ? 'ring-2 ring-primary ring-offset-2' : ''
                        } ${
                          isReview ? 'bg-tertiary text-on-tertiary' :
                          isAns ? 'bg-primary text-on-primary' : 'bg-surface-container-high text-on-surface-variant'
                        }`}
                      >
                        {i + 1}
                      </button>
                    )
                 })}
              </div>
              <div className="flex flex-wrap gap-4 text-[10px] font-bold pt-4">
                 <div className="flex items-center gap-1"><div className="w-3 h-3 bg-primary rounded-sm" /> ANSWERED</div>
                 <div className="flex items-center gap-1"><div className="w-3 h-3 bg-tertiary rounded-sm" /> REVIEW</div>
                 <div className="flex items-center gap-1"><div className="w-3 h-3 bg-surface-container-high rounded-sm" /> NOT VISITED</div>
              </div>
              <Button onClick={() => setShowGrid(false)} className="w-full">CLOSE GRID</Button>
           </div>
        </div>
      )}
    </div>
  );
}
