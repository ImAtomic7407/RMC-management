import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Button, Card, Badge } from '../../components/ui/M3Components';
import { 
  ArrowLeft, Play, ShieldAlert, CheckCircle2, QrCode, Users, ListFilter, 
  HelpCircle, AlertTriangle, FileSpreadsheet, Sparkles, RefreshCw
} from 'lucide-react';

export default function ExamControlScreen({ examId, onBack, onOpenScanner, onOpenSessions }: { 
  examId: string, 
  onBack: () => void, 
  onOpenScanner: () => void, 
  onOpenSessions: () => void 
}) {
  const { controlledExams, setControlledExams, gateSessions, setGateSessions, studentGateState, setStudentGateState } = useAppContext();
  const exam = controlledExams.find(e => e.id === examId) || controlledExams[0];

  const [simAlert, setSimAlert] = useState<string | null>(null);

  const stats = {
    total: gateSessions.length,
    waiting: gateSessions.filter(s => s.gateStatus === 'WAITING').length,
    verified: gateSessions.filter(s => s.gateStatus === 'VERIFIED').length,
    ready: gateSessions.filter(s => s.paperDownloadStatus === 'READY').length,
    attempting: gateSessions.filter(s => s.attemptStatus === 'ATTEMPTING').length,
    submitted: gateSessions.filter(s => s.attemptStatus === 'SUBMITTED').length,
    violations: gateSessions.reduce((acc, s) => acc + s.violationCount, 0),
  };

  const handleStartExam = () => {
    setControlledExams(prev => prev.map(e => e.id === examId ? { ...e, status: 'LIVE' } : e));
    triggerAlert("Controlled Exam center is now LIVE! Answers are unlocked for verified students.");
  };

  const handleCloseExam = () => {
    setControlledExams(prev => prev.map(e => e.id === examId ? { ...e, status: 'CLOSED' } : e));
    triggerAlert("Live attempt closed. Students can no longer submit.");
  };

  const handleReleaseResult = () => {
    setControlledExams(prev => prev.map(e => e.id === examId ? { ...e, status: 'RESULT_RELEASED' } : e));
    triggerAlert("Result Released! Students can now review scoring & detailed solution keys.");
  };

  const triggerAlert = (msg: string) => {
    setSimAlert(msg);
    setTimeout(() => setSimAlert(null), 4000);
  };

  // State stateful simulations for student
  const simulateStudentVerification = () => {
    // Force student status to waiting room
    setStudentGateState(prev => ({
      ...prev,
      status: 'WAITING_ROOM',
      verified: true,
      paperDownloaded: 'NOT',
      percent: 0
    }));

    // Update Rohan Kumar's status in gateSessions to verified
    setGateSessions(prev => prev.map(s => s.student.id === 's1' ? {
      ...s,
      gateStatus: 'VERIFIED',
      deviceStatus: 'BOUND'
    }: s));

    triggerAlert("SUCCESS: Rohan Kumar (Current Student) verified via QR Gate!");
  };

  const simulateDownloadReady = () => {
    setStudentGateState(prev => ({
      ...prev,
      paperDownloaded: 'READY',
      percent: 100
    }));

    setGateSessions(prev => prev.map(s => s.student.id === 's1' ? {
      ...s,
      paperDownloadStatus: 'READY'
    }: s));

    triggerAlert("SUCCESS: Paper package decrypted & cached for current student!");
  };

  const simulateViolation = () => {
    setStudentGateState(prev => {
      const nextCount = prev.violationCount + 1;
      return {
        ...prev,
        violationCount: nextCount,
        showViolationWarning: true,
        violationReason: nextCount === 1 ? 'App switched to Background' : nextCount === 2 ? 'Multi-window/Overlay detected' : 'Screenshots Attempted'
      };
    });

    setGateSessions(prev => prev.map(s => s.student.id === 's1' ? {
      ...s,
      violationCount: s.violationCount + 1
    }: s));

    triggerAlert("ALERT: Security Violation triggered for current student!");
  };

  const simulateSubmit = () => {
    setStudentGateState(prev => ({
      ...prev,
      status: 'SUBMITTED'
    }));

    setGateSessions(prev => prev.map(s => s.student.id === 's1' ? {
      ...s,
      attemptStatus: 'SUBMITTED'
    }: s));

    triggerAlert("SUCCESS: Secured attempt auto-submitted and synchronized!");
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col pb-24">
      {/* Alert Banner */}
      {simAlert && (
        <div className="bg-primary text-on-primary px-4 py-3 text-center text-xs font-bold font-mono tracking-wide flex items-center justify-center gap-2 animate-slide-up sticky top-0 z-50 shadow-md">
          <Sparkles className="w-4 h-4" /> {simAlert}
        </div>
      )}

      {/* Header */}
      <header className="px-4 py-4 border-b border-surface-variant/40 flex items-center justify-between sticky top-[40px] bg-surface/90 backdrop-blur-md z-30">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-on-surface truncate max-w-[180px]">{exam.title}</h1>
            <p className="text-[10px] font-mono text-on-surface-variant font-bold">CONTROL CENTER · {exam.versionNumber}</p>
          </div>
        </div>
        <Badge variant={exam.status === 'LIVE' ? 'error' : exam.status === 'RESULT_RELEASED' ? 'success' : 'warning'}>
          {exam.status}
        </Badge>
      </header>

      {/* Main Stats Panel */}
      <div className="p-4 space-y-4">
        {/* Info Grid */}
        <Card className="p-4 bg-surface-container-low border border-surface-variant/20 grid grid-cols-2 gap-y-3 gap-x-2">
          <div>
            <p className="text-[9px] font-bold text-on-surface-variant uppercase tracking-wider">LOCKED QUESTION PAPER</p>
            <p className="text-xs font-bold truncate">JEE Advanced Mock 01 (Draft)</p>
          </div>
          <div>
            <p className="text-[9px] font-bold text-on-surface-variant uppercase tracking-wider">BATCH AUDIENCE</p>
            <p className="text-xs font-bold text-primary">{exam.batch}</p>
          </div>
          <div>
            <p className="text-[9px] font-bold text-on-surface-variant uppercase tracking-wider">DURATION</p>
            <p className="text-xs font-bold">{exam.duration / 3600} Hours (180 mins)</p>
          </div>
          <div>
            <p className="text-[9px] font-bold text-on-surface-variant uppercase tracking-wider">TOTAL SECTIONS</p>
            <p className="text-xs font-bold text-tertiary">PHY / CHEM / MATHS</p>
          </div>
        </Card>

        {/* Dashboard Stat Grid */}
        <div>
          <h2 className="text-xs font-bold text-on-surface-variant px-2 uppercase tracking-wide mb-2 flex justify-between items-center">
            <span>Center Attendance Dashboard</span>
            <span className="text-[10px] text-primary lowercase">realtime active</span>
          </h2>
          <div className="grid grid-cols-3 gap-2">
            <StatBox label="Waiting Gate" count={stats.waiting} color="text-secondary" />
            <StatBox label="Verified/In" count={stats.verified} color="text-success" />
            <StatBox label="Paper Ready" count={stats.ready} color="text-primary" />
            <StatBox label="Attempting" count={stats.attempting} color="text-error" />
            <StatBox label="Submitted" count={stats.submitted} color="text-on-surface" />
            <StatBox label="Violations" count={stats.violations} color="text-error font-extrabold animate-pulse" />
          </div>
        </div>

        {/* Primary Controls */}
        <div className="space-y-2 pt-2">
          {exam.status === 'SCHEDULED' && (
            <Button onClick={handleStartExam} className="w-full py-3.5 bg-primary text-on-primary font-bold flex items-center justify-center gap-2 rounded-2xl">
              <Play className="fill-current w-4 h-4" /> START EXAM CENTER
            </Button>
          )}

          {exam.status === 'LIVE' && (
            <Button onClick={handleCloseExam} variant="danger" className="w-full py-3.5 bg-error text-on-error font-bold flex items-center justify-center gap-2 rounded-2xl">
              <ShieldAlert className="w-4 h-4" /> CLOSE EXAM ATTEMPT
            </Button>
          )}

          {exam.status === 'CLOSED' && (
            <Button onClick={handleReleaseResult} className="w-full py-3.5 bg-green-700 text-white font-bold flex items-center justify-center gap-2 rounded-2xl hover:bg-green-800">
              <CheckCircle2 className="w-4 h-4" /> RELEASE OFFICAL RESULTS
            </Button>
          )}
        </div>

        {/* Mobile Camera Scanner & Attendance Gate Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <Button onClick={onOpenScanner} variant="tonal" className="py-3 flex items-center justify-center gap-2 rounded-xl text-xs font-bold">
            <QrCode className="w-4 h-4" /> QR GATE CAMERA
          </Button>
          <Button onClick={onOpenSessions} variant="outline" className="py-3 flex items-center justify-center gap-2 rounded-xl text-xs font-bold">
            <Users className="w-4 h-4" /> GATE CONTROLLER
          </Button>
        </div>

        {/* ==========================================
            LIVE DEMO PROTOTYPE STATE CONTROLLERS
            ========================================== */}
        <Card className="p-4 bg-tertiary-container/10 border-2 border-dashed border-tertiary-container mt-6 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-tertiary">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>EXAM CENTER SIMULATOR ENGINE</span>
          </div>
          <p className="text-[10px] text-on-surface-variant leading-tight">
            Use these controls to simulate high-fidelity student actions. Open the app as "Student" in another tab or switch roles to view the synced state!
          </p>
          <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[9px]">
            <button onClick={simulateStudentVerification} className="bg-secondary-container text-on-secondary-container p-2.5 rounded-xl text-left border border-secondary font-bold">
              ⚡ Verified QR Gate (Rohan)
            </button>
            <button onClick={simulateDownloadReady} className="bg-primary-container text-on-primary-container p-2.5 rounded-xl text-left border border-primary font-bold">
              📦 Decrypt Paper (Rohan)
            </button>
            <button onClick={simulateViolation} className="bg-error-container text-on-error-container p-2.5 rounded-xl text-left border border-error font-bold col-span-2">
              🚨 Trigger Security Violation Alert (Warning warning)
            </button>
            <button onClick={simulateSubmit} className="bg-surface-container-high text-on-surface p-2.5 rounded-xl text-left border border-outline font-bold col-span-2 text-center">
              ✓ Force Student Auto-Submit Form
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

const StatBox = ({ label, count, color = "" }: { label: string, count: number, color?: string }) => (
  <div className="bg-surface-container-low border border-surface-variant/30 p-2 text-center rounded-2xl">
    <p className="text-[9px] font-bold text-on-surface-variant truncate uppercase">{label}</p>
    <p className={`text-lg font-bold ${color}`}>{count}</p>
  </div>
);
