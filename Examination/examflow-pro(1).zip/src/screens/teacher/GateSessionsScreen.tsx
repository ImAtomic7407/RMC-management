import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Card, Badge, Button } from '../../components/ui/M3Components';
import { 
  ArrowLeft, Search, Filter, ShieldAlert, CheckCircle, RefreshCw, 
  Trash2, AlertTriangle, CloudDownload, Laptop, LogIn, Sparkles
} from 'lucide-react';

export default function GateSessionsScreen({ examId, onBack }: { examId: string, onBack: () => void }) {
  const { gateSessions, setGateSessions, studentGateState, setStudentGateState } = useAppContext();
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'WAITING' | 'VERIFIED' | 'READY' | 'VIOLATIONS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filterChips = [
    { id: 'ALL', label: 'All Sessions' },
    { id: 'WAITING', label: 'Waiting Scan' },
    { id: 'VERIFIED', label: 'Verified Gate' },
    { id: 'READY', label: 'Variants Ready' },
    { id: 'VIOLATIONS', label: 'Violations' }
  ];

  const handleResetSession = (uid: string) => {
    setGateSessions(prev => prev.map(s => {
      if (s.student.uid === uid) {
        return {
          ...s,
          gateStatus: 'WAITING',
          paperDownloadStatus: 'NOT_STARTED',
          attemptStatus: 'WAITING',
          violationCount: 0
        };
      }
      return s;
    }));

    if (uid === 'JEE26-041') {
      // Reset Rohan
      setStudentGateState({
        status: 'SHOWING_QR',
        verified: false,
        paperDownloaded: 'NOT',
        percent: 0,
        violationCount: 0,
        showViolationWarning: false,
        violationReason: '',
        answers: {},
        marked: new Set(),
        currentExamId: 'ce1'
      });
    }
  };

  const handleManualVerify = (uid: string) => {
    setGateSessions(prev => prev.map(s => {
      if (s.student.uid === uid) {
        return {
          ...s,
          gateStatus: 'VERIFIED',
          deviceStatus: 'BOUND',
          paperDownloadStatus: 'READY'
        };
      }
      return s;
    }));

    if (uid === 'JEE26-041') {
      // Rohan
      setStudentGateState((prev: any) => ({
        ...prev,
        status: 'WAITING_ROOM',
        verified: true,
        paperDownloaded: 'READY',
        percent: 100
      }));
    }
  };

  const filteredSessions = gateSessions.filter(s => {
    // Search filter
    const matchesSearch = s.student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          s.student.uid.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;

    // Filter type
    if (activeFilter === 'WAITING') return s.gateStatus === 'WAITING';
    if (activeFilter === 'VERIFIED') return s.gateStatus === 'VERIFIED';
    if (activeFilter === 'READY') return s.paperDownloadStatus === 'READY';
    if (activeFilter === 'VIOLATIONS') return s.violationCount > 0;
    return true;
  });

  return (
    <div className="min-h-screen bg-surface flex flex-col pb-20">
      {/* Header */}
      <header className="px-4 py-4 border-b border-surface-variant/40 flex items-center justify-between sticky top-0 bg-surface/90 backdrop-blur-md z-30">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-on-surface">Gate Session Monitor</h1>
            <p className="text-[10px] text-on-surface-variant">Realtime examination security logs & attendance</p>
          </div>
        </div>
        <button 
          onClick={() => {
            // refresh
          }}
          className="p-2.5 bg-surface-container-high rounded-full hover:rotate-180 duration-500"
        >
          <RefreshCw className="w-4 h-4 text-primary" />
        </button>
      </header>

      {/* Filter and Search */}
      <div className="p-4 space-y-3 bg-surface sticky top-[68px] z-20 shadow-sm border-b border-surface-variant/30">
        <div className="flex items-center gap-2 bg-surface-container px-3 py-2.5 rounded-2xl">
          <Search className="w-4 h-4 text-on-surface-variant/60" />
          <input 
            type="text" 
            placeholder="Search student code or name..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-xs text-on-surface"
          />
        </div>

        {/* Filter Scrollable Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1.5 m3-scroll-hide">
          {filterChips.map((chip) => (
            <button
              key={chip.id}
              onClick={() => setActiveFilter(chip.id as any)}
              className={`px-4 py-2 rounded-xl text-[10px] font-bold shrink-0 transition-all ${
                activeFilter === chip.id ? 'bg-primary text-on-primary' : 'bg-surface-container-low border border-outline/10 text-on-surface-variant'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Gate Card Student List */}
      <div className="p-4 space-y-3 flex-1 overflow-y-auto">
        {filteredSessions.length === 0 ? (
          <div className="py-20 text-center opacity-40 italic text-xs">No active gate sessions found</div>
        ) : (
          filteredSessions.map((session) => {
            const student = session.student;
            return (
              <Card key={student.uid} className="p-4 space-y-3 border border-surface-variant/25">
                <div className="flex gap-3 justify-between">
                  <div className="flex gap-3 items-center">
                    <img 
                      src={student.photoUrl} 
                      alt={student.name} 
                      className="w-10 h-10 rounded-full border border-primary/20 object-cover" 
                    />
                    <div>
                      <h4 className="font-bold text-xs">{student.name}</h4>
                      <p className="font-mono text-[9px] text-on-surface-variant uppercase">{student.uid} · ID: {student.deviceId}</p>
                    </div>
                  </div>

                  <div className="text-right flex flex-col gap-1 items-end">
                    <Badge variant={session.gateStatus === 'VERIFIED' ? 'success' : session.gateStatus === 'DENIED' ? 'error' : 'info'}>
                      GATE: {session.gateStatus}
                    </Badge>
                    {session.violationCount > 0 && (
                      <span className="bg-red-100 text-red-800 text-[8px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                        <AlertTriangle className="w-2.5 h-2.5 text-error" /> {session.violationCount} Violations
                      </span>
                    )}
                  </div>
                </div>

                {/* Sub status row */}
                <div className="grid grid-cols-2 gap-2 text-[10px] bg-surface-container-low p-2.5 rounded-xl text-on-surface-variant">
                   <div className="flex items-center gap-1.5">
                     <Laptop className="w-3.5 h-3.5 opacity-70" />
                     <span>Device: <strong className="font-bold text-on-surface">{session.deviceStatus}</strong></span>
                   </div>
                   <div className="flex items-center gap-1.5">
                     <CloudDownload className="w-3.5 h-3.5 opacity-70" />
                     <span>Package: <strong className="font-bold text-primary">{session.paperDownloadStatus}</strong></span>
                   </div>
                   <div className="flex items-center gap-1.5 col-span-2">
                     <LogIn className="w-3.5 h-3.5 opacity-70" />
                     <span>Attempt Status: <strong className="font-bold text-on-surface">{session.attemptStatus}</strong></span>
                   </div>
                </div>

                {/* Quick action buttons */}
                <div className="flex gap-2 justify-end pt-1">
                   {session.gateStatus === 'WAITING' ? (
                     <Button 
                       onClick={() => handleManualVerify(student.uid)} 
                       variant="tonal" 
                       className="!px-3 !py-1 text-[9px] font-bold"
                     >
                       MANUAL OVERRIDE ENTRY
                     </Button>
                   ) : (
                     <Button 
                       onClick={() => handleResetSession(student.uid)} 
                       variant="outline" 
                       className="!px-3 !py-1 text-[9px] font-bold text-error border-error-container hover:bg-error-container/10"
                     >
                       RESET/VACATE ENTRY
                     </Button>
                   )}
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
