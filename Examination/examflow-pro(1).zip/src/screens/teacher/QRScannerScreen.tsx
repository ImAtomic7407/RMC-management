import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Button, Card, Badge } from '../../components/ui/M3Components';
import { ArrowLeft, User, QrCode, Monitor, CheckCircle, AlertOctagon, HelpCircle, Sparkles, Send } from 'lucide-react';

export default function QRScannerScreen({ examId, onBack }: { examId: string, onBack: () => void }) {
  const { gateSessions, setGateSessions, studentGateState, setStudentGateState } = useAppContext();

  // Selected student to simulate scanning
  const [selectedStudentIndex, setSelectedStudentIndex] = useState(0);
  const [pastedCode, setPastedCode] = useState('');
  const [scanResult, setScanResult] = useState<any>(null);
  const [alertMsg, setAlertMsg] = useState<any>(null);

  const availableStudentsToScan = [
    { name: 'Rohan Kumar', uid: 'JEE26-041', deviceId: 'DEV-9801X', error: null },
    { name: 'Priya Singh', uid: 'JEE26-112', deviceId: 'DEV-2234Y', error: 'ALREADY_VERIFIED' },
    { name: 'Unknown Attempter', uid: 'NEET25-999', deviceId: 'DEV-9090W', error: 'STUDENT_NOT_ASSIGNED' },
    { name: 'Aman Raj', uid: 'JEE26-330', deviceId: 'DEV-MISMATCH-999', error: 'DEVICE_MISMATCH' },
    { name: 'Sneha Kumari', uid: 'JEE26-019', deviceId: 'DEV-IJK22', error: 'EXPIRED' }
  ];

  const handleSimulateScan = (index: number) => {
    const student = availableStudentsToScan[index];
    setScanResult({
      studentName: student.name,
      uid: student.uid,
      examId,
      deviceId: student.deviceId,
      expiry: student.error === 'EXPIRED' ? 'Expired (15 min ago)' : 'Valid (Expires in 4:59)',
      error: student.error
    });
  };

  const handleManualPaste = () => {
    if (!pastedCode) return;
    setScanResult({
      studentName: 'Custom Pasted Student',
      uid: pastedCode,
      examId,
      deviceId: 'DEV-PASTE-X4',
      expiry: 'Valid',
      error: null
    });
  };

  const handleVerifyStudent = () => {
    if (!scanResult) return;

    if (scanResult.error) {
      setAlertMsg({ type: 'error', text: `Verification Denied: ${scanResult.error}` });
      return;
    }

    // Success flow - update the gate sessions lists
    setGateSessions(prev => prev.map(s => {
      if (s.student.uid === scanResult.uid) {
        return {
          ...s,
          gateStatus: 'VERIFIED',
          deviceStatus: 'BOUND',
          paperDownloadStatus: 'DOWNLOADING' // Starts download instantly
        };
      }
      return s;
    }));

    if (scanResult.uid === 'JEE26-041') {
      // Rohan
      setStudentGateState((prev: any) => ({
        ...prev,
        status: 'WAITING_ROOM',
        verified: true,
        paperDownloaded: 'DOWNLOADING',
        percent: 30
      }));

      // Simulate download progress
      setTimeout(() => {
        setStudentGateState((prev: any) => {
          if (prev.paperDownloaded === 'DOWNLOADING') {
            return { ...prev, paperDownloaded: 'READY', percent: 100 };
          }
          return prev;
        });

        setGateSessions(prev => prev.map(s => {
          if (s.student.id === 's1') {
            return { ...s, paperDownloadStatus: 'READY' };
          }
          return s;
        }));
      }, 3000);
    }

    setAlertMsg({ type: 'success', text: `Verified successfully! Rohan's Secure Exam package unlocked.` });
    setTimeout(() => {
      onBack();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Header */}
      <header className="px-4 py-4 border-b border-surface-variant/40 flex items-center justify-between bg-surface">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-surface-container-high transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-on-surface">Secure QR Scanner</h1>
            <p className="text-[10px] text-on-surface-variant">Verify student gate identity & device signature</p>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 space-y-4 overflow-y-auto pb-24">
        {alertMsg && (
          <div className={`p-4 rounded-2xl text-xs font-bold leading-tight flex items-center gap-2 ${
            alertMsg.type === 'success' ? 'bg-green-100 text-green-900 border border-green-300' : 'bg-red-100 text-red-900 border border-red-300'
          }`}>
            <Sparkles className="w-4 h-4" /> {alertMsg.text}
          </div>
        )}

        {/* Camera Scanner Simulation viewport */}
        <div className="relative w-full aspect-square bg-black rounded-[36px] overflow-hidden flex flex-col items-center justify-center p-6 shadow-inner">
          {/* Animated Matrix scan line */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent shadow-md animate-bounce" style={{ animationDuration: '3s' }} />

          {/* Hologram Box */}
          <div className="relative w-2/3 aspect-square border-4 border-dashed border-primary/60 rounded-3xl flex items-center justify-center">
             <QrCode className="w-16 h-16 text-primary/30 animate-pulse" />
             <div className="absolute -top-2 -left-2 w-6 h-6 border-t-4 border-l-4 border-primary rounded-tl-md" />
             <div className="absolute -top-2 -right-2 w-6 h-6 border-t-4 border-r-4 border-primary rounded-tr-md" />
             <div className="absolute -bottom-2 -left-2 w-6 h-6 border-b-4 border-l-4 border-primary rounded-bl-md" />
             <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-4 border-r-4 border-primary rounded-br-md" />
          </div>

          <div className="absolute bottom-4 left-0 right-0 text-center">
             <Badge variant="error" className="bg-red-600/20 text-red-400 font-mono text-[9px] px-3">SIMULATED CAMERA FEED ACTIVE</Badge>
          </div>
        </div>

        {/* Simulated scanning select */}
        <Card className="p-4 bg-surface-container-low border border-surface-variant text-xs space-y-3">
          <p className="font-bold text-on-surface flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" /> Simulation Scanner Trigger</p>
          <div className="grid grid-cols-2 gap-2">
            {availableStudentsToScan.map((s, idx) => (
              <button 
                key={s.uid} 
                onClick={() => handleSimulateScan(idx)}
                className="bg-surface-container-high hover:bg-primary-container hover:text-on-primary-container p-2.5 rounded-xl border border-outline/15 text-left text-[10px] font-bold"
              >
                {s.name} {s.error ? `(${s.error})` : ''}
              </button>
            ))}
          </div>

          <div className="flex gap-2 items-center pt-2 border-t border-surface-variant/30">
            <input 
              type="text" 
              placeholder="Or paste Student UID UID..." 
              value={pastedCode}
              onChange={(e) => setPastedCode(e.target.value)}
              className="flex-1 bg-surface py-2 px-3 rounded-lg text-[10px] outline-none border border-outline/30"
            />
            <Button onClick={handleManualPaste} variant="tonal" className="!p-2">
              <Send className="w-3 h-3" />
            </Button>
          </div>
        </Card>

        {/* Parsed QR preview card */}
        {scanResult && (
          <Card className="p-5 bg-surface-container border border-surface-variant/50 space-y-4">
            <div className="flex justify-between items-center">
               <h3 className="font-bold text-sm text-primary">Signature Captured</h3>
               <Badge variant={scanResult.error ? 'error' : 'success'}>
                  {scanResult.error ? 'DENIED' : 'VERIFIED'}
               </Badge>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="col-span-2">
                 <p className="text-[9px] text-on-surface-variant uppercase font-bold">Student Name</p>
                 <p className="font-bold text-sm text-on-surface flex items-center gap-1">
                   <User className="w-4 h-4 text-on-surface-variant" /> {scanResult.studentName}
                 </p>
              </div>
              <div>
                 <p className="text-[9px] text-on-surface-variant uppercase font-bold">Student UID</p>
                 <p className="font-mono font-bold text-on-surface">{scanResult.uid}</p>
              </div>
              <div>
                 <p className="text-[9px] text-on-surface-variant uppercase font-bold">Active Device ID</p>
                 <p className="font-mono font-bold text-on-surface flex items-center gap-1">
                   <Monitor className="w-3.5 h-3.5 text-on-surface-variant" /> {scanResult.deviceId}
                 </p>
              </div>
              <div className="col-span-2">
                 <p className="text-[9px] text-on-surface-variant uppercase font-bold">QR Expiry Status</p>
                 <p className="font-bold text-on-surface">{scanResult.expiry}</p>
              </div>
            </div>

            {scanResult.error ? (
              <div className="bg-red-100 text-red-900 duration-200 border border-red-200 p-3 rounded-xl text-xs space-y-1">
                <p className="font-bold flex items-center gap-1.5"><AlertOctagon className="w-4 h-4" /> ERROR CODE: {scanResult.error}</p>
                <p className="text-[10px] leading-relaxed opacity-90">
                  {scanResult.error === 'EXPIRED' && 'Security token expired. Ask student to generate a fresh QR in student dashboard.'}
                  {scanResult.error === 'DEVICE_MISMATCH' && 'Device ID signature differs from pre-bound student account! Denying gate entry.'}
                  {scanResult.error === 'STUDENT_NOT_ASSIGNED' && 'This student is not registered/assigned to this batch exams. No variant found.'}
                  {scanResult.error === 'ALREADY_VERIFIED' && 'This student token is already verified. Gate entry completed.'}
                </p>
              </div>
            ) : (
              <div className="bg-green-100 text-green-900 border border-green-200 p-3 rounded-xl text-xs space-y-1">
                 <p className="font-bold flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-700" /> Identity Secure & Clear</p>
                 <p className="text-[10px] opacity-90">Device bound signature verified. Click verification button to unlock student variant decryption package.</p>
              </div>
            )}

            <Button onClick={handleVerifyStudent} className="w-full py-3.5 text-xs font-bold font-mono">
               PROCESS STUDENT GATE PASS
            </Button>
          </Card>
        )}
      </main>
    </div>
  );
}
