import React, { useState } from 'react';
import { BookOpen, HelpCircle, Image as ImageIcon, CheckCircle2, MoreVertical, Plus } from 'lucide-react';
import { Button, Card, Tabs, Badge } from '../../components/ui/M3Components';
import { Paper, QuestionType } from '../../types';

export default function PaperEditor({ paper, onBack }: { paper: Paper, onBack: () => void }) {
  const [activeSection, setActiveSection] = useState<'PHYSICS' | 'CHEMISTRY' | 'MATHS'>('PHYSICS');
  const [editingQuestion, setEditingQuestion] = useState<any>(null);

  const sections = [
    { id: 'PHYSICS', label: 'Physics' },
    { id: 'CHEMISTRY', label: 'Chemistry' },
    { id: 'MATHS', label: 'Maths' },
  ];

  const currentQuestions = paper.questions.filter(q => q.section === activeSection);
  const sectionConfig = paper.sections[activeSection];

  if (editingQuestion) {
    return <QuestionEditorScreen 
      type={editingQuestion.type} 
      section={activeSection} 
      number={currentQuestions.length + 1}
      onSave={() => setEditingQuestion(null)}
      onCancel={() => setEditingQuestion(null)}
    />;
  }

  return (
    <div className="min-h-screen bg-surface">
      <header className="p-4 border-b border-surface-variant flex items-center justify-between bg-surface sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Button variant="text" onClick={onBack} className="!p-2 -ml-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </Button>
          <div>
            <h1 className="font-bold truncate max-w-[200px]">{paper.title}</h1>
            <p className="text-xs text-on-surface-variant">{paper.batch}</p>
          </div>
        </div>
        <Badge variant={paper.status === 'PUBLISHED' ? 'success' : 'info'}>{paper.status}</Badge>
      </header>

      <div className="sticky top-[68px] bg-surface z-10 px-4 py-3 shadow-sm">
        <div className="flex items-center justify-between gap-4">
           <Tabs items={sections as any} activeTab={activeSection} onChange={(id) => setActiveSection(id as any)} />
           <div className="text-right">
             <p className="text-[10px] font-bold text-on-surface-variant uppercase">Progress</p>
             <p className="text-sm font-bold text-primary">{currentQuestions.length}/{sectionConfig.targetCount}</p>
           </div>
        </div>
      </div>

      <div className="p-4 space-y-4 pb-32">
        {currentQuestions.length === 0 ? (
          <div className="py-20 text-center space-y-2 opacity-50">
            <HelpCircle className="w-12 h-12 mx-auto" />
            <p>No questions added to {activeSection} yet</p>
          </div>
        ) : (
          currentQuestions.map((q, idx) => (
            <Card key={q.id} className="p-4 space-y-2 border border-outline/5">
              <div className="flex justify-between">
                <span className="text-xs font-bold text-on-surface-variant">Question {idx + 1}</span>
                <div className="flex gap-2">
                   <Badge variant="info">{q.type}</Badge>
                   <button className="text-on-surface-variant"><MoreVertical className="w-4 h-4" /></button>
                </div>
              </div>
              <p className="text-sm line-clamp-2">{q.text || 'No text content'}</p>
              <div className="flex gap-4 pt-2 border-t border-surface-variant/20">
                <MediaBadge icon={ImageIcon} label="Question" active={true} />
                <MediaBadge icon={CheckCircle2} label="Solution" active={false} />
                <div className="flex-1 text-right">
                   <span className="text-xs font-bold text-primary">Key: {q.type === 'MCQ' ? 'A' : (q.correctInteger || '-')}</span>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Floating Add Menu */}
      <div className="fixed bottom-6 right-6 flex flex-col items-end gap-3 z-30">
        <div className="flex items-center gap-2 group">
          <span className="bg-surface-container-high px-3 py-1 rounded-lg text-xs font-bold shadow-sm group-hover:block transition-all">ADD INTEGER</span>
          <button 
            onClick={() => setEditingQuestion({ type: 'INTEGER' })}
            className="w-12 h-12 bg-secondary-container text-on-secondary-container rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-all font-bold"
          >
            123
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span className="bg-surface-container-high px-3 py-1 rounded-lg text-xs font-bold shadow-sm">ADD MCQ</span>
          <button 
            onClick={() => setEditingQuestion({ type: 'MCQ' })}
            className="w-14 h-14 bg-primary text-on-primary rounded-2xl flex items-center justify-center shadow-lg active:scale-95 transition-all"
          >
            <Plus className="w-8 h-8" />
          </button>
        </div>
      </div>
    </div>
  );
}

const MediaBadge = ({ icon: Icon, label, active }: any) => (
  <div className={`flex items-center gap-1 ${active ? 'text-primary' : 'text-on-surface-variant opacity-40'}`}>
    <Icon className="w-3.5 h-3.5" />
    <span className="text-[10px] font-bold uppercase tracking-tight">{label}</span>
  </div>
);

function QuestionEditorScreen({ type, section, number, onSave, onCancel }: any) {
  const [correctOption, setCorrectOption] = useState('A');
  const [hasImage, setHasImage] = useState(false);

  return (
    <div className="min-h-screen bg-surface flex flex-col animate-in slide-in-from-bottom duration-300">
      <header className="p-4 border-b border-surface-variant flex items-center justify-between bg-surface shadow-sm">
        <div className="flex items-center gap-3">
          <Button variant="text" onClick={onCancel} className="!p-1">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </Button>
          <div className="flex gap-2 items-center">
            <h1 className="font-bold text-lg">Add {type}</h1>
            <span className="text-xs bg-surface-container-high px-2 py-0.5 rounded-full text-on-surface-variant">{section} · Q{number}</span>
          </div>
        </div>
        <Button onClick={onSave} className="font-bold">SAVE</Button>
      </header>

      <main className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Question Area */}
        <div className="space-y-3">
          <div 
             onClick={() => setHasImage(!hasImage)}
             className={`w-full h-40 border-2 border-dashed rounded-[28px] flex flex-col items-center justify-center gap-2 transition-all ${hasImage ? 'bg-primary-container/20 border-primary text-primary' : 'bg-surface-container-low border-outline/20 text-on-surface-variant'}`}
          >
            {hasImage ? (
              <div className="flex flex-col items-center">
                <CheckCircle2 className="w-10 h-10 mb-2" />
                <span className="text-sm font-bold">QUESTION IMAGE SELECTED</span>
                <span className="text-[10px] opacity-70">Tap to remove image</span>
              </div>
            ) : (
              <>
                <ImageIcon className="w-10 h-10 opacity-30" />
                <div className="flex gap-4">
                  <span className="text-sm font-bold">UPLOAD IMAGE</span>
                  <span className="text-sm font-bold">TAKE PHOTO</span>
                </div>
              </>
            )}
          </div>
          <textarea 
            placeholder="Optional short question text..." 
            className="w-full bg-surface-container-low p-4 rounded-2xl outline-none min-h-[80px] text-sm"
          />
        </div>

        {/* Answer Key */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-on-surface-variant px-2 uppercase tracking-wide">Answer Key</h3>
          {type === 'MCQ' ? (
            <div className="grid gap-3">
              {['A', 'B', 'C', 'D'].map(opt => (
                <div key={opt} className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl flex-1 flex items-center justify-between border-2 transition-all ${correctOption === opt ? 'bg-primary-container border-primary' : 'bg-surface-container border-transparent'}`}>
                    <div className="flex items-center gap-3">
                       <span className={`font-bold w-6 h-6 rounded-lg flex items-center justify-center ${correctOption === opt ? 'bg-primary text-on-primary' : 'bg-secondary-container text-on-secondary-container'}`}>{opt}</span>
                       <input disabled placeholder="Optional text..." className="bg-transparent text-sm w-full outline-none" />
                    </div>
                    <button 
                      onClick={() => setCorrectOption(opt)}
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${correctOption === opt ? 'bg-primary border-primary' : 'border-outline/50'}`}
                    >
                      {correctOption === opt && <div className="w-2 h-2 bg-white rounded-full" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-surface-container rounded-[28px] p-6 text-center space-y-3 border-2 border-primary/20">
               <p className="text-xs font-bold text-on-surface-variant">CORRECT INTEGER VALUE</p>
               <input 
                 type="number" 
                 placeholder="Enter Answer" 
                 className="text-4xl font-bold w-full text-center bg-transparent outline-none text-primary"
               />
               <p className="text-[10px] opacity-50 italic">e.g., -42, 0, 105 (no decimals)</p>
            </div>
          )}
        </div>

        {/* Solution Image Area */}
        <div className="space-y-3 pt-4 border-t border-surface-variant">
           <h3 className="text-sm font-bold text-on-surface-variant px-2 uppercase tracking-wide">Solution Explanation</h3>
           <div className="w-full h-32 border border-outline/20 bg-surface-container-low rounded-[28px] flex flex-col items-center justify-center gap-1 opacity-60">
              <Plus className="w-6 h-6" />
              <span className="text-xs font-bold">ADD SOLUTION IMAGE</span>
           </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pb-10">
           <Button variant="tonal" onClick={onSave}>SAVE & NEXT</Button>
           <Button onClick={onSave} className="font-bold">FINISH</Button>
        </div>
      </main>
    </div>
  );
}
