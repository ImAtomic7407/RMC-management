import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Button, Card, Badge } from '../components/ui/M3Components';
import { 
  LogOut, Trophy, History, BookOpen, ChevronRight, Zap, 
  ShieldAlert, Sparkles, QrCode, Monitor, CheckCircle, Smartphone 
} from 'lucide-react';

// Import newly created screens
import QRGateScreen from './student/QRGateScreen';
import WaitingRoomScreen from './student/WaitingRoomScreen';
import SecureAttemptScreen from './student/SecureAttemptScreen';
import PostExamReviewScreen from './student/PostExamReviewScreen';
import PracticeIntroScreen from './student/PracticeIntroScreen';

export default function StudentDashboard() {
  const { user, setUser, results, controlledExams, setControlledExams, studentGateState, setStudentGateState } = useAppContext();
  
  // Student views: 'HOME' | 'QR_GATE' | 'WAITING_ROOM' | 'SECURE_ENTRY_RULES' | 'LIVE_SECURE_ATTEMPT' | 'POST_EXAM_REVIEW' | 'PRACTICE_INTRO'
  const [activeScreen, setActiveScreen] = useState<'HOME' | 'QR_GATE' | 'WAITING_ROOM' | 'LIVE_SECURE_ATTEMPT' | 'POST_EXAM_REVIEW' | 'PRACTICE_INTRO'>('HOME');
  const [selectedExam, setSelectedExam] = useState<any>(controlledExams[0]);

  // Handle student clicking the primary CTA on exam cards
  const handleExamClick = (exam: any) => {
    setSelectedExam(exam);

    if (exam.status === 'RESULT_RELEASED') {
      setActiveScreen('POST_EXAM_REVIEW');
      return;
    }

    // Evaluate progress
    if (studentGateState.status === 'NOT_AT' || studentGateState.status === 'SHOWING_QR') {
      setActiveScreen('QR_GATE');
    } else if (studentGateState.status === 'WAITING_ROOM') {
      setActiveScreen('WAITING_ROOM');
    } else {
      setActiveScreen('LIVE_SECURE_ATTEMPT');
    }
  };

  // Callback to force Result Released simulation
  const simulateResultsReleased = () => {
    setControlledExams(prev => prev.map(e => e.id === 'ce1' ? { ...e, status: 'RESULT_RELEASED' } : e));
    alert("SYSTEM: Exam review released! Scroll down to 'My Recent Results' or click JEE Advanced Mock card to review answer keys & solutons.");
  };

  // Nav views router
  if (activeScreen === 'QR_GATE') {
    return (
      <QRGateScreen 
        exam={selectedExam}
        onBack={() => setActiveScreen('HOME')}
        onTriggerVerify={() => {
          setStudentGateState(prev => ({ ...prev, status: 'WAITING_ROOM', verified: true }));
          setActiveScreen('WAITING_ROOM');
        }}
      />
    );
  }

  if (activeScreen === 'WAITING_ROOM') {
    return (
      <WaitingRoomScreen 
        exam={selectedExam}
        onEnterSecureMode={() => {
          setActiveScreen('LIVE_SECURE_ATTEMPT');
        }}
      />
    );
  }

  if (activeScreen === 'LIVE_SECURE_ATTEMPT') {
    return (
      <SecureAttemptScreen 
        onSucceedSubmit={() => {
          setActiveScreen('HOME');
          alert("✓ Secure exam successfully submitted! Wait for supervisor results release.");
        }}
        onBackToLobby={() => {
          setActiveScreen('WAITING_ROOM');
        }}
      />
    );
  }

  if (activeScreen === 'POST_EXAM_REVIEW') {
    return (
      <PostExamReviewScreen 
        exam={selectedExam}
        onBack={() => setActiveScreen('HOME')}
        onOpenPracticeRetake={() => {
          setActiveScreen('PRACTICE_INTRO');
        }}
      />
    );
  }

  if (activeScreen === 'PRACTICE_INTRO') {
    return (
      <PracticeIntroScreen 
        exam={selectedExam}
        onBack={() => setActiveScreen('POST_EXAM_REVIEW')}
        onStartPractice={() => {
          setStudentGateState(prev => ({
            ...prev,
            status: 'ATTEMPTING',
            violationCount: 0,
            showViolationWarning: false
          }));
          setActiveScreen('LIVE_SECURE_ATTEMPT');
        }}
        onReviewPrevious={() => {
          setActiveScreen('POST_EXAM_REVIEW');
        }}
      />
    );
  }

  // Find linked exam for rohan
  const currentAssignedExam = controlledExams.find(e => e.id === 'ce1') || controlledExams[0];

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      <header className="px-6 py-4 flex items-center justify-between sticky top-0 bg-surface/80 backdrop-blur-md z-10 border-b border-surface-variant/30">
        <div>
          <h1 className="text-xl font-bold">Student Hub</h1>
          <p className="text-xs text-on-surface-variant">Preparing for Batch: {user?.batchId || 'JEE 2026 Alpha'}</p>
        </div>
        <button onClick={() => setUser(null)} className="p-2 rounded-full hover:bg-error-container/20 text-error">
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      <main className="flex-1 p-4 space-y-6 pb-24 overflow-y-auto">
        {/* Verification Status Banner */}
        <Card className="p-4 bg-primary-container/10 border-2 border-dashed border-primary flex justify-between items-center rounded-3xl">
           <div className="space-y-1">
              <p className="text-[10px] font-mono text-primary font-bold tracking-wider uppercase">SECURE HARDWARE REGISTER STATE</p>
              <h3 className="font-extrabold text-xs text-on-surface">Device Bind Signature:</h3>
              <p className="font-mono text-[9px] text-on-surface-variant">ANDROID_9801_SECURED (OK)</p>
           </div>
           <Badge variant="success">BOUND</Badge>
        </Card>

        {/* 1. Controlled live-exam center entry point */}
        <section className="space-y-3">
          <h2 className="text-sm font-extrabold flex items-center gap-2 ml-2 uppercase text-primary tracking-wider">
             <ShieldAlert className="w-4.5 h-4.5 text-error" /> Secure Exam Gates
          </h2>

          <Card className="p-5 space-y-4 border border-error bg-surface-container-low">
             <div className="flex justify-between items-start">
                <div>
                   <span className="bg-red-100 text-red-800 text-[8px] font-bold px-2.5 py-0.5 rounded-full font-mono uppercase tracking-widest animate-pulse">
                     CONTROLLED CENTER EXAM
                   </span>
                   <h3 className="font-extrabold text-base text-on-surface mt-1.5">{currentAssignedExam.title}</h3>
                   <p className="text-[10px] text-on-surface-variant font-mono">CODE: {currentAssignedExam.versionNumber}</p>
                </div>
                <Badge variant={currentAssignedExam.status === 'LIVE' ? 'error' : currentAssignedExam.status === 'RESULT_RELEASED' ? 'success' : 'warning'}>
                   {currentAssignedExam.status}
                </Badge>
             </div>

             <div className="grid grid-cols-2 gap-3 bg-surface-container p-3 rounded-2xl text-[10px] text-on-surface-variant font-mono">
                <div>
                   <p>DURATION: <strong className="font-bold text-on-surface">{currentAssignedExam.duration / 3600} Hours</strong></p>
                </div>
                <div>
                   <p>QUESTIONS: <strong className="font-bold text-on-surface">3 Sections (90 Qs)</strong></p>
                </div>
                <div className="col-span-2 border-t border-outline/10 pt-2 flex items-center gap-1">
                   <Monitor className="w-3.5 h-3.5 text-primary" />
                   <span>Seat Allocation: <strong className="font-bold text-primary">HALL-04 / SEAT-19</strong></span>
                </div>
             </div>

             {/* Dynamic CTA depending on state */}
             {currentAssignedExam.status === 'RESULT_RELEASED' ? (
               <Button onClick={() => handleExamClick(currentAssignedExam)} className="w-full py-3.5 bg-green-700 hover:bg-green-800 text-white font-extrabold">
                  VIEW MARKS & SOULTION DETAILS
               </Button>
             ) : (
               <Button onClick={() => handleExamClick(currentAssignedExam)} className="w-full py-3.5 bg-error hover:bg-red-800 text-white font-extrabold flex items-center justify-center gap-2">
                  <QrCode className="w-4 h-4" /> ENTER EXAM CENTER GATEWAY
               </Button>
             )}
          </Card>
        </section>

        {/* 2. Recent Results & Reviews */}
        <section className="space-y-3">
          <h2 className="text-sm font-extrabold flex items-center gap-2 ml-2 uppercase text-on-surface-variant tracking-wider">
             <History className="w-4.5 h-4.5" /> Recent scoring details
          </h2>
          <div className="grid gap-3">
            {results.map((res) => (
              <Card key={res.attemptId} className="p-4 flex items-center justify-between hover:bg-surface-container-high border-b border-surface-variant/20 bg-surface-container-low">
                <div className="flex-1">
                   <h3 className="text-xs font-bold text-on-surface">Algebra Weekly Test</h3>
                   <div className="flex gap-2 text-[10px] mt-1 font-mono font-bold">
                      <span className="text-primary">{res.totalScore} / {res.maxScore}</span>
                      <span className="text-on-surface-variant"> Rank: #{res.rank}</span>
                   </div>
                </div>
                <div className="text-right flex items-center gap-2">
                   <div className="text-[9px] text-on-surface-variant font-mono">
                      <p>Correct: {res.correct}</p>
                      <p>Wrong: {res.wrong}</p>
                   </div>
                   <ChevronRight className="w-4 h-4 text-on-surface-variant opacity-40" />
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* ==========================================
            STUDENT LIVE DEMO PROTOTYPE STATE CONTROLLERS
            ========================================== */}
        <Card className="p-4 bg-tertiary-container/10 border-2 border-dashed border-tertiary-container mt-6 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-tertiary">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>STUDENT SIMULATOR SANDBOX</span>
          </div>
          <p className="text-[10px] text-on-surface-variant leading-tight">
            Use this action to simulate a teacher releasing the exam results manually. This allows you to preview the review workflow in this client tab instantly:
          </p>
          <button 
            onClick={simulateResultsReleased} 
            className="w-full bg-primary text-on-primary py-2.5 text-xs font-bold rounded-xl flex items-center justify-center gap-1"
          >
             <span>⚡ FORCIBLY RELEASE EXAM RESULTS & REVIEW</span>
          </button>
        </Card>
      </main>

      {/* Student Nav */}
      <footer className="fixed bottom-0 w-full bg-surface-container px-6 py-4 border-t border-surface-variant flex justify-around items-center z-30">
        <NavItem icon={BookOpen} label="Exams" active={true} />
        <NavItem icon={Trophy} label="Rankings" />
        <NavItem icon={History} label="History" />
      </footer>
    </div>
  );
}

const NavItem = ({ icon: Icon, label, active }: any) => (
  <div className={`flex flex-col items-center gap-1 ${active ? 'text-primary' : 'text-on-surface-variant'}`}>
     <div className={`px-5 py-1 rounded-full ${active ? 'bg-primary-container/20' : ''}`}>
       <Icon className="w-5 h-5" />
     </div>
     <span className="text-[9px] font-bold tracking-wider uppercase">{label}</span>
  </div>
);
