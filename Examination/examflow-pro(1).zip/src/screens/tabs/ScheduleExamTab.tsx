import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Card, Button, Badge } from '../../components/ui/M3Components';
import { Calendar, Send, Info } from 'lucide-react';

export default function ScheduleExamTab() {
  const { papers, setPapers } = useAppContext();
  const draftPapers = papers.filter(p => p.status === 'DRAFT');

  const handlePublish = (id: string) => {
    setPapers(prev => prev.map(p => p.id === id ? { ...p, status: 'PUBLISHED' } : p));
  };

  return (
    <div className="p-4 space-y-4">
      <div className="bg-primary-container/20 p-4 rounded-[28px] border border-primary/10 flex items-start gap-4 mb-4">
        <Info className="w-6 h-6 text-primary shrink-0 mt-1" />
        <div className="space-y-1">
          <h3 className="font-bold text-sm text-primary">Schedule Ready Papers</h3>
          <p className="text-xs text-on-surface-variant leading-relaxed">
            Only DRAFT papers can be scheduled/published. Once published, they will be visible to students in the selected batch.
          </p>
        </div>
      </div>

      <div className="grid gap-4">
        {draftPapers.length === 0 ? (
          <div className="py-20 text-center opacity-30 italic text-sm">No draft papers available to schedule</div>
        ) : (
          draftPapers.map((paper) => (
            <Card key={paper.id} className="p-5 space-y-4">
              <div className="flex justify-between items-start">
                 <div className="space-y-1">
                    <h3 className="font-bold text-lg leading-tight">{paper.title}</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-on-surface-variant">{paper.batch}</span>
                      <span className="w-1 h-1 bg-on-surface-variant/30 rounded-full" />
                      <span className="text-[10px] font-bold text-primary uppercase">Draft</span>
                    </div>
                 </div>
              </div>

              <div className="bg-surface-container-low p-4 rounded-2xl flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <div className="p-2 bg-secondary-container rounded-lg">
                       <Calendar className="w-5 h-5 text-on-secondary-container" />
                    </div>
                    <div>
                       <p className="text-[10px] font-bold text-on-surface-variant opacity-60">TARGET DATE</p>
                       <p className="text-sm font-bold">Select Date & Time</p>
                    </div>
                 </div>
                 <Button onClick={() => handlePublish(paper.id)} variant="tonal" className="!px-6 py-2 gap-2 flex items-center font-bold">
                    <Send className="w-4 h-4" /> PUBLISH
                 </Button>
              </div>

              <div className="flex justify-around pt-2">
                 <MiniStat label="Duration" val={`${paper.duration / 60}m`} />
                 <MiniStat label="MCQs" val={paper.questions.filter(q => q.type === 'MCQ').length} />
                 <MiniStat label="Integers" val={paper.questions.filter(q => q.type === 'INTEGER').length} />
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

const MiniStat = ({ label, val }: any) => (
  <div className="text-center">
    <p className="text-[9px] font-bold text-on-surface-variant uppercase">{label}</p>
    <p className="text-xs font-bold text-on-surface">{val}</p>
  </div>
);
