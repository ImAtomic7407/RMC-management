import React from 'react';
import { Card, Badge, Button } from '../../components/ui/M3Components';
import { useAppContext } from '../../context/AppContext';
import { ChevronRight, BarChart3, Users, Settings, ShieldAlert, Zap } from 'lucide-react';

export default function ExamsHeldTab({ onSelectControlledExam }: { onSelectControlledExam: (examId: string) => void }) {
  const { heldExams, controlledExams } = useAppContext();

  return (
    <div className="p-4 space-y-4">
      {/* 1. Live & Scheduled Controlled Exams */}
      <div className="space-y-3">
        <h2 className="text-sm font-extrabold text-primary flex items-center gap-1.5 uppercase ml-2 select-none tracking-wider">
          <ShieldAlert className="w-4.5 h-4.5" /> Secure Controlled Exam Centers
        </h2>
        
        <div className="grid gap-3">
          {controlledExams.map((exam) => (
            <Card key={exam.id} className="p-5 space-y-3 border-l-4 border-error bg-surface-container-low">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="font-bold text-base leading-tight text-on-surface">{exam.title}</h3>
                  <div className="flex flex-wrap gap-2 items-center">
                    <Badge variant={exam.status === 'LIVE' ? 'error' : exam.status === 'RESULT_RELEASED' ? 'success' : 'warning'}>
                      {exam.status}
                    </Badge>
                    <span className="text-[9px] font-mono font-bold text-on-surface-variant bg-surface-container px-2 py-0.5 rounded">
                      {exam.batch}
                    </span>
                    <span className="text-[9px] font-mono font-bold text-secondary bg-secondary-container/10 px-2 py-0.5 rounded">
                      {exam.versionNumber}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center text-[10px] text-on-surface-variant font-mono">
                 <p>Questions: <strong className="font-bold">{exam.totalQuestions} Qs</strong></p>
                 <p>Duration: <strong className="font-bold">{exam.duration / 60} mins</strong></p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-surface-variant/20">
                <span className="text-[9px] font-mono text-on-surface-variant">{exam.scheduledAt.split('T')[0]}</span>
                <Button 
                  onClick={() => onSelectControlledExam(exam.id)}
                  className="!px-3 !py-1.5 text-[10px] font-bold bg-error text-on-error flex items-center gap-1.5 rounded-xl hover:bg-error/95"
                >
                   <Settings className="w-3.5 h-3.5" /> EXAM DOOR CONTROL
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <div className="border-t border-surface-variant/45 pt-4">
        {/* 2. Historic Held Exams list */}
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-extrabold opacity-75 uppercase ml-2 tracking-wider">Historical Held Exams</h2>
          <span className="text-[10px] text-on-surface-variant font-bold">{heldExams.length} Records</span>
        </div>

        <div className="grid gap-4">
          {heldExams.map((exam) => (
            <Card key={exam.id} className="p-5 space-y-4 border-l-4 border-primary bg-surface-container-low">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="font-bold text-base leading-tight">{exam.title}</h3>
                  <div className="flex gap-2">
                    <Badge variant={exam.status === 'RESULT_RELEASED' ? 'success' : 'warning'}>
                      {exam.status.replace('_', ' ')}
                    </Badge>
                    <span className="text-[10px] font-bold text-on-surface-variant flex items-center bg-surface-container px-2 py-0.5 rounded">
                      {exam.batch}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-surface-container-low p-3 rounded-2xl border border-surface-variant/20">
                 <div className="space-y-0.5 border-r border-surface-variant/30">
                    <p className="text-[10px] uppercase font-bold opacity-60">Avg. Score</p>
                    <p className="text-sm font-bold text-primary">{exam.avgMarks}</p>
                 </div>
                 <div className="space-y-0.5">
                    <p className="text-[10px] uppercase font-bold opacity-60">Attempts</p>
                    <p className="text-sm font-bold flex items-center gap-1">
                      <Users className="w-3 h-3" /> {exam.attemptsCount}
                    </p>
                 </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] font-bold text-on-surface-variant">{exam.date}</span>
                <div className="flex gap-2">
                  <Button variant="tonal" className="!px-3 !py-1 text-xs font-bold gap-1 flex items-center">
                     <BarChart3 className="w-3.5 h-3.5" /> RESULTS
                  </Button>
                  {exam.status === 'CLOSED' && (
                    <Button className="!px-3 !py-1 text-xs font-bold">RELEASE</Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
