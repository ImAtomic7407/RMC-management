import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Card, Input, Button, Tabs } from '../../components/ui/M3Components';
import { Clock, Book, AlertCircle } from 'lucide-react';

export default function CreatePaperTab({ onSuccess }: { onSuccess: () => void }) {
  const { setPapers } = useAppContext();
  const [formData, setFormData] = useState({
    title: '',
    batch: 'JEE 2026 Alpha',
    examMode: 'LIVE',
    duration: '180', // minutes
    solutionPolicy: 'AFTER_RESULT_RELEASE',
    phyCount: 30,
    chemCount: 30,
    mathCount: 30
  });

  const handleSave = () => {
    if (!formData.title) return alert('Enter paper title');
    
    const newPaper: any = {
      id: 'p' + Date.now(),
      title: formData.title,
      batch: formData.batch,
      status: 'DRAFT',
      duration: parseInt(formData.duration) * 60,
      examMode: formData.examMode,
      instructions: 'Default instructions for ' + formData.title,
      solutionPolicy: formData.solutionPolicy,
      sections: {
        PHYSICS: { targetCount: formData.phyCount, defaultMarks: 4, defaultNegativeMarks: 1 },
        CHEMISTRY: { targetCount: formData.chemCount, defaultMarks: 4, defaultNegativeMarks: 1 },
        MATHS: { targetCount: formData.mathCount, defaultMarks: 4, defaultNegativeMarks: 1 },
      },
      questions: []
    };

    setPapers(prev => [newPaper, ...prev]);
    onSuccess();
  };

  return (
    <div className="p-4 space-y-6">
      <h2 className="text-xl font-bold px-2">New Question Paper</h2>
      
      <div className="space-y-4">
        <Input 
          label="Paper Title" 
          placeholder="e.g. JEE Main Mock Test - 05" 
          value={formData.title}
          onChange={(e: any) => setFormData({...formData, title: e.target.value})}
        />
        
        <div className="grid grid-cols-2 gap-4">
          <Input 
            label="Duration (Minutes)" 
            type="number"
            value={formData.duration}
            onChange={(e: any) => setFormData({...formData, duration: e.target.value})}
          />
          <div className="flex flex-col gap-1">
             <label className="text-sm font-medium text-on-surface-variant ml-2">Exam Mode</label>
             <select 
               className="bg-surface-container-high px-4 py-3 rounded-2xl outline-none"
               value={formData.examMode}
               onChange={(e) => setFormData({...formData, examMode: e.target.value})}
             >
               <option value="LIVE">LIVE EXAM</option>
               <option value="PRACTICE">PRACTICE MO</option>
             </select>
          </div>
        </div>

        <Card className="p-5 space-y-4 border border-outline/10">
          <h3 className="text-sm font-bold text-primary flex items-center gap-2">
            <Book className="w-4 h-4" /> SECTION TARGETS
          </h3>
          <div className="grid grid-cols-3 gap-3">
             <TargetInput label="Physics" value={formData.phyCount} onChange={(val) => setFormData({...formData, phyCount: val})} />
             <TargetInput label="Chemistry" value={formData.chemCount} onChange={(val) => setFormData({...formData, chemCount: val})} />
             <TargetInput label="Maths" value={formData.mathCount} onChange={(val) => setFormData({...formData, mathCount: val})} />
          </div>
          <p className="text-[10px] text-on-surface-variant italic">
            * Marks: +4, -1 will be applied as section defaults
          </p>
        </Card>

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium text-on-surface-variant ml-2">Solution Policy</label>
          <select 
            className="bg-surface-container-high px-4 py-3 rounded-2xl outline-none"
            value={formData.solutionPolicy}
            onChange={(e) => setFormData({...formData, solutionPolicy: e.target.value})}
          >
            <option value="AFTER_EXAM_END">After Exam End</option>
            <option value="AFTER_RESULT_RELEASE">After Result Release</option>
            <option value="NEVER">Never Show</option>
            <option value="PRACTICE_UNLOCK_RULE">Practice Unlock Rule</option>
          </select>
        </div>

        <Button onClick={handleSave} className="w-full py-4 text-lg">
          CREATE DRAFT PAPER
        </Button>
      </div>
    </div>
  );
}

const TargetInput = ({ label, value, onChange }: any) => (
  <div className="flex flex-col items-center gap-1">
    <span className="text-[10px] font-bold uppercase">{label}</span>
    <input 
      type="number" 
      value={value}
      onChange={(e) => onChange(parseInt(e.target.value) || 0)}
      className="w-full bg-surface-container px-2 py-2 rounded-xl text-center font-bold"
    />
  </div>
);
