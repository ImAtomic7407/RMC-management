import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Card, Badge, Button } from '../../components/ui/M3Components';
import { ChevronRight, FileEdit, Eye } from 'lucide-react';

export default function QuestionPaperTab() {
  const { papers } = useAppContext();

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-bold ml-2">My Question Papers</h2>
        <span className="text-xs text-on-surface-variant">{papers.length} Papers</span>
      </div>

      <div className="grid gap-4">
        {papers.map((paper) => (
          <Card key={paper.id} data-paper-id={paper.id} className="p-5 space-y-3">

            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h3 className="font-bold text-lg">{paper.title}</h3>
                <div className="flex gap-2">
                  <Badge variant={paper.status === 'PUBLISHED' ? 'success' : 'info'}>
                    {paper.status}
                  </Badge>
                  <span className="text-xs text-on-surface-variant flex items-center">
                    {paper.batch}
                  </span>
                </div>
              </div>
              <Button variant="tonal" className="!p-2">
                <FileEdit className="w-5 h-5" />
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-2 py-2 border-y border-surface-variant/30">
              <SectionStat label="Physics" count={paper.questions.filter(q => q.section === 'PHYSICS').length} target={paper.sections.PHYSICS.targetCount} />
              <SectionStat label="Chemistry" count={paper.questions.filter(q => q.section === 'CHEMISTRY').length} target={paper.sections.CHEMISTRY.targetCount} />
              <SectionStat label="Maths" count={paper.questions.filter(q => q.section === 'MATHS').length} target={paper.sections.MATHS.targetCount} />
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex -space-x-2">
                <span className="text-[10px] bg-secondary-container text-on-secondary-container px-2 py-0.5 rounded-full z-10">
                  {Math.round((paper.questions.length / (paper.sections.PHYSICS.targetCount + paper.sections.CHEMISTRY.targetCount + paper.sections.MATHS.targetCount)) * 100 || 0)}% Complete
                </span>
              </div>
              <Button variant="text" className="gap-1 !px-2 !py-1 text-sm font-bold items-center flex">
                OPEN PAPER <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

const SectionStat = ({ label, count, target }: any) => (
  <div className="text-center">
    <p className="text-[10px] text-on-surface-variant font-medium uppercase tracking-wider">{label}</p>
    <p className="text-sm font-bold">{count}<span className="text-on-surface-variant/50">/{target}</span></p>
  </div>
);
