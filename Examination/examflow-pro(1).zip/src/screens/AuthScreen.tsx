import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Button, Card } from '../components/ui/M3Components';
import { UserRole } from '../types';
import { GraduationCap, BookOpen, ShieldCheck } from 'lucide-react';

export default function AuthScreen() {
  const { setUser } = useAppContext();

  const handleLogin = (role: UserRole) => {
    setUser({
      id: role === 'STUDENT' ? 's1' : 't1',
      name: role === 'STUDENT' ? 'Rohan Kumar' : 'Arjun Singh',
      role,
      batchId: role === 'STUDENT' ? 'JEE 2026 Alpha' : undefined
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-surface">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-2">
          <div className="w-20 h-20 bg-primary-container rounded-3xl mx-auto flex items-center justify-center mb-4">
            <ShieldCheck className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-on-surface">Examify Hub</h1>
          <p className="text-on-surface-variant">Choose your role to continue</p>
        </div>

        <div className="grid gap-4">
          <RoleCard 
            title="Teacher / Admin" 
            desc="Manage papers, exams & results" 
            icon={BookOpen}
            onClick={() => handleLogin('TEACHER')}
          />
          <RoleCard 
            title="Student" 
            desc="Take exams & view performance" 
            icon={GraduationCap}
            onClick={() => handleLogin('STUDENT')}
          />
        </div>

        <p className="text-xs text-center text-on-surface-variant pt-8">
          Coaching Institute Examination Management System v1.0
        </p>
      </div>
    </div>
  );
}

const RoleCard = ({ title, desc, icon: Icon, onClick }: any) => (
  <Card onClick={onClick} className="p-6 flex items-center gap-4 hover:scale-[1.02]">
    <div className="p-4 bg-secondary-container rounded-2xl text-on-secondary-container">
      <Icon className="w-6 h-6" />
    </div>
    <div className="flex-1">
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="text-sm text-on-surface-variant">{desc}</p>
    </div>
  </Card>
);
