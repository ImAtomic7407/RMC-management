import React, { useState } from 'react';
import { FileText, ClipboardCheck, PlusCircle, Calendar, LogOut } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Button, Card, Badge } from '../components/ui/M3Components';
import QuestionPaperTab from './tabs/QuestionPaperTab';
import ExamsHeldTab from './tabs/ExamsHeldTab';
import CreatePaperTab from './tabs/CreatePaperTab';
import ScheduleExamTab from './tabs/ScheduleExamTab';

// New Secure Gate Screens
import ExamControlScreen from './teacher/ExamControlScreen';
import QRScannerScreen from './teacher/QRScannerScreen';
import GateSessionsScreen from './teacher/GateSessionsScreen';

export default function TeacherDashboard() {
  const [activeTab, setActiveTab] = useState(0);
  const { user, setUser } = useAppContext();

  // Controlled exam view states
  const [teacherView, setTeacherView] = useState<'TABS' | 'EXAM_CONTROL' | 'QR_SCANNER' | 'GATE_SESSIONS'>('TABS');
  const [activeExamId, setActiveExamId] = useState<string | null>(null);

  const tabs = [
    { id: 0, label: 'Question Paper', icon: FileText },
    { id: 1, label: 'Exams', icon: ClipboardCheck },
    { id: 2, label: 'Create', icon: PlusCircle },
    { id: 3, label: 'Schedule', icon: Calendar },
  ];

  const handleOpenControlledExam = (examId: string) => {
    setActiveExamId(examId);
    setTeacherView('EXAM_CONTROL');
  };

  if (teacherView === 'EXAM_CONTROL' && activeExamId) {
    return (
      <ExamControlScreen 
        examId={activeExamId}
        onBack={() => setTeacherView('TABS')}
        onOpenScanner={() => setTeacherView('QR_SCANNER')}
        onOpenSessions={() => setTeacherView('GATE_SESSIONS')}
      />
    );
  }

  if (teacherView === 'QR_SCANNER' && activeExamId) {
    return (
      <QRScannerScreen 
        examId={activeExamId}
        onBack={() => setTeacherView('EXAM_CONTROL')}
      />
    );
  }

  if (teacherView === 'GATE_SESSIONS' && activeExamId) {
    return (
      <GateSessionsScreen 
        examId={activeExamId}
        onBack={() => setTeacherView('EXAM_CONTROL')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Top Header */}
      <header className="px-6 py-4 flex items-center justify-between sticky top-0 bg-surface/80 backdrop-blur-md z-10 border-b border-surface-variant">
        <div>
          <h1 className="text-xl font-bold">Teacher Hub</h1>
          <p className="text-xs text-on-surface-variant">Welcome, {user?.name}</p>
        </div>
        <button onClick={() => setUser(null)} className="p-2 rounded-full hover:bg-error-container/20 text-error">
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 pb-24 overflow-y-auto">
        {activeTab === 0 && <QuestionPaperTab />}
        {activeTab === 1 && <ExamsHeldTab onSelectControlledExam={handleOpenControlledExam} />}
        {activeTab === 2 && <CreatePaperTab onSuccess={() => setActiveTab(0)} />}
        {activeTab === 3 && <ScheduleExamTab />}
      </main>

      {/* Bottom Navigation (Android Style) */}
      <nav className="fixed bottom-0 w-full bg-surface-container border-t border-surface-variant px-2 py-3 flex justify-around items-center z-20">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setTeacherView('TABS');
                setActiveTab(tab.id);
              }}
              className="flex flex-col items-center gap-1 group relative"
            >
              <div className={`px-5 py-1 rounded-full transition-all ${isActive ? 'bg-secondary-container text-on-secondary-container' : 'text-on-surface-variant'}`}>
                <Icon className={`w-6 h-6 ${isActive ? 'fill-current' : ''}`} />
              </div>
              <span className={`text-[11px] font-medium ${isActive ? 'text-on-surface' : 'text-on-surface-variant'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
