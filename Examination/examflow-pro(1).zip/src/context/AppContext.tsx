import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, Paper, Exam, Result, ControlledExam, GateSession, StudentParticipant } from '../types';
import { MOCK_PAPERS, MOCK_HELD_EXAMS, MOCK_RESULTS } from '../data/mockData';

const INITIAL_CONTROLLED_EXAMS: ControlledExam[] = [
  {
    id: 'ce1',
    title: 'JEE Advanced Controlled Mock - 01',
    status: 'SCHEDULED',
    batch: 'JEE 2026 Alpha',
    scheduledAt: '2026-05-25T09:00:00Z',
    duration: 10800,
    totalQuestions: 90,
    versionNumber: 'v2.4-SECURE',
    linkedPaperId: 'p1',
    physicsQuestions: 30,
    chemistryQuestions: 30,
    mathsQuestions: 30
  },
  {
    id: 'ce2',
    title: 'IIT Physics Sectional Gate Exam',
    status: 'LIVE',
    batch: 'JEE 2026 Beta',
    scheduledAt: '2026-05-23T10:00:00Z',
    duration: 3600,
    totalQuestions: 25,
    versionNumber: 'v1.1-LOCKED',
    linkedPaperId: 'p2',
    physicsQuestions: 25,
    chemistryQuestions: 0,
    mathsQuestions: 0
  }
];

const INITIAL_STUDENT_PARTICIPANTS: StudentParticipant[] = [
  { id: 's1', name: 'Rohan Kumar', uid: 'JEE26-041', photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', deviceId: 'DEV-9801X' },
  { id: 's2', name: 'Priya Singh', uid: 'JEE26-112', photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', deviceId: 'DEV-2234Y' },
  { id: 's3', name: 'Aman Raj', uid: 'JEE26-330', photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', deviceId: 'DEV-4091Z' },
  { id: 's4', name: 'Sneha Kumari', uid: 'JEE26-019', photoUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', deviceId: 'DEV-IJK22' }
];

const INITIAL_GATE_SESSIONS: GateSession[] = [
  {
    student: INITIAL_STUDENT_PARTICIPANTS[0],
    gateStatus: 'WAITING',
    deviceStatus: 'BOUND',
    paperDownloadStatus: 'NOT_STARTED',
    attemptStatus: 'WAITING',
    violationCount: 0
  },
  {
    student: INITIAL_STUDENT_PARTICIPANTS[1],
    gateStatus: 'VERIFIED',
    deviceStatus: 'BOUND',
    paperDownloadStatus: 'READY',
    attemptStatus: 'ATTEMPTING',
    violationCount: 0
  },
  {
    student: INITIAL_STUDENT_PARTICIPANTS[2],
    gateStatus: 'VERIFIED',
    deviceStatus: 'BOUND',
    paperDownloadStatus: 'DOWNLOADING',
    attemptStatus: 'WAITING',
    violationCount: 1
  },
  {
    student: INITIAL_STUDENT_PARTICIPANTS[3],
    gateStatus: 'DENIED',
    deviceStatus: 'MISMATCH',
    paperDownloadStatus: 'FAILED',
    attemptStatus: 'WAITING',
    violationCount: 0
  }
];

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  papers: Paper[];
  setPapers: React.Dispatch<React.SetStateAction<Paper[]>>;
  heldExams: Exam[];
  results: Result[];
  controlledExams: ControlledExam[];
  setControlledExams: React.Dispatch<React.SetStateAction<ControlledExam[]>>;
  gateSessions: GateSession[];
  setGateSessions: React.Dispatch<React.SetStateAction<GateSession[]>>;
  // Student active mock state
  studentGateState: {
    status: 'NOT_AT' | 'SHOWING_QR' | 'WAITING_ROOM' | 'SECURE_RULES' | 'ATTEMPTING' | 'SUBMITTED' | 'REVIEW';
    verified: boolean;
    paperDownloaded: 'NOT' | 'DOWNLOADING' | 'READY' | 'FAILED';
    percent: number;
    violationCount: number;
    showViolationWarning: boolean;
    violationReason: string;
    answers: Record<number, any>;
    marked: Set<number>;
    currentExamId: string;
  };
  setStudentGateState: React.Dispatch<React.SetStateAction<any>>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [papers, setPapers] = useState<Paper[]>(MOCK_PAPERS);
  const [controlledExams, setControlledExams] = useState<ControlledExam[]>(INITIAL_CONTROLLED_EXAMS);
  const [gateSessions, setGateSessions] = useState<GateSession[]>(INITIAL_GATE_SESSIONS);

  const [studentGateState, setStudentGateState] = useState<{
    status: 'NOT_AT' | 'SHOWING_QR' | 'WAITING_ROOM' | 'SECURE_RULES' | 'ATTEMPTING' | 'SUBMITTED' | 'REVIEW';
    verified: boolean;
    paperDownloaded: 'NOT' | 'DOWNLOADING' | 'READY' | 'FAILED';
    percent: number;
    violationCount: number;
    showViolationWarning: boolean;
    violationReason: string;
    answers: Record<number, any>;
    marked: Set<number>;
    currentExamId: string;
  }>({
    status: 'NOT_AT',
    verified: false,
    paperDownloaded: 'NOT',
    percent: 0,
    violationCount: 0,
    showViolationWarning: false,
    violationReason: '',
    answers: {},
    marked: new Set<number>(),
    currentExamId: 'ce1'
  });

  return (
    <AppContext.Provider value={{ 
      user, 
      setUser, 
      papers, 
      setPapers, 
      heldExams: MOCK_HELD_EXAMS, 
      results: MOCK_RESULTS,
      controlledExams,
      setControlledExams,
      gateSessions,
      setGateSessions,
      studentGateState,
      setStudentGateState
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
};
