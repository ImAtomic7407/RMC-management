import { Paper, Exam, Result, Question } from '../types';

export const MOCK_PAPERS: Paper[] = [
  {
    id: 'p1',
    title: 'JEE Full Syllabus Mock - 01',
    status: 'DRAFT',
    batch: 'JEE 2026 Alpha',
    duration: 10800,
    examMode: 'LIVE',
    instructions: '1. Read all questions carefully.\n2. Do not use calculators.',
    solutionPolicy: 'AFTER_RESULT_RELEASE',
    sections: {
      PHYSICS: { targetCount: 30, defaultMarks: 4, defaultNegativeMarks: 1 },
      CHEMISTRY: { targetCount: 30, defaultMarks: 4, defaultNegativeMarks: 1 },
      MATHS: { targetCount: 30, defaultMarks: 4, defaultNegativeMarks: 1 },
    },
    questions: [
      {
        id: 'q1',
        paperId: 'p1',
        section: 'PHYSICS',
        type: 'MCQ',
        order: 1,
        text: 'The focal length of a convex lens is 20cm. Find its power.',
        options: [
          { label: 'A', text: '+5D', isCorrect: true },
          { label: 'B', text: '-5D', isCorrect: false },
          { label: 'C', text: '+2D', isCorrect: false },
          { label: 'D', text: '-2D', isCorrect: false },
        ],
        marks: 4,
        negativeMarks: 1,
      },
      {
        id: 'q2',
        paperId: 'p1',
        section: 'PHYSICS',
        type: 'INTEGER',
        order: 2,
        text: 'A bullet of mass 10g is moving with speed 100m/s. Find KE in Joules.',
        correctInteger: 50,
        options: [],
        marks: 4,
        negativeMarks: 0,
      }
    ],
  },
  {
    id: 'p2',
    title: 'Vectors & 3D Geometry Practice',
    status: 'DRAFT',
    batch: 'Class 12 Board',
    duration: 3600,
    examMode: 'PRACTICE',
    instructions: 'Practice session for Vectors.',
    solutionPolicy: 'PRACTICE_UNLOCK_RULE',
    sections: {
      PHYSICS: { targetCount: 0, defaultMarks: 4, defaultNegativeMarks: 1 },
      CHEMISTRY: { targetCount: 0, defaultMarks: 4, defaultNegativeMarks: 1 },
      MATHS: { targetCount: 20, defaultMarks: 4, defaultNegativeMarks: 0 },
    },
    questions: [],
  }
];

export const MOCK_HELD_EXAMS: Exam[] = [
  {
    id: 'e1',
    paperId: 'p3',
    title: 'Weekly Test - Algebra',
    batch: 'JEE 2026 Beta',
    status: 'CLOSED',
    date: '2024-05-15',
    attemptsCount: 45,
    avgMarks: 112,
    topScore: 285,
  },
  {
    id: 'e2',
    paperId: 'p4',
    title: 'Full Syllabus Test - 05',
    batch: 'NEET 2026',
    status: 'RESULT_RELEASED',
    date: '2024-05-10',
    attemptsCount: 120,
    avgMarks: 450,
    topScore: 710,
  }
];

export const MOCK_RESULTS: Result[] = [
  {
    attemptId: 'a1',
    studentName: 'Rohan Kumar',
    totalScore: 245,
    maxScore: 300,
    rank: 1,
    physicsScore: 85,
    chemistryScore: 80,
    mathsScore: 80,
    correct: 65,
    wrong: 10,
    unattempted: 15,
  },
  {
    attemptId: 'a2',
    studentName: 'Priya Singh',
    totalScore: 232,
    maxScore: 300,
    rank: 2,
    physicsScore: 75,
    chemistryScore: 82,
    mathsScore: 75,
    correct: 62,
    wrong: 8,
    unattempted: 20,
  }
];
