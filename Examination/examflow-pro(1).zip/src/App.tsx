/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useAppContext } from './context/AppContext';
import AuthScreen from './screens/AuthScreen';
import TeacherDashboard from './screens/TeacherDashboard';
import StudentDashboard from './screens/StudentDashboard';
import PaperEditor from './screens/teacher/PaperEditor';
import { Paper } from './types';

function AppContent() {
  const { user, papers } = useAppContext();
  const [selectedPaperForEdit, setSelectedPaperForEdit] = useState<Paper | null>(null);

  if (!user) {
    return <AuthScreen />;
  }

  if (user.role === 'TEACHER' || user.role === 'ADMIN') {
    return (
      <div onClick={(e) => {
        const target = (e.target as HTMLElement).closest('[data-paper-id]');
        if (target) {
          const id = target.getAttribute('data-paper-id');
          const paper = papers.find(p => p.id === id);
          if (paper) setSelectedPaperForEdit(paper);
        }
      }}>
        {selectedPaperForEdit ? (
          <PaperEditor 
            paper={selectedPaperForEdit} 
            onBack={() => setSelectedPaperForEdit(null)} 
          />
        ) : (
          <TeacherDashboard />
        )}
      </div>
    );
  }

  return <StudentDashboard />;
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
