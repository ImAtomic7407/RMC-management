import React from 'react';

export const Card = ({ children, className = "", onClick }: { children: React.ReactNode, className?: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className={`bg-surface-container-low rounded-[28px] overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer ${className}`}
  >
    {children}
  </div>
);

export const Button = ({ 
  children, 
  variant = 'primary', 
  className = "", 
  onClick,
  disabled = false
}: { 
  children: React.ReactNode, 
  variant?: 'primary' | 'secondary' | 'tonal' | 'outline' | 'text' | 'danger',
  className?: string,
  onClick?: () => void,
  disabled?: boolean
}) => {
  const variants = {
    primary: 'bg-primary text-on-primary',
    secondary: 'bg-secondary-container text-on-secondary-container',
    tonal: 'bg-tertiary-container text-on-tertiary-container',
    outline: 'border border-outline text-primary',
    text: 'text-primary hover:bg-primary/5',
    danger: 'bg-error text-on-error'
  };

  return (
    <button 
      disabled={disabled}
      onClick={onClick}
      className={`px-6 py-2.5 rounded-full font-medium transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100 ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
};

export const Badge = ({ children, variant = 'info', className = "" }: { children: React.ReactNode, variant?: 'info' | 'success' | 'warning' | 'error', className?: string }) => {
  const styles = {
    info: 'bg-primary-container text-on-primary-container',
    success: 'bg-green-100 text-green-800',
    warning: 'bg-yellow-100 text-yellow-800',
    error: 'bg-error-container text-on-error-container'
  };
  return (
    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${styles[variant]} ${className}`}>
      {children}
    </span>
  );
};

export const Input = ({ label, type = "text", ...props }: any) => (
  <div className="flex flex-col gap-1 w-full">
    {label && <label className="text-sm font-medium text-on-surface-variant ml-2">{label}</label>}
    <input 
      type={type}
      className="bg-surface-container-high px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-primary border-none"
      {...props}
    />
  </div>
);

export const Tabs = ({ items, activeTab, onChange }: { items: { id: string, label: string }[], activeTab: string, onChange: (id: string) => void }) => (
  <div className="flex bg-surface-container-low rounded-2xl p-1 w-fit">
    {items.map(item => (
      <button
        key={item.id}
        onClick={() => onChange(item.id)}
        className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
          activeTab === item.id ? 'bg-secondary-container text-on-secondary-container shadow-sm' : 'text-on-surface-variant'
        }`}
      >
        {item.label}
      </button>
    ))}
  </div>
);
