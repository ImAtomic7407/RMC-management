import { LucideIcon } from 'lucide-react';

export type UserRole = 'ADMIN' | 'TEACHER' | 'STUDENT';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  batchId?: string;
}

export type PaperStatus = 'DRAFT' | 'PUBLISHED';
export type ExamStatus = 'CLOSED' | 'RESULT_RELEASED';
export type ExamMode = 'LIVE' | 'PRACTICE';
export type SolutionPolicy = 'AFTER_EXAM_END' | 'AFTER_RESULT_RELEASE' | 'NEVER' | 'PRACTICE_UNLOCK_RULE';

export interface SectionConfig {
  targetCount: number;
  defaultMarks: number;
  defaultNegativeMarks: number;
}

export interface Paper {
  id: string;
  title: string;
  status: PaperStatus;
  batch: string;
  duration: number; // in seconds
  examMode: ExamMode;
  instructions: string;
  solutionPolicy: SolutionPolicy;
  sections: {
    PHYSICS: SectionConfig;
    CHEMISTRY: SectionConfig;
    MATHS: SectionConfig;
  };
  questions: Question[];
}

export type QuestionType = 'MCQ' | 'INTEGER';

export interface Option {
  label: 'A' | 'B' | 'C' | 'D';
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: string;
  paperId: string;
  section: 'PHYSICS' | 'CHEMISTRY' | 'MATHS';
  type: QuestionType;
  order: number;
  text?: string;
  image?: string;
  solutionImage?: string;
  options: Option[]; // Exactly 4 for MCQ
  correctInteger?: number;
  marks: number;
  negativeMarks: number;
}

export interface Exam {
  id: string;
  paperId: string;
  title: string;
  batch: string;
  status: ExamStatus;
  date: string;
  attemptsCount: number;
  avgMarks: number;
  topScore: number;
}

export interface Attempt {
  id: string;
  examId: string;
  studentId: string;
  status: 'STARTED' | 'SUBMITTED';
  startedAt: string;
  submittedAt?: string;
  answers: Record<string, {
    selectedOption?: string;
    integerAnswer?: number;
    isMarkedForReview: boolean;
  }>;
}

export interface Result {
  attemptId: string;
  studentName: string;
  totalScore: number;
  maxScore: number;
  rank: number;
  physicsScore: number;
  chemistryScore: number;
  mathsScore: number;
  correct: number;
  wrong: number;
  unattempted: number;
}

// ==========================================
// CONTROLLED EXAM FLOW TYPES
// ==========================================

export type ControlledExamStatus = 'SCHEDULED' | 'LIVE' | 'CLOSED' | 'RESULT_RELEASED';
export type GateStatus = 'WAITING' | 'VERIFIED' | 'DENIED';
export type DeviceStatus = 'BOUND' | 'MISMATCH';
export type PaperDownloadStatus = 'NOT_STARTED' | 'DOWNLOADING' | 'READY' | 'FAILED';
export type AttemptStatus = 'WAITING' | 'ATTEMPTING' | 'SUBMITTED';

export interface StudentParticipant {
  id: string;
  name: string;
  uid: string;
  photoUrl: string;
  deviceId: string;
}

export interface GateSession {
  student: StudentParticipant;
  gateStatus: GateStatus;
  deviceStatus: DeviceStatus;
  paperDownloadStatus: PaperDownloadStatus;
  attemptStatus: AttemptStatus;
  violationCount: number;
}

export interface ControlledExam {
  id: string;
  title: string;
  status: ControlledExamStatus;
  batch: string;
  scheduledAt: string;
  duration: number; // in seconds
  totalQuestions: number;
  versionNumber: string;
  linkedPaperId: string;
  physicsQuestions: number;
  chemistryQuestions: number;
  mathsQuestions: number;
}

