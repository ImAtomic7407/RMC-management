package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.viewmodel.*
import com.example.data.SampleData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentHomeScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    val attempts by viewModel.attempts.collectAsState()
    val examsList by viewModel.exams.collectAsState()

    val completedCount = attempts.size
    val liveCount = examsList.count { it.status == ExamStatus.LIVE || it.status == ExamStatus.PRACTICE }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Companion", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.Login) }) {
                        Icon(Icons.Default.Logout, contentDescription = "Log Out")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Student Welcome Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Welcome back, ${viewModel.studentName}!",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Roll: ${viewModel.studentRoll} | Core Batch A",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier.size(52.dp),
                        color = Color.White.copy(alpha = 0.2f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(28.dp), tint = Color.White)
                        }
                    }
                }
            }

            // Overview Section
            Text("Your Statistics Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Active/Live", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$liveCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("Exams to take", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Completed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$completedCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        Text("Evaluations", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                }
            }

            Text("Interactive Portals", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            // Portal Navigation Options
            Button(
                onClick = { onNavigate(Screen.StudentAvailableExams) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("std_available_exams_btn")
            ) {
                Icon(Icons.Default.PlayCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Join Live & Practice Exams", fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = { onNavigate(Screen.StudentMarksHistory) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("std_marks_history_btn")
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Marks History", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = { onNavigate(Screen.StudentLeaderboard("ex_2")) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("std_leaderboard_btn")
                ) {
                    Icon(Icons.Default.Leaderboard, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Leaderboards", style = MaterialTheme.typography.labelLarge)
                }
            }

            // Guidelines Warning Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Honor System & Security Protocols", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        Text(
                            "While taking Exams, screenshot blockades are active. Solution keys/materials are blocked from memory buffers and cannot be decrypted until released by admins.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAvailableExamsScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    val examsList by viewModel.exams.collectAsState()
    val attempts by viewModel.attempts.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Available Examination Events", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(examsList) { exam ->
                val hasAttempted = attempts.any { it.examId == exam.id }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_exam_item_${exam.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(exam.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                            Surface(
                                color = when (exam.status) {
                                    ExamStatus.SCHEDULED -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                                    ExamStatus.LIVE -> MaterialTheme.colorScheme.primaryContainer
                                    ExamStatus.PRACTICE -> MaterialTheme.colorScheme.tertiaryContainer
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = exam.status.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Timings scheduled: ${exam.scheduledTime}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Duration Limit: ${exam.durationMinutes} Minutes total",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        if (hasAttempted) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Attempt Submitted", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                }

                                if (exam.status == ExamStatus.RELEASED) {
                                    val matchAttempt = attempts.find { it.examId == exam.id }
                                    Button(
                                        onClick = {
                                            matchAttempt?.let {
                                                onNavigate(Screen.StudentSolutionViewer(exam.id, exam.questionPaperSnapshot.questions.firstOrNull()?.id ?: ""))
                                            }
                                        },
                                        modifier = Modifier.testTag("view_marked_solutions_${exam.id}")
                                    ) {
                                        Text("Review Solutions")
                                    }
                                } else {
                                    Text(
                                        "Results Pending release...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        } else {
                            when (exam.status) {
                                ExamStatus.LIVE, ExamStatus.PRACTICE -> {
                                    Button(
                                        onClick = { viewModel.startStudentExam(exam.id) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("attempt_exam_btn_${exam.id}")
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Start Examination Now")
                                    }
                                }
                                ExamStatus.SCHEDULED -> {
                                    OutlinedButton(
                                        onClick = {},
                                        enabled = false,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Exam Locked Until Calendar Time")
                                    }
                                }
                                else -> {
                                    Text(
                                        "Awaiting Scheduled Period.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// THE VISUAL ATTEMPT SCREEN - STRICTOR STUDENT SAFETY RULES
// NO DISPLAY of solutionImages, answerKeys, correct values, correct options, is_correct flags.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAttemptScreen(
    viewModel: ExamViewModel,
    examId: String
) {
    val activeAttempt by viewModel.activeAttempt.collectAsState()
    val examsList by viewModel.exams.collectAsState()
    val exam = examsList.find { it.id == examId } ?: return
    val snapshotPaper = exam.questionPaperSnapshot

    val studentAnswers = activeAttempt?.answers ?: emptyMap()
    val activeIndex by viewModel.activeStudentQuestionIndex.collectAsState()
    val activeSection by viewModel.activeStudentSection.collectAsState()

    val sectionQuestions = snapshotPaper.questions.filter { it.section == activeSection }
    val q = sectionQuestions.getOrNull(activeIndex)

    var showSubmitDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(exam.name, fontWeight = FontWeight.Bold) },
                actions = {
                    // Live remaining countdown model (mocked)
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.padding(end = 12.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("02:44:11 left", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Section switcher tabs
            TabRow(selectedTabIndex = when(activeSection) {
                "Physics" -> 0
                "Chemistry" -> 1
                else -> 2
            }) {
                Tab(
                    selected = activeSection == "Physics",
                    onClick = {
                        viewModel.activeStudentSection.value = "Physics"
                        viewModel.activeStudentQuestionIndex.value = 0
                    },
                    text = { Text("Physics (${snapshotPaper.questions.count { it.section == "Physics" }})") }
                )
                Tab(
                    selected = activeSection == "Chemistry",
                    onClick = {
                        viewModel.activeStudentSection.value = "Chemistry"
                        viewModel.activeStudentQuestionIndex.value = 0
                    },
                    text = { Text("Chemistry (${snapshotPaper.questions.count { it.section == "Chemistry" }})") }
                )
                Tab(
                    selected = activeSection == "Maths",
                    onClick = {
                        viewModel.activeStudentSection.value = "Maths"
                        viewModel.activeStudentQuestionIndex.value = 0
                    },
                    text = { Text("Maths (${snapshotPaper.questions.count { it.section == "Maths" }})") }
                )
            }

            if (q == null) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No questions found in this section.")
                }
            } else {
                val studentSelectedVal = studentAnswers[q.id] ?: ""

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Question identifier info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Question ${activeIndex + 1} of ${sectionQuestions.size}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = q.type.name,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Display Question Image (if uploaded/exists)
                    if (q.questionImageStatus == ImageStatus.UPLOADED && q.questionImageUri != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp + 160.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.outline)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "[IMAGE ATTACHMENT SIMULATOR]\n${q.questionImageUri}",
                                    style = MaterialTheme.typography.labelSmall,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }

                    // Question Text content
                    if (q.text.isNotEmpty()) {
                        Text(
                            text = q.text,
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 24.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    HorizontalDivider()

                    // Student Safety enforcement: NO correct Option visible, NO solutions visible! Only answers can be recorded.
                    if (q.type == QuestionType.MCQ) {
                        Text("Select the answer option below:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            q.options.forEachIndexed { optIdx, optTxt ->
                                val label = ('A' + optIdx).toString()
                                val isSelected = studentSelectedVal == label

                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.updateStudentAnswer(q.id, label) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { viewModel.updateStudentAnswer(q.id, label) },
                                            modifier = Modifier.testTag("std_select_${label}")
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "$label: ${optTxt.ifBlank { "(Please review printed option vectors in question block image above)" }}",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // Integer answers text box
                        Text("Input Integer answer (allow negative, ignore decimals):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = studentSelectedVal,
                            onValueChange = { inputVal ->
                                val filtered = inputVal.filterIndexed { index, ch ->
                                    ch.isDigit() || (index == 0 && (ch == '-' || ch == '+'))
                                }
                                viewModel.updateStudentAnswer(q.id, filtered)
                            },
                            placeholder = { Text("e.g. -42, 5") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("std_integer_field"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }
                }

                // Friendly bottom nav row for previous/next questions
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (activeIndex > 0) viewModel.activeStudentQuestionIndex.value = activeIndex - 1
                            },
                            enabled = activeIndex > 0
                        ) {
                            Text("Previous")
                        }

                        Button(
                            onClick = { showSubmitDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Submit Exam")
                        }

                        Button(
                            onClick = {
                                if (activeIndex < sectionQuestions.size - 1) {
                                    viewModel.activeStudentQuestionIndex.value = activeIndex + 1
                                }
                            },
                            enabled = activeIndex < sectionQuestions.size - 1
                        ) {
                            Text("Next")
                        }
                    }
                }
            }
        }
    }

    if (showSubmitDialog) {
        Dialog(onDismissRequest = { showSubmitDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Help, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Submit Answers Review", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Are you sure you want to submits this exam? Total recorded marks will be instantly compiled and graded against snapshot rules.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showSubmitDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Go Back")
                        }
                        Button(
                            onClick = {
                                showSubmitDialog = false
                                viewModel.submitStudentExam()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("confirm_submit_exam_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Yes, Submit")
                        }
                    }
                }
            }
        }
    }
}
