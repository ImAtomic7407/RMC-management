package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.viewmodel.*
import com.example.data.SampleData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentMarksHistoryScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    val attempts by viewModel.attempts.collectAsState()
    val examsList by viewModel.exams.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Evaluations & Marks", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {
            Text(
                "Inspect historical graded papers. Review step-by-step vector answers if the coordination releasing flags are active.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (attempts.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "You haven't submitted any examinations yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Join any Active or Practice exam from Available list.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(attempts) { att ->
                        val exam = examsList.find { it.id == att.examId }
                        val status = exam?.status ?: ExamStatus.CLOSED

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("score_record_${att.examId}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        exam?.name ?: "Unknown Exam Session",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )

                                    Surface(
                                        color = if (status == ExamStatus.RELEASED) Color(0xFFD1FAE5) else MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (status == ExamStatus.RELEASED) "Results Live" else "Pending Evaluation",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (status == ExamStatus.RELEASED) Color(0xFF065F46) else MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Score Awarded:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                                        Text(
                                            "${att.score} Marks",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Subject Breakdowns:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                        Text(
                                            "Phy: ${att.physicsScore} | Che: ${att.chemistryScore} | Mat: ${att.mathsScore}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                if (status == ExamStatus.RELEASED) {
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                                    Button(
                                        onClick = {
                                            exam?.let { nonNullExam ->
                                                onNavigate(Screen.StudentSolutionViewer(nonNullExam.id, nonNullExam.questionPaperSnapshot.questions.firstOrNull()?.id ?: ""))
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("solution_viewer_trigger_${att.examId}"),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Open Practice Solution Viewer")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentSolutionViewerScreen(
    viewModel: ExamViewModel,
    examId: String,
    initialQuestionId: String
) {
    val examsList by viewModel.exams.collectAsState()
    val attempts by viewModel.attempts.collectAsState()

    val exam = examsList.find { it.id == examId } ?: return
    val attempt = attempts.find { it.examId == examId } ?: return
    val questions = exam.questionPaperSnapshot.questions

    var activeIndex by remember { mutableStateOf(questions.indexOfFirst { it.id == initialQuestionId }.coerceAtLeast(0)) }
    val q = questions.getOrNull(activeIndex)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Solution Booklet Review", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (q == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No matching question found.")
            }
        } else {
            val studentAns = attempt.answers[q.id] ?: "Skipped"

            // Compute score contribution for this question
            val sectionConfig = when (q.section) {
                "Physics" -> exam.questionPaperSnapshot.physicsConfig
                "Chemistry" -> exam.questionPaperSnapshot.chemistryConfig
                else -> exam.questionPaperSnapshot.mathsConfig
            }

            val isCorrect = if (q.type == QuestionType.MCQ) {
                studentAns == q.correctOption
            } else {
                viewModel.normalizeInteger(studentAns) == q.correctInteger?.toString()
            }

            val isSkipped = studentAns.isBlank() || studentAns == "Skipped"

            val marksAwarded = if (isSkipped) 0 else if (isCorrect) sectionConfig.defaultMarks else sectionConfig.defaultNegativeMarks

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Horizontal Question selector tabs (scrollable)
                ScrollableTabRow(
                    selectedTabIndex = activeIndex,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    questions.forEachIndexed { i, item ->
                        val ansVal = attempt.answers[item.id] ?: ""
                        val itemCorrect = if (item.type == QuestionType.MCQ) {
                            ansVal == item.correctOption
                        } else {
                            viewModel.normalizeInteger(ansVal) == item.correctInteger?.toString()
                        }
                        val itemSkipped = ansVal.isBlank()

                        Tab(
                            selected = activeIndex == i,
                            onClick = { activeIndex = i },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Q${i + 1}")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = if (itemSkipped) Icons.Default.Circle else if (itemCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = if (itemSkipped) Color.Gray else if (itemCorrect) Color(0xFF10B981) else Color(0xFFEF4444)
                                    )
                                }
                            }
                        )
                    }
                }

                // Solution details pane
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Question info line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${q.section} Section | Question ${activeIndex + 1}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)

                        Surface(
                            color = if (isSkipped) MaterialTheme.colorScheme.surfaceVariant
                                    else if (isCorrect) Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isSkipped) "No Marks (Skipped)"
                                       else if (isCorrect) "+$marksAwarded Marks (Correct)"
                                       else "$marksAwarded Marks (Incorrect Penalty)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSkipped) MaterialTheme.colorScheme.onSurfaceVariant
                                        else if (isCorrect) Color(0xFF065F46) else Color(0xFF991B1B),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Question texts
                    if (q.text.isNotEmpty()) {
                        Text(q.text, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    }

                    // Display question image preview simulator for reference
                    if (q.questionImageStatus == ImageStatus.UPLOADED && q.questionImageUri != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "[QUESTION ASSET REFERENCE]\n${q.questionImageUri}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }

                    HorizontalDivider()

                    // Graded performance block
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Your Submitted Response:", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = if (isSkipped) Color.LightGray else if (isCorrect) Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = " $studentAns ",
                                        fontWeight = FontWeight.Black,
                                        color = if (isSkipped) Color.DarkGray else if (isCorrect) Color(0xFF065F46) else Color(0xFF991B1B),
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )
                                }
                            }

                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Correct Evaluated Answer:", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = Color(0xFFD1FAE5),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (q.type == QuestionType.MCQ) " ${q.correctOption} " else " ${q.correctInteger} ",
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF065F46),
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    // SOLUTION DESIGN SCHEME (STUDENT SEES SOLUTIONS ONLY UNDER THIS POLICY FLOW!)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lightbulb, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Solution Blueprint Explanation", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            }

                            // SOLUTION Image Display
                            if (q.solutionImageStatus == ImageStatus.UPLOADED && q.solutionImageUri != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(150.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFE2E8F0)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DoneOutline, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "[DECRYPTED EXAM PREVIEW SOLUTION]\nFile: ${q.solutionImageUri}\nShows detailed step-by-step mathematical proofs.",
                                            style = MaterialTheme.typography.labelSmall,
                                            textAlign = TextAlign.Center,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.DarkGray
                                        )
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "No blueprint visualization registered for this question. Consult textbook modules.",
                                        style = MaterialTheme.typography.bodySmall,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            // Sample explaining description
                            Text(
                                text = "Applying thermodynamic laws and hybrid atomic orbital rules to balance physical coordinates. Substitute values into equation variables to establish constant state formulas.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
            }
        }
    }
}
