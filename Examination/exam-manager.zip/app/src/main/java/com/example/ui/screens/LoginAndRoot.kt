package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.viewmodel.*

@Composable
fun LoginScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        MaterialTheme.colorScheme.background
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Task,
                contentDescription = "Logo",
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Exam Manager",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Professional Academic Examination Suite",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                "Access Portal Roles Selection",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Teacher Role Trigger Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(Screen.TeacherHome) }
                    .testTag("login_as_teacher_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sign In as Instructor / Admin", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text("Draft Papers, schedule Exams, release marked analytics.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }

                    Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                }
            }

            // Student Role Trigger Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(Screen.StudentHome) }
                    .testTag("login_as_student_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sign In as Student Candidate", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text("Attempt schedules, track history, open Solutions booklets.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }

                    Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Footer metadata
            Text(
                "Build Version 3.4.1 | Offline Active Simulator",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun AppMasterView(viewModel: ExamViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val statusMsg by viewModel.statusMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMsg) {
        statusMsg?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            }
        ) { screen ->
            when (screen) {
                is Screen.Login -> LoginScreen(viewModel) { viewModel.navigateTo(it) }

                // Teacher routes
                is Screen.TeacherHome -> TeacherHomeScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.TeacherPapers -> TeacherPapersScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.TeacherCreatePaper -> TeacherCreatePaperScreen(viewModel, screen.editingPaperId) { viewModel.navigateTo(it) }
                is Screen.TeacherPaperEditor -> TeacherPaperEditorScreen(viewModel, screen.paperId) { viewModel.navigateTo(it) }
                is Screen.TeacherEditQuestion -> TeacherEditQuestionScreen(viewModel, screen.paperId, screen.questionId, screen.section, screen.type)
                is Screen.TeacherScheduleExam -> TeacherScheduleExamScreen(viewModel, screen.paperId)
                is Screen.TeacherExams -> TeacherExamsScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.TeacherResults -> TeacherResultsScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.TeacherLeaderboard -> TeacherLeaderboardScreen(viewModel, screen.examId)

                // Student routes
                is Screen.StudentHome -> StudentHomeScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.StudentAvailableExams -> StudentAvailableExamsScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.StudentAttempt -> StudentAttemptScreen(viewModel, screen.examId)
                is Screen.StudentMarksHistory -> StudentMarksHistoryScreen(viewModel) { viewModel.navigateTo(it) }
                is Screen.StudentSolutionViewer -> StudentSolutionViewerScreen(viewModel, screen.examId, screen.activeQuestionId)
                is Screen.StudentLeaderboard -> TeacherLeaderboardScreen(viewModel, screen.examId) // reuse common leaderboard layout
                else -> LoginScreen(viewModel) { viewModel.navigateTo(it) }
            }
        }

        // Floating Toast Snackbars
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
        )
    }
}
