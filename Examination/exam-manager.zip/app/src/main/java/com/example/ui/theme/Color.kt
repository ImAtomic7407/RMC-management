package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette Slate-Blue
val SlatePrimary = Color(0xFF1E3A8A)      // Deep Navy Academic Blue
val SlateSecondary = Color(0xFF2563EB)    // Action Blue
val SlateTertiary = Color(0xFF0D9488)     // Teal Accents
val SlateBackground = Color(0xFFF8FAFC)   // Crisp slate gray background
val SlateSurface = Color(0xFFFFFFFF)      // Pure white containers
val SlateError = Color(0xFFDC2626)        // Status alarm red

// Dark Palette Slate-Blue
val SlateDarkPrimary = Color(0xFF60A5FA)    // Soft sky action blue
val SlateDarkSecondary = Color(0xFF93C5FD)  // Indigo highlight
val SlateDarkTertiary = Color(0xFF2DD4BF)   // Radiant teal
val SlateDarkBackground = Color(0xFF0F172A) // Intense Slate Night
val SlateDarkSurface = Color(0xFF1E293B)    // Layered Dark Slate
val SlateDarkError = Color(0xFFF87171)      // High clarity Red
