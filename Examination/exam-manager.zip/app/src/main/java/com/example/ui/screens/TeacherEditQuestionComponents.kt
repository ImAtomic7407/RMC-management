package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.viewmodel.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherEditQuestionScreen(
    viewModel: ExamViewModel,
    paperId: String,
    questionId: String?,
    section: String,
    type: QuestionType
) {
    val qText by viewModel.questionTextInput.collectAsState()
    val optionTextsList by viewModel.optionTexts.collectAsState()
    val correctMCQ by viewModel.correctMCQOption.collectAsState()
    val correctInt by viewModel.correctIntegerInput.collectAsState()

    // Question Image state
    val qImgUri by viewModel.questionImageUri.collectAsState()
    val qImgStatus by viewModel.questionImageStatus.collectAsState()

    // Solution Image state
    val sImgUri by viewModel.solutionImageUri.collectAsState()
    val sImgStatus by viewModel.solutionImageStatus.collectAsState()

    // Crop simulator state
    val showCrop by viewModel.showCropDialog.collectAsState()
    val cropType by viewModel.croppingImageType.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (questionId == null) "Add $section $type" else "Edit $section $type") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section & Type Header display (read-only per user instruction)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$section Section", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    SuggestionChip(onClick = {}, label = { Text(type.name, fontWeight = FontWeight.Bold) })
                }
            }

            // Question CONTENT Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("1. Question Visuals & Text", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                    // QUESTION Image Simulator Block
                    MediaSimulatorBlock(
                        title = "Question Image",
                        imageUri = qImgUri,
                        status = qImgStatus,
                        onSimulateUpload = { viewModel.simulateQuestionImageUpload(takePhoto = false) },
                        onSimulateCamera = { viewModel.simulateQuestionImageUpload(takePhoto = true) },
                        onSimulateCrop = { viewModel.startCrop("QUESTION") },
                        onClear = { viewModel.clearQuestionImage() }
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Question Text Formulation (Optional):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = qText,
                        onValueChange = { viewModel.questionTextInput.value = it },
                        placeholder = { Text("Describe chemical formulas, mathematical integrals or general definitions...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("question_text_input"),
                        minLines = 3,
                        maxLines = 6
                    )
                }
            }

            // MCQ Option Layout or INTEGER Answer Field
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("2. Answer Keys", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                    if (type == QuestionType.MCQ) {
                        Text(
                            "Options always containing A, B, C, D (option text optional):",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            optionTextsList.forEachIndexed { idx, optVal ->
                                val label = ('A' + idx).toString()
                                val isSelected = correctMCQ == label

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    IconButton(
                                        onClick = { viewModel.correctMCQOption.value = label },
                                        modifier = Modifier.testTag("mark_mcq_${label}")
                                    ) {
                                        Icon(
                                            if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = "Mark Correct",
                                            tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                        )
                                    }

                                    OutlinedTextField(
                                        value = optVal,
                                        onValueChange = { viewModel.updateOptionText(idx, it) },
                                        label = { Text("Option $label text") },
                                        placeholder = { Text("[Printed in question image]") },
                                        modifier = Modifier.weight(1f),
                                        singleLine = true
                                    )
                                }
                            }
                        }
                    } else {
                        // INTEGER block
                        Text("Compact Correct Integer Answer Field:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = correctInt,
                            onValueChange = { inputString ->
                                // Filtering rules: allow single leading minus, reject decimals, reject letters
                                val sanitized = inputString.filterIndexed { index, ch ->
                                    ch.isDigit() || (index == 0 && (ch == '-' || ch == '+'))
                                }
                                viewModel.correctIntegerInput.value = sanitized
                            },
                            placeholder = { Text("Enter correct integer, e.g. -42, 5") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("integer_correct_field"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            trailingIcon = {
                                if (correctInt.isNotEmpty()) {
                                    val normal = viewModel.normalizeInteger(correctInt)
                                    if (normal.isNotEmpty() && normal != correctInt) {
                                        Text(
                                            "Normalizes to: $normal",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                    }
                                }
                            }
                        )
                    }
                }
            }

            // SOLUTION Media block
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("3. Practice Solution & Explanation", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Upload full detailed printed solutions for the Practice Solution Viewer:", style = MaterialTheme.typography.bodySmall)

                    MediaSimulatorBlock(
                        title = "Solution Blueprint Image",
                        imageUri = sImgUri,
                        status = sImgStatus,
                        onSimulateUpload = { viewModel.simulateSolutionImageUpload(takePhoto = false) },
                        onSimulateCamera = { viewModel.simulateSolutionImageUpload(takePhoto = true) },
                        onSimulateCrop = { viewModel.startCrop("SOLUTION") },
                        onClear = { viewModel.clearSolutionImage() }
                    )
                }
            }

            // Bottom CTA Saves
            Button(
                onClick = { viewModel.saveQuestion(paperId, questionId, section, type) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .testTag("save_question_btn")
            ) {
                Text("Review & Save Question", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Interactive Crop simulation dialogue
    if (showCrop) {
        Dialog(onDismissRequest = { viewModel.showCropDialog.value = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Interactive Cropping Simulator", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Crop boundary has been locked to [4:3 aspect ratio] for optimized $cropType layouts.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(Color.Gray.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            modifier = Modifier
                                .size(110.dp)
                                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp)),
                            color = Color.Transparent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("CROP BOUNDS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.showCropDialog.value = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Reject")
                        }
                        Button(
                            onClick = { viewModel.confirmCrop() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Apply Crop")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaSimulatorBlock(
    title: String,
    imageUri: String?,
    status: ImageStatus,
    onSimulateUpload: () -> Unit,
    onSimulateCamera: () -> Unit,
    onSimulateCrop: () -> Unit,
    onClear: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)

                // Current mock status badge
                Surface(
                    color = when (status) {
                        ImageStatus.IDLE -> MaterialTheme.colorScheme.outlineVariant
                        ImageStatus.LOCALLY_SELECTED -> MaterialTheme.colorScheme.surface
                        ImageStatus.UPLOADING -> MaterialTheme.colorScheme.secondaryContainer
                        ImageStatus.UPLOADED -> MaterialTheme.colorScheme.primaryContainer
                        ImageStatus.FAILED -> MaterialTheme.colorScheme.errorContainer
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = when (status) {
                            ImageStatus.IDLE -> "No Image Selected"
                            ImageStatus.LOCALLY_SELECTED -> "Selected Locally"
                            ImageStatus.UPLOADING -> "Uploading..."
                            ImageStatus.UPLOADED -> "Uploaded Successfully"
                            ImageStatus.FAILED -> "Upload Failed"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (status) {
                            ImageStatus.FAILED -> MaterialTheme.colorScheme.error
                            ImageStatus.UPLOADED -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Simulated progress bar if uploading
            if (status == ImageStatus.UPLOADING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
            } else if (status == ImageStatus.UPLOADED && imageUri != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "IMAGE PREVIEW SIMULATOR\nFile: $imageUri",
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else if (status == ImageStatus.FAILED) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Error uploading asset. Low networking speed.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = onSimulateUpload,
                    label = { Text("Upload File") },
                    leadingIcon = { Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                AssistChip(
                    onClick = onSimulateCamera,
                    label = { Text("Take Camera Photo") },
                    leadingIcon = { Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                if (status == ImageStatus.UPLOADED || status == ImageStatus.LOCALLY_SELECTED) {
                    AssistChip(
                        onClick = onSimulateCrop,
                        label = { Text("Crop") },
                        leadingIcon = { Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    AssistChip(
                        onClick = onClear,
                        label = { Text("Remove") },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }
                if (status == ImageStatus.FAILED) {
                    AssistChip(
                        onClick = onSimulateUpload,
                        label = { Text("Retry Upload") },
                        leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }
            }
        }
    }
}

// IMMUTABLE SCHEDULING SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherScheduleExamScreen(
    viewModel: ExamViewModel,
    paperId: String
) {
    val papersVal by viewModel.papers.collectAsState()
    val paper = papersVal.find { it.id == paperId } ?: return

    var examNameInput by remember { mutableStateOf("") }
    var durationMinutesInput by remember { mutableStateOf("180") }
    var dateInput by remember { mutableStateOf("2026-05-22 09:00") }
    var isPracticeChecked by remember { mutableStateOf(false) }

    var showConfirmationDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Schedule Scheduled Exam") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Source details
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Selected Target Source Paper:", style = MaterialTheme.typography.bodySmall)
                        Text(paper.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text("${paper.questions.size} reusable questions available.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Text("Scheduled Event Configurations", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = examNameInput,
                onValueChange = { examNameInput = it },
                label = { Text("Exam Name / Session Title") },
                placeholder = { Text("e.g. Annual Advanced Prep Examination Series A") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("schedule_exam_name_field"),
                singleLine = true
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = durationMinutesInput,
                    onValueChange = { durationMinutesInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Duration (Mins)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                OutlinedTextField(
                    value = dateInput,
                    onValueChange = { dateInput = it },
                    label = { Text("Scheduled Date & Time") },
                    modifier = Modifier.weight(1.5f),
                    singleLine = true
                )
            }

            // Mode selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("Publish as Practice Screen", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("Students can attempt this as free homework anytime without strict schedule clocks.", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = isPracticeChecked,
                        onCheckedChange = { isPracticeChecked = it }
                    )
                }
            }

            // Scheduling triggers confirmation dialogue per instructions
            Button(
                onClick = { showConfirmationDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .testTag("schedule_confirmation_trigger")
            ) {
                Icon(Icons.Default.Lock, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Confirm Event Lock", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showConfirmationDialog) {
        Dialog(onDismissRequest = { showConfirmationDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "IMMUTABLE PAPER LOCK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    // Strict requirement text:
                    Text(
                        text = "You are scheduling this exam using the selected question paper. A locked copy of the paper will be saved for this exam. Later changes to the original question paper will not affect this exam.",
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showConfirmationDialog = false },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("cancel_schedule_btn")
                        ) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                showConfirmationDialog = false
                                viewModel.scheduleExam(
                                    paperId = paperId,
                                    examName = examNameInput,
                                    scheduledTime = dateInput,
                                    durationMinutes = durationMinutesInput.toIntOrNull() ?: 180,
                                    isPractice = isPracticeChecked
                                )
                            },
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("confirm_schedule_btn")
                        ) {
                            Text("Schedule Exam")
                        }
                    }
                }
            }
        }
    }
}
