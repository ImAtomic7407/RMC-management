package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.example.model.*
import com.example.viewmodel.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherHomeScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    val papersList by viewModel.papers.collectAsState()
    val examsList by viewModel.exams.collectAsState()
    val totalAttempts = 42 // Mock metric

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Teacher Portal", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.Login) },
                        modifier = Modifier.testTag("logout_btn")
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Log Out")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Welcome, ${viewModel.teacherName}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Manage your Question Papers, schedule Exams, and monitor real-time class standings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Book, contentDescription = "PapersCount", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("${papersList.size}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Source Papers", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Event, contentDescription = "ExamsCount", tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("${examsList.size}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Active Exams", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text("Core Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

            // Direct Navigation Actions Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.initCreatePaper(null)
                        onNavigate(Screen.TeacherCreatePaper(null))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .testTag("create_paper_action"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create Paper", fontWeight = FontWeight.SemiBold)
                }

                FilledTonalButton(
                    onClick = { onNavigate(Screen.TeacherPapers) },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .testTag("view_papers_action")
                ) {
                    Icon(Icons.Default.Folder, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("View Papers", fontWeight = FontWeight.SemiBold)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilledTonalButton(
                    onClick = { onNavigate(Screen.TeacherExams) },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .testTag("view_exams_action")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Live / All Exams", fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = { onNavigate(Screen.TeacherResults) },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .testTag("view_results_action")
                ) {
                    Icon(Icons.Default.Leaderboard, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Class Standings", fontWeight = FontWeight.SemiBold)
                }
            }

            // Quick Info Banner on Snapshots
            Card(
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Snapshot Design Safety Guaranteed", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Every Scheduled Exam stores a local, sealed snapshot copy of the reusable source paper.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherPapersScreen(
    viewModel: ExamViewModel,
    onNavigate: (Screen) -> Unit
) {
    val papersList by viewModel.papers.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reusable Source Papers", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.initCreatePaper(null)
                            onNavigate(Screen.TeacherCreatePaper(null))
                        },
                        modifier = Modifier.testTag("floating_add_paper")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add New Paper")
                    }
                }
            )
        }
    ) { padding ->
        if (papersList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Book, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No question papers created yet.", color = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        viewModel.initCreatePaper(null)
                        onNavigate(Screen.TeacherCreatePaper(null))
                    }) {
                        Text("Create First Paper")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(papersList) { paper ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(Screen.TeacherPaperEditor(paper.id)) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(paper.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Row {
                                    IconButton(onClick = {
                                        viewModel.initCreatePaper(paper.id)
                                        onNavigate(Screen.TeacherCreatePaper(paper.id))
                                    }) {
                                        Icon(Icons.Default.Settings, contentDescription = "Edit Defaults", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                            Text("Section Defaults & Configurations:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                SectionBadge(config = paper.physicsConfig)
                                SectionBadge(config = paper.chemistryConfig)
                                SectionBadge(config = paper.mathsConfig)
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "${paper.questions.size} Questions Configured",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = { onNavigate(Screen.TeacherScheduleExam(paper.id)) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.testTag("schedule_action_${paper.id}")
                                    ) {
                                        Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Schedule Exam", style = MaterialTheme.typography.labelMedium)
                                    }
                                    Button(
                                        onClick = { onNavigate(Screen.TeacherPaperEditor(paper.id)) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    ) {
                                        Text("Edit Questions", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SectionBadge(config: SectionConfig) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text(config.sectionName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            Text("${config.targetQuestionCount} Qs | +${config.defaultMarks}/${config.defaultNegativeMarks}", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherCreatePaperScreen(
    viewModel: ExamViewModel,
    editingPaperId: String?,
    onNavigate: (Screen) -> Unit
) {
    val paperName by viewModel.paperNameInput.collectAsState()

    // Physics configs
    val pCount by viewModel.physicsQuestionsCount.collectAsState()
    val pMarks by viewModel.physicsMarks.collectAsState()
    val pNeg by viewModel.physicsNegative.collectAsState()

    // Chemistry configs
    val cCount by viewModel.chemistryQuestionsCount.collectAsState()
    val cMarks by viewModel.chemistryMarks.collectAsState()
    val cNeg by viewModel.chemistryNegative.collectAsState()

    // Maths configs
    val mCount by viewModel.mathsQuestionsCount.collectAsState()
    val mMarks by viewModel.mathsMarks.collectAsState()
    val mNeg by viewModel.mathsNegative.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editingPaperId == null) "New Paper Config" else "Update Configurations") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = paperName,
                onValueChange = { viewModel.paperNameInput.value = it },
                label = { Text("Question Paper Title") },
                placeholder = { Text("e.g. JEE Mock Test Series 1") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("paper_title_field"),
                singleLine = true
            )

            Text(
                "Define Defaults (Set per-section. No individual question pricing avoids visual noise):",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )

            // Section editor components
            SectionConfigurationCard(
                sectionName = "Physics",
                countState = viewModel.physicsQuestionsCount,
                marksState = viewModel.physicsMarks,
                negState = viewModel.physicsNegative
            )

            SectionConfigurationCard(
                sectionName = "Chemistry",
                countState = viewModel.chemistryQuestionsCount,
                marksState = viewModel.chemistryMarks,
                negState = viewModel.chemistryNegative
            )

            SectionConfigurationCard(
                sectionName = "Maths",
                countState = viewModel.mathsQuestionsCount,
                marksState = viewModel.mathsMarks,
                negState = viewModel.mathsNegative
            )

            Button(
                onClick = { viewModel.saveQuestionPaper(editingPaperId) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .testTag("save_paper_config_btn")
            ) {
                Text(
                    if (editingPaperId == null) "Create Reusable Paper" else "Save Configurations",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SectionConfigurationCard(
    sectionName: String,
    countState: MutableStateFlow<String>,
    marksState: MutableStateFlow<String>,
    negState: MutableStateFlow<String>
) {
    val count by countState.collectAsState()
    val marks by marksState.collectAsState()
    val neg by negState.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(sectionName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = count,
                    onValueChange = { countState.value = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Target Qs") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                OutlinedTextField(
                    value = marks,
                    onValueChange = { marksState.value = it.filter { ch -> ch.isDigit() } },
                    label = { Text("+ Marks/Q") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                OutlinedTextField(
                    value = neg,
                    onValueChange = { negState.value = it.filter { ch -> ch.isDigit() || ch == '-' } },
                    label = { Text("- Marks/Q") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherPaperEditorScreen(
    viewModel: ExamViewModel,
    paperId: String,
    onNavigate: (Screen) -> Unit
) {
    val papersList by viewModel.papers.collectAsState()
    val paper = papersList.find { it.id == paperId } ?: return

    var activeTab by remember { mutableStateOf("Physics") }
    val questions = paper.questions.filter { it.section == activeTab }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(paper.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Preview total marks indicator
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.padding(end = 12.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            "${paper.questions.size} Qs Saved",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExtendedFloatingActionButton(
                    text = { Text("Add MCQ") },
                    icon = { Icon(Icons.Default.Quiz, contentDescription = null) },
                    onClick = {
                        viewModel.initQuestionEdit(paperId, null)
                        onNavigate(Screen.TeacherEditQuestion(paperId, null, activeTab, QuestionType.MCQ))
                    },
                    modifier = Modifier.testTag("add_mcq_fab"),
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )

                FloatingActionButton(
                    onClick = {
                        viewModel.initQuestionEdit(paperId, null)
                        onNavigate(Screen.TeacherEditQuestion(paperId, null, activeTab, QuestionType.INTEGER))
                    },
                    modifier = Modifier.testTag("add_integer_fab"),
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                ) {
                    Icon(Icons.Default.Filter1, contentDescription = "Add INTEGER Question")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab row for Physics Chemistry Maths
            TabRow(selectedTabIndex = when(activeTab) {
                "Physics" -> 0
                "Chemistry" -> 1
                else -> 2
            }) {
                Tab(
                    selected = activeTab == "Physics",
                    onClick = { activeTab = "Physics" },
                    text = { Text("Physics (${paper.questions.count { it.section == "Physics" }})") }
                )
                Tab(
                    selected = activeTab == "Chemistry",
                    onClick = { activeTab = "Chemistry" },
                    text = { Text("Chemistry (${paper.questions.count { it.section == "Chemistry" }})") }
                )
                Tab(
                    selected = activeTab == "Maths",
                    onClick = { activeTab = "Maths" },
                    text = { Text("Maths (${paper.questions.count { it.section == "Maths" }})") }
                )
            }

            // Display of limits and warnings
            val limitConfig = when(activeTab) {
                "Physics" -> paper.physicsConfig
                "Chemistry" -> paper.chemistryConfig
                else -> paper.mathsConfig
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Suggested Count Target: ${limitConfig.targetQuestionCount} questions",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "Defaults: +${limitConfig.defaultMarks} / ${limitConfig.defaultNegativeMarks}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (questions.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.Drafts, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No questions inside $activeTab section yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Create standard MCQ options or Numerical Integer questions below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(questions) { q ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("question_item_${q.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text(q.type.name, fontWeight = FontWeight.Bold) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        // Image indicators
                                        if (q.questionImageUri != null) {
                                            Icon(Icons.Default.Image, contentDescription = "Has Question Image", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                        }
                                        if (q.solutionImageUri != null) {
                                            Icon(Icons.Default.Done, contentDescription = "Has Solution Image", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.tertiary)
                                        }
                                    }

                                    Row {
                                        IconButton(onClick = {
                                            viewModel.initQuestionEdit(paperId, q.id)
                                            onNavigate(Screen.TeacherEditQuestion(paperId, q.id, activeTab, q.type))
                                        }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Question", tint = MaterialTheme.colorScheme.primary)
                                        }
                                        IconButton(onClick = { viewModel.deleteQuestion(paperId, q.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Question", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                Text(
                                    text = q.text.ifBlank { "[No text query - visual question]" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )

                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                                // MCQ answer key
                                if (q.type == QuestionType.MCQ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        q.options.forEachIndexed { optIndex, optText ->
                                            val label = ('A' + optIndex).toString()
                                            val isCorrect = q.correctOption == label
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                RadioButton(selected = isCorrect, onClick = {})
                                                Text(
                                                    "$label: ${optText.ifBlank { "(See image options)" }}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isCorrect) MaterialTheme.colorScheme.primary else Color.Unspecified
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    // INTEGER correct key
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.tertiary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "Correct Integer Entry: ",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Surface(
                                            color = MaterialTheme.colorScheme.tertiaryContainer,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                " ${q.correctInteger ?: 0} ",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
