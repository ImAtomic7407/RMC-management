package com.example.data

import com.example.model.*

object SampleData {
    val initialQuestions1 = listOf(
        // PHYSICS
        Question(
            id = "q_p1",
            section = "Physics",
            type = QuestionType.MCQ,
            text = "A block of mass m is placed on a smooth inclined plane of angle θ. The normal reaction force exerted on the block by the plane is:",
            options = listOf("m g cos θ", "m g sin θ", "m g", "m g / cos θ"),
            correctOption = "A",
            questionImageUri = "https://example.com/physics_wedge.png",
            questionImageStatus = ImageStatus.UPLOADED,
            solutionImageUri = "https://example.com/sol_physics_wedge.png",
            solutionImageStatus = ImageStatus.UPLOADED
        ),
        Question(
            id = "q_p2",
            section = "Physics",
            type = QuestionType.INTEGER,
            text = "An ideal heat engine operates in a Carnot cycle between 600 K and 300 K. What is the percentage thermal efficiency of this engine?",
            correctInteger = 50,
            questionImageUri = null,
            questionImageStatus = ImageStatus.IDLE,
            solutionImageUri = null,
            solutionImageStatus = ImageStatus.IDLE
        ),
        // CHEMISTRY
        Question(
            id = "q_c1",
            section = "Chemistry",
            type = QuestionType.MCQ,
            text = "Among the following chemical species, which one has a perfectly tetrahedral geometry according to VSEPR theory?",
            options = listOf("SF4", "XeF4", "CH4", "BF3"),
            correctOption = "C",
            questionImageUri = null,
            questionImageStatus = ImageStatus.IDLE,
            solutionImageUri = "https://example.com/sol_chem_hybrid.png",
            solutionImageStatus = ImageStatus.UPLOADED
        ),
        Question(
            id = "q_c2",
            section = "Chemistry",
            type = QuestionType.INTEGER,
            text = "Calculate the oxidation number of Chromium (Cr) in a molecule of Potassium Dichromate (K₂Cr₂O₇).",
            correctInteger = 6,
            questionImageUri = "https://example.com/chem_struct.png",
            questionImageStatus = ImageStatus.UPLOADED,
            solutionImageUri = null,
            solutionImageStatus = ImageStatus.IDLE
        ),
        // MATHS
        Question(
            id = "q_m1",
            section = "Maths",
            type = QuestionType.MCQ,
            text = "If log₂ (x) + log₄ (x) = 3, what is the exact value of x?",
            options = listOf("2", "4", "8", "16"),
            correctOption = "B",
            questionImageUri = null,
            questionImageStatus = ImageStatus.IDLE,
            solutionImageUri = null,
            solutionImageStatus = ImageStatus.IDLE
        ),
        Question(
            id = "q_m2",
            section = "Maths",
            type = QuestionType.INTEGER,
            text = "Evaluate the limit of the function as x approaches zero: lim_{x -> 0} (sin(5x) / x).",
            correctInteger = 5,
            questionImageUri = null,
            questionImageStatus = ImageStatus.IDLE,
            solutionImageUri = null,
            solutionImageStatus = ImageStatus.IDLE
        )
    )

    val initialPapers = listOf(
        QuestionPaper(
            id = "qp_1",
            name = "JEE Advanced Mock Paper 1",
            physicsConfig = SectionConfig("Physics", 2, 4, -1),
            chemistryConfig = SectionConfig("Chemistry", 2, 4, -1),
            mathsConfig = SectionConfig("Maths", 2, 4, -1),
            questions = initialQuestions1
        ),
        QuestionPaper(
            id = "qp_2",
            name = "AIEEE Practice Screening Test",
            physicsConfig = SectionConfig("Physics", 4, 3, -1),
            chemistryConfig = SectionConfig("Chemistry", 4, 3, -1),
            mathsConfig = SectionConfig("Maths", 4, 3, -1),
            questions = initialQuestions1.take(3).map { it.copy(id = "copy_" + it.id) }
        )
    )

    val initialExams = listOf(
        Exam(
            id = "ex_1",
            name = "JEE Main Revision Practice - 1",
            originalPaperId = "qp_1",
            scheduledTime = "2026-05-22 09:00",
            durationMinutes = 180,
            status = ExamStatus.LIVE,
            questionPaperSnapshot = initialPapers[0] // original frozen version
        ),
        Exam(
            id = "ex_2",
            name = "NEET Target Level Chemistry Test (Release Active)",
            originalPaperId = "qp_2",
            scheduledTime = "2026-05-18 14:00",
            durationMinutes = 120,
            status = ExamStatus.RELEASED,
            questionPaperSnapshot = initialPapers[1]
        ),
        Exam(
            id = "ex_3",
            name = "Upcoming Practice Series 3",
            originalPaperId = "qp_1",
            scheduledTime = "2026-05-24 10:00",
            durationMinutes = 180,
            status = ExamStatus.SCHEDULED,
            questionPaperSnapshot = initialPapers[0]
        )
    )

    val initialLeaderboard = listOf(
        LeaderboardEntry(1, "Rohan Sharma", 24, 8, 8, 8, "Top Percentile"),
        LeaderboardEntry(2, "Ananya Sen", 20, 8, 4, 8, "98th Percentile"),
        LeaderboardEntry(3, "Kabir Mehta", 15, 4, 3, 8, "95th Percentile"),
        LeaderboardEntry(4, "Aditi Roy", 11, 4, 4, 3, "90th Percentile")
    )
}
