package com.example.model

enum class QuestionType {
    MCQ, INTEGER
}

enum class ImageStatus {
    IDLE,
    LOCALLY_SELECTED,
    UPLOADING,
    UPLOADED,
    FAILED
}

enum class ExamStatus {
    SCHEDULED,
    LIVE,
    PRACTICE,
    CLOSED,
    RELEASED
}

data class SectionConfig(
    val sectionName: String, // "Physics", "Chemistry", "Maths"
    val targetQuestionCount: Int,
    val defaultMarks: Int,
    val defaultNegativeMarks: Int
)

data class Question(
    val id: String,
    val section: String, // "Physics", "Chemistry", "Maths"
    val type: QuestionType,
    val text: String = "",
    val questionImageUri: String? = null,
    val questionImageStatus: ImageStatus = ImageStatus.IDLE,
    val options: List<String> = listOf("", "", "", ""), // MCQ only option labels (optional)
    val correctOption: String? = null, // "A", "B", "C", "D"
    val correctInteger: Int? = null, // INTEGER only
    val solutionImageUri: String? = null,
    val solutionImageStatus: ImageStatus = ImageStatus.IDLE
)

data class QuestionPaper(
    val id: String,
    val name: String,
    val physicsConfig: SectionConfig = SectionConfig("Physics", 5, 4, -1),
    val chemistryConfig: SectionConfig = SectionConfig("Chemistry", 5, 4, -1),
    val mathsConfig: SectionConfig = SectionConfig("Maths", 5, 4, -1),
    val questions: List<Question> = emptyList()
)

data class Exam(
    val id: String,
    val name: String,
    val originalPaperId: String,
    val scheduledTime: String,
    val durationMinutes: Int = 180,
    val status: ExamStatus,
    val questionPaperSnapshot: QuestionPaper // Immutable locked copy
)

data class ExamAttempt(
    val id: String,
    val examId: String,
    val studentId: String,
    val studentName: String,
    val answers: Map<String, String> = emptyMap(), // Question ID -> Answer ("A"/"B"/"C"/"D" or Integer string)
    val startTime: Long = System.currentTimeMillis(),
    val submittedTime: Long? = null,
    val isSubmitted: Boolean = false,
    val score: Int = 0,
    val physicsScore: Int = 0,
    val chemistryScore: Int = 0,
    val mathsScore: Int = 0
)

data class LeaderboardEntry(
    val rank: Int,
    val studentName: String,
    val totalScore: Int,
    val physicsScore: Int,
    val chemistryScore: Int,
    val mathsScore: Int,
    val relativeRankTag: String = ""
)
