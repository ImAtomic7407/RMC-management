package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.data.SampleData
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface Screen {
    object Login : Screen
    object TeacherHome : Screen
    object TeacherPapers : Screen
    data class TeacherCreatePaper(val editingPaperId: String? = null) : Screen
    data class TeacherPaperEditor(val paperId: String) : Screen
    data class TeacherEditQuestion(
        val paperId: String,
        val questionId: String?,
        val section: String,
        val type: QuestionType
    ) : Screen
    data class TeacherScheduleExam(val paperId: String) : Screen
    object TeacherExams : Screen
    object TeacherResults : Screen
    data class TeacherLeaderboard(val examId: String) : Screen

    object StudentHome : Screen
    object StudentAvailableExams : Screen
    data class StudentAttempt(val examId: String) : Screen
    object StudentMarksHistory : Screen
    data class StudentResultDetail(val attemptId: String) : Screen
    data class StudentLeaderboard(val examId: String) : Screen
    data class StudentSolutionViewer(val examId: String, val activeQuestionId: String) : Screen
}

class ExamViewModel : ViewModel() {

    // Mock profiles
    val teacherName = "Dr. Sarah Jenkins"
    val studentName = "Rohan Sharma"
    val studentRoll = "IIT-2026-042"

    // Backstack for navigation
    private val _backstack = MutableStateFlow<List<Screen>>(listOf(Screen.Login))
    val currentScreen: StateFlow<Screen> = MutableStateFlow<Screen>(Screen.Login).apply {
        viewModelScope.launch {
            _backstack.collect { screens ->
                value = screens.lastOrNull() ?: Screen.Login
            }
        }
    }

    // Question Papers
    private val _papers = MutableStateFlow<List<QuestionPaper>>(SampleData.initialPapers)
    val papers = _papers.asStateFlow()

    // Exams (Scheduled/Live/Closed/Released)
    private val _exams = MutableStateFlow<List<Exam>>(SampleData.initialExams)
    val exams = _exams.asStateFlow()

    // Student Attempts
    private val _attempts = MutableStateFlow<List<ExamAttempt>>(emptyList())
    val attempts = _attempts.asStateFlow()

    // Active state for Create/Edit Paper
    val paperNameInput = MutableStateFlow("")
    val physicsQuestionsCount = MutableStateFlow("5")
    val physicsMarks = MutableStateFlow("4")
    val physicsNegative = MutableStateFlow("-1")

    val chemistryQuestionsCount = MutableStateFlow("5")
    val chemistryMarks = MutableStateFlow("4")
    val chemistryNegative = MutableStateFlow("-1")

    val mathsQuestionsCount = MutableStateFlow("5")
    val mathsMarks = MutableStateFlow("4")
    val mathsNegative = MutableStateFlow("-1")

    // Active state for Question Editing
    val questionTextInput = MutableStateFlow("")
    private val _optionTexts = MutableStateFlow(listOf("", "", "", ""))
    val optionTexts = _optionTexts.asStateFlow()
    val correctMCQOption = MutableStateFlow<String?>("A") // "A", "B", "C", "D"
    val correctIntegerInput = MutableStateFlow("") // For INTEGER types

    // Interactive Media Upload simulation
    // Question Image
    private val _questionImageUri = MutableStateFlow<String?>(null)
    val questionImageUri = _questionImageUri.asStateFlow()

    private val _questionImageStatus = MutableStateFlow(ImageStatus.IDLE)
    val questionImageStatus = _questionImageStatus.asStateFlow()

    // Solution Image
    private val _solutionImageUri = MutableStateFlow<String?>(null)
    val solutionImageUri = _solutionImageUri.asStateFlow()

    private val _solutionImageStatus = MutableStateFlow(ImageStatus.IDLE)
    val solutionImageStatus = _solutionImageStatus.asStateFlow()

    // Crop simulator flag
    val showCropDialog = MutableStateFlow(false)
    val croppingImageType = MutableStateFlow<String>("") // "QUESTION" or "SOLUTION"

    // Student Active Attempt state
    private val _activeAttempt = MutableStateFlow<ExamAttempt?>(null)
    val activeAttempt = _activeAttempt.asStateFlow()
    val activeStudentQuestionIndex = MutableStateFlow(0)
    val activeStudentSection = MutableStateFlow("Physics") // "Physics", "Chemistry", "Maths"

    // Toast/Feedback state helper
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage = _statusMessage.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun navigateTo(screen: Screen) {
        val current = _backstack.value.toMutableList()
        current.add(screen)
        _backstack.value = current
    }

    fun navigateBack() {
        val current = _backstack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _backstack.value = current
        }
    }

    fun navigateToHome() {
        _backstack.value = listOf(Screen.Login)
    }

    // Integer String Normalization Helper
    fun normalizeInteger(input: String): String {
        // Only keep minus sign and digits
        val clean = input.filter { it.isDigit() || it == '-' || it == '+' }
        if (clean.isEmpty() || clean == "-" || clean == "+") return ""

        // Try parsing
        try {
            val isNegative = clean.startsWith("-")
            val digits = clean.filter { it.isDigit() }
            if (digits.isEmpty()) return ""
            val intVal = digits.toInt() // automatically Strips leading zeros like 042 -> 42
            return if (isNegative) "-$intVal" else "$intVal"
        } catch (e: Exception) {
            return ""
        }
    }

    // Media action simulations
    fun simulateQuestionImageUpload(takePhoto: Boolean = false) {
        viewModelScope.launch {
            _questionImageStatus.value = ImageStatus.LOCALLY_SELECTED
            _statusMessage.value = if (takePhoto) "Photo clicked successfully!" else "Image selected from gallery."
            delay(1000)
            _questionImageStatus.value = ImageStatus.UPLOADING
            delay(1500)
            // 85% success simulation
            if (Math.random() < 0.85) {
                _questionImageStatus.value = ImageStatus.UPLOADED
                _questionImageUri.value = if (takePhoto) "photo_camera_sim.png" else "gallery_image_sim.png"
                _statusMessage.value = "Question image uploaded successfully."
            } else {
                _questionImageStatus.value = ImageStatus.FAILED
                _statusMessage.value = "Upload failed. Please retry."
            }
        }
    }

    fun clearQuestionImage() {
        _questionImageStatus.value = ImageStatus.IDLE
        _questionImageUri.value = null
    }

    fun startCrop(type: String) {
        croppingImageType.value = type
        showCropDialog.value = true
    }

    fun confirmCrop() {
        showCropDialog.value = false
        _statusMessage.value = "Image cropped successfully."
    }

    fun simulateSolutionImageUpload(takePhoto: Boolean = false) {
        viewModelScope.launch {
            _solutionImageStatus.value = ImageStatus.LOCALLY_SELECTED
            _statusMessage.value = if (takePhoto) "Solution photo clicked." else "Solution image selected."
            delay(1000)
            _solutionImageStatus.value = ImageStatus.UPLOADING
            delay(1500)
            if (Math.random() < 0.85) {
                _solutionImageStatus.value = ImageStatus.UPLOADED
                _solutionImageUri.value = if (takePhoto) "photo_camera_sol_sim.png" else "gallery_solution_sim.png"
                _statusMessage.value = "Solution image uploaded."
            } else {
                _solutionImageStatus.value = ImageStatus.FAILED
                _statusMessage.value = "Solution upload failed."
            }
        }
    }

    fun clearSolutionImage() {
        _solutionImageStatus.value = ImageStatus.IDLE
        _solutionImageUri.value = null
    }

    // Section Level Configuration Setting
    fun initCreatePaper(editingPaperId: String? = null) {
        if (editingPaperId == null) {
            paperNameInput.value = ""
            physicsQuestionsCount.value = "5"
            physicsMarks.value = "4"
            physicsNegative.value = "-1"

            chemistryQuestionsCount.value = "5"
            chemistryMarks.value = "4"
            chemistryNegative.value = "-1"

            mathsQuestionsCount.value = "5"
            mathsMarks.value = "4"
            mathsNegative.value = "-1"
        } else {
            val paper = _papers.value.find { it.id == editingPaperId } ?: return
            paperNameInput.value = paper.name
            physicsQuestionsCount.value = paper.physicsConfig.targetQuestionCount.toString()
            physicsMarks.value = paper.physicsConfig.defaultMarks.toString()
            physicsNegative.value = paper.physicsConfig.defaultNegativeMarks.toString()

            chemistryQuestionsCount.value = paper.chemistryConfig.targetQuestionCount.toString()
            chemistryMarks.value = paper.chemistryConfig.defaultMarks.toString()
            chemistryNegative.value = paper.chemistryConfig.defaultNegativeMarks.toString()

            mathsQuestionsCount.value = paper.mathsConfig.targetQuestionCount.toString()
            mathsMarks.value = paper.mathsConfig.defaultMarks.toString()
            mathsNegative.value = paper.mathsConfig.defaultNegativeMarks.toString()
        }
    }

    fun saveQuestionPaper(id: String?) {
        val name = paperNameInput.value.ifBlank { "Untitled Question Paper" }
        val pCount = physicsQuestionsCount.value.toIntOrNull() ?: 5
        val pM = physicsMarks.value.toIntOrNull() ?: 4
        val pNeg = physicsNegative.value.toIntOrNull() ?: -1

        val cCount = chemistryQuestionsCount.value.toIntOrNull() ?: 5
        val cM = chemistryMarks.value.toIntOrNull() ?: 4
        val cNeg = chemistryNegative.value.toIntOrNull() ?: -1

        val mCount = mathsQuestionsCount.value.toIntOrNull() ?: 5
        val mM = mathsMarks.value.toIntOrNull() ?: 4
        val mNeg = mathsNegative.value.toIntOrNull() ?: -1

        if (id == null) {
            val newPaper = QuestionPaper(
                id = "qp_${System.currentTimeMillis()}",
                name = name,
                physicsConfig = SectionConfig("Physics", pCount, pM, pNeg),
                chemistryConfig = SectionConfig("Chemistry", cCount, cM, cNeg),
                mathsConfig = SectionConfig("Maths", mCount, mM, mNeg),
                questions = emptyList()
            )
            _papers.value = _papers.value + newPaper
            _statusMessage.value = "Question Paper successfully created!"
            navigateTo(Screen.TeacherPaperEditor(newPaper.id))
        } else {
            _papers.value = _papers.value.map {
                if (it.id == id) {
                    it.copy(
                        name = name,
                        physicsConfig = SectionConfig("Physics", pCount, pM, pNeg),
                        chemistryConfig = SectionConfig("Chemistry", cCount, cM, cNeg),
                        mathsConfig = SectionConfig("Maths", mCount, mM, mNeg)
                    )
                } else it
            }
            _statusMessage.value = "Configurations updated."
            navigateBack()
        }
    }

    // Question Editing initialization and save
    fun initQuestionEdit(paperId: String, questionId: String?) {
        val paper = _papers.value.find { it.id == paperId } ?: return
        if (questionId == null) {
            questionTextInput.value = ""
            _optionTexts.value = listOf("", "", "", "")
            correctMCQOption.value = "A"
            correctIntegerInput.value = ""
            _questionImageUri.value = null
            _questionImageStatus.value = ImageStatus.IDLE
            _solutionImageUri.value = null
            _solutionImageStatus.value = ImageStatus.IDLE
        } else {
            val q = paper.questions.find { q -> q.id == questionId } ?: return
            questionTextInput.value = q.text
            _optionTexts.value = q.options
            correctMCQOption.value = q.correctOption ?: "A"
            correctIntegerInput.value = q.correctInteger?.toString() ?: ""
            _questionImageUri.value = q.questionImageUri
            _questionImageStatus.value = q.questionImageStatus
            _solutionImageUri.value = q.solutionImageUri
            _solutionImageStatus.value = q.solutionImageStatus
        }
    }

    fun updateOptionText(index: Int, text: String) {
        val list = _optionTexts.value.toMutableList()
        if (index in 0..3) {
            list[index] = text
            _optionTexts.value = list
        }
    }

    fun saveQuestion(paperId: String, questionId: String?, section: String, type: QuestionType) {
        val normalizedAnswerKeyString = if (type == QuestionType.INTEGER) {
            normalizeInteger(correctIntegerInput.value)
        } else null

        val finalCorrectInteger = normalizedAnswerKeyString?.toIntOrNull()

        val q = Question(
            id = questionId ?: "q_${System.currentTimeMillis()}",
            section = section,
            type = type,
            text = questionTextInput.value,
            questionImageUri = _questionImageUri.value,
            questionImageStatus = _questionImageStatus.value,
            options = if (type == QuestionType.MCQ) _optionTexts.value else listOf("", "", "", ""),
            correctOption = if (type == QuestionType.MCQ) correctMCQOption.value else null,
            correctInteger = finalCorrectInteger,
            solutionImageUri = _solutionImageUri.value,
            solutionImageStatus = _solutionImageStatus.value
        )

        _papers.value = _papers.value.map { paper ->
            if (paper.id == paperId) {
                val updatedQuestions = if (questionId == null) {
                    paper.questions + q
                } else {
                    paper.questions.map { oldQ -> if (oldQ.id == questionId) q else oldQ }
                }
                paper.copy(questions = updatedQuestions)
            } else paper
        }

        _statusMessage.value = "Question saved successfully!"
        navigateBack()
    }

    fun deleteQuestion(paperId: String, questionId: String) {
        _papers.value = _papers.value.map { paper ->
            if (paper.id == paperId) {
                paper.copy(questions = paper.questions.filter { it.id != questionId })
            } else paper
        }
        _statusMessage.value = "Question deleted."
    }

    // IMMUTABLE SNAPSHOT SCHEDULER
    fun scheduleExam(
        paperId: String,
        examName: String,
        scheduledTime: String,
        durationMinutes: Int,
        isPractice: Boolean
    ) {
        val originalPaper = _papers.value.find { it.id == paperId } ?: return

        // 1. Double check / deep clone the snapshot copy to prove immutability!
        val snapshotOfPaper = originalPaper.copy(
            questions = originalPaper.questions.map { it.copy() }
        )

        // 2. Create the Exam
        val exam = Exam(
            id = "ex_${System.currentTimeMillis()}",
            name = examName.ifBlank { "Exam via ${snapshotOfPaper.name}" },
            originalPaperId = paperId,
            scheduledTime = scheduledTime,
            durationMinutes = durationMinutes,
            status = if (isPractice) ExamStatus.PRACTICE else ExamStatus.LIVE,
            questionPaperSnapshot = snapshotOfPaper // Snapshot copy locked at this moment.
        )

        _exams.value = _exams.value + exam
        _statusMessage.value = "Exam scheduled successfully with a frozen snapshot of the paper!"
        // Direct back to home or list
        navigateBack()
    }

    fun releaseExamResults(examId: String) {
        _exams.value = _exams.value.map {
            if (it.id == examId) it.copy(status = ExamStatus.RELEASED) else it
        }
        _statusMessage.value = "Results released! Students can now view their marked details and solution images."
    }

    fun closeLiveExam(examId: String) {
        _exams.value = _exams.value.map {
            if (it.id == examId) it.copy(status = ExamStatus.CLOSED) else it
        }
        _statusMessage.value = "Exam status closed."
    }

    // Student Active Exam Simulation
    fun startStudentExam(examId: String) {
        val exam = _exams.value.find { it.id == examId } ?: return
        val currentAttempt = ExamAttempt(
            id = "att_${System.currentTimeMillis()}",
            examId = examId,
            studentId = "std_row",
            studentName = studentName,
            answers = emptyMap()
        )
        _activeAttempt.value = currentAttempt
        activeStudentQuestionIndex.value = 0
        activeStudentSection.value = "Physics"
        navigateTo(Screen.StudentAttempt(examId))
    }

    fun updateStudentAnswer(questionId: String, answer: String) {
        val current = _activeAttempt.value ?: return
        val map = current.answers.toMutableMap()
        map[questionId] = answer
        _activeAttempt.value = current.copy(answers = map)
    }

    fun submitStudentExam() {
        val attempt = _activeAttempt.value ?: return
        val exam = _exams.value.find { it.id == attempt.examId } ?: return
        val snapshotPaper = exam.questionPaperSnapshot

        var totalScore = 0
        var physScore = 0
        var chemScore = 0
        var mathScore = 0

        // Calculate score from frozen snapshot rules
        for (q in snapshotPaper.questions) {
            val config = when (q.section) {
                "Physics" -> snapshotPaper.physicsConfig
                "Chemistry" -> snapshotPaper.chemistryConfig
                else -> snapshotPaper.mathsConfig
            }

            val studentAnswer = attempt.answers[q.id]
            val isAnswered = !studentAnswer.isNullOrBlank()

            var questionScore = 0
            if (isAnswered) {
                if (q.type == QuestionType.MCQ) {
                    if (studentAnswer == q.correctOption) {
                        questionScore = config.defaultMarks
                    } else {
                        questionScore = config.defaultNegativeMarks // -1 e.g.
                    }
                } else {
                    // INTEGER
                    val cleanVal = normalizeInteger(studentAnswer ?: "")
                    val targetVal = q.correctInteger?.toString() ?: ""
                    if (cleanVal == targetVal && cleanVal.isNotEmpty()) {
                        questionScore = config.defaultMarks
                    } else {
                        questionScore = config.defaultNegativeMarks
                    }
                }
            } else {
                questionScore = 0
            }

            totalScore += questionScore
            when (q.section) {
                "Physics" -> physScore += questionScore
                "Chemistry" -> chemScore += questionScore
                "Maths" -> mathScore += questionScore
            }
        }

        val finalizedAttempt = attempt.copy(
            isSubmitted = true,
            submittedTime = System.currentTimeMillis(),
            score = totalScore,
            physicsScore = physScore,
            chemistryScore = chemScore,
            mathsScore = mathScore
        )

        _attempts.value = _attempts.value + finalizedAttempt
        _activeAttempt.value = null
        _statusMessage.value = "Your attempt on '${exam.name}' has been graded and saved successfully!"
        // Save to historic list, then navigate back
        navigateBack()
    }
}
